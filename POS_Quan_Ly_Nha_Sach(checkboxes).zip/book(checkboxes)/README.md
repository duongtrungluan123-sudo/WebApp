# Hệ thống POS Quản lý Nhà sách

Đây là dự án xây dựng hệ thống POS (Point of Sale) quản lý nhà sách, được phát triển bằng Java Servlet, JSP, JDBC và MySQL theo mô hình MVC. Hệ thống hỗ trợ quản lý sách, khách hàng, nhân viên, bán hàng, hóa đơn, thống kê doanh thu và quản lý lịch làm việc của nhân viên.

---

# Công nghệ sử dụng

- Java 17+
- JSP & Servlet
- JDBC
- MySQL 8.0+
- Apache Tomcat 10+
- Maven
- Bootstrap 5
- HTML/CSS/JavaScript

---

# Cấu trúc thư mục

```
BookStore_POS
│
├── src/
├── resources/
│   ├── application.properties
│   └── db/
│       └── bookstore.sql
├── web/
├── pom.xml
└── README.md
```

---

# Thư mục dữ liệu

- `bookImage/`: Lưu trữ hình ảnh sách được tải lên.
- `invoices/`: Lưu trữ các hóa đơn PDF được tạo sau khi thanh toán.

Hai thư mục này sẽ được tạo tự động theo đường dẫn cấu hình trong `resources/application.properties` nếu chưa tồn tại.

---

# Yêu cầu trước khi chạy

Đảm bảo máy tính đã cài đặt các phần mềm sau:

- JDK 17 hoặc mới hơn
- Apache Tomcat 10 hoặc mới hơn
- MySQL 8.0 hoặc mới hơn
- Maven 3.9 hoặc mới hơn
- IntelliJ IDEA, Eclipse hoặc NetBeans

---

# Hướng dẫn cài đặt

## Bước 1: Import cơ sở dữ liệu

Import file:

`resources/db/bookstore.sql`

Có thể import bằng MySQL Workbench:

```
Server
→ Data Import
→ Import from Self-Contained File
→ Chọn file bookstore.sql
→ Start Import
```

Hoặc sử dụng Command Line:

```bash
mysql -u root -p bookstore < bookstore.sql
```

---

## Bước 2: Cấu hình kết nối cơ sở dữ liệu

Mở file:

`resources/application.properties`

Thay đổi các thông tin kết nối phù hợp với máy tính của bạn.

Ví dụ:

```properties

db.url=jdbc:mysql://localhost:3306/bookstore
db.username=root
db.password=123456
db.driver=com.mysql.cj.jdbc.Driver

```

Cần chỉnh sửa các thông tin sau nếu khác với cấu hình mặc định:

- Tên cơ sở dữ liệu
- Tên đăng nhập MySQL
- Mật khẩu MySQL
- Địa chỉ máy chủ (Host)
- Cổng kết nối (Port) nếu có thay đổi

---

# Build dự án

Mở Terminal tại thư mục dự án và thực hiện:

```bash
mvn clean install
```

Hoặc:

```bash
mvn clean package
```

Sau khi build thành công, file `.war` sẽ được tạo trong thư mục:

```
target/
```

---

# Triển khai dự án

Sao chép file WAR vừa tạo vào thư mục:

```
Tomcat/webapps/
```

Khởi động Apache Tomcat.

Truy cập hệ thống tại:

```
http://localhost:8080/book
```

(Nếu tên file WAR khác thì thay `book` bằng tên tương ứng.)

---

# Chức năng chính

- Đăng nhập và phân quyền
- Quản lý sách
- Quản lý nhân viên
- Quản lý khách hàng
- Quản lý lịch làm việc của nhân viên
- Quản lý giỏ hàng
- Thanh toán (POS)
- Quản lý hóa đơn
- Thống kê doanh thu

---

# Lưu ý

Trước khi chạy dự án, cần đảm bảo:

- MySQL đang hoạt động.
- Đã import thành công file `resources/db/bookstore.sql`.
- Đã cấu hình đúng thông tin trong `resources/application.properties`.
- Apache Tomcat đã được cấu hình và khởi động.
- Dự án đã được build thành công bằng Maven.

---

# Một số lỗi thường gặp

## Không kết nối được cơ sở dữ liệu

Kiểm tra lại:

- MySQL đã được khởi động.
- Tên cơ sở dữ liệu.
- Tên đăng nhập và mật khẩu MySQL.
- Địa chỉ Host và Port.
- Thông tin trong `resources/application.properties`.

---

## Lỗi HTTP Status 404

Kiểm tra:

- Dự án đã được deploy lên Tomcat.
- Đường dẫn truy cập (Context Path) đúng với tên dự án.
- File WAR đã được triển khai thành công.

---

## Giao diện không cập nhật sau khi chỉnh sửa mã nguồn

Thực hiện lại các bước sau:

```bash
mvn clean
mvn package
```

Sau đó:

- Xóa phiên bản dự án cũ trong thư mục `Tomcat/webapps`.
- Xóa thư mục `Tomcat/work`.
- Xóa thư mục `Tomcat/temp`.
- Chép lại file WAR mới.
- Khởi động lại Apache Tomcat.

---

# Tác giả

**Sinh viên thực hiện**

- Dương Trung Luân

---

# Giấy phép

Dự án được phát triển phục vụ mục đích học tập và nghiên cứu.