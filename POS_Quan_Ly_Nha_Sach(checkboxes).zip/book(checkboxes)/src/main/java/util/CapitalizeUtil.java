package util;

public class CapitalizeUtil {
    public static String capitalize(String text){
        if(text == null || text.trim().isEmpty()){
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for(String word : text.trim().toLowerCase().split("\\s+")){
            sb.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1)).append(" ");
        }
        return sb.toString().trim();
    }
}
