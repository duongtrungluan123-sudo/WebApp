package util;

import java.time.LocalTime;

public final class ShiftUtil {
    private ShiftUtil() {}

    // Ca làm việc theo giờ hiện tại: 08:00-14:00 -> "Sáng", 14:00-20:00 -> "Chiều".
    // Đồng bộ với dashboard (InvoiceDAO.getTodayRevenueByShift):
    //   TIME(created_at) >= '08:00:00' AND < '14:00:00' -> Sáng
    //   TIME(created_at) >= '14:00:00' AND < '20:00:00' -> Chiều
    public static String currentShiftLabel() {
        int hour = LocalTime.now().getHour();
        if (hour >= 8 && hour < 14) {
            return "Sáng";
        }
        if (hour >= 14 && hour < 20) {
            return "Chiều";
        }
        return "Ngoài giờ làm việc";
    }
}
