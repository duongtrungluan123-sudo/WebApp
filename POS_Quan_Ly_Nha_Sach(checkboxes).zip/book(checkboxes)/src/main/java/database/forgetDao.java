package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import config.DBConnection;

public class forgetDao {
   public boolean resetPassword(String phone, String password) throws ClassNotFoundException {
      boolean status = false;
      try {
         Connection connection = DBConnection.getConnection();

         PreparedStatement preparedStatement = connection.prepareStatement("UPDATE employee SET password = ? WHERE phone = ?");

         preparedStatement.setString(1, password);
         preparedStatement.setString(2, phone);
         int row = preparedStatement.executeUpdate();
         if (row > 0) {
            status = true;
         }
      } 
      catch (SQLException e) {
         System.out.println("Lỗi khi truy cập cơ sở dữ liệu: " + e.getMessage());
      }

      return status;
   }
}
