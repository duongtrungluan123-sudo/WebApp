package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import config.DBConnection;
import structure.login;

public class loginDao {

    public login validate(login newLogin) throws ClassNotFoundException {
        try{
            Connection connection = DBConnection.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM employee WHERE email = ? AND password = ?");
        

            preparedStatement.setString(1, newLogin.getEmail());
            preparedStatement.setString(2, newLogin.getPassword());

            System.out.println(preparedStatement);
            login user = new login();

            try (ResultSet rs = preparedStatement.executeQuery()) {

                if (rs.next()) {
                    user.setId(rs.getInt("id"));
                    String displayName = rs.getString("name");
                    if (displayName == null || displayName.isBlank()) {
                        displayName = rs.getString("username");
                    }
                    if (displayName != null && !displayName.isBlank()) {
                        user.setUsername(displayName);
                    }
                    user.setRole(rs.getString("role"));
                    return user;
                }

            }

        } catch (SQLException e) {
            System.out.println("Lỗi khi truy cập cơ sở dữ liệu: " + e.getMessage());
        }

        return null;
    }
}