package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import config.DBConnection;
import structure.Invoice;
import structure.InvoiceDetail;

public class InvoiceDAO {

    // Thêm hoá đơn mới (kèm chi tiết) và trừ tồn kho sách trong cùng một transaction
    public int createInvoice(Invoice invoice, List<InvoiceDetail> details) throws ClassNotFoundException, SQLException {
        String sql = "INSERT INTO invoice (invoice_date, total_amount, employee_name, customer_name, customer_phone, payment_method, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
        int invoiceId = -1;

        Connection connection = null;
        try {
            connection = DBConnection.getConnection();
            connection.setAutoCommit(false);

            try (PreparedStatement ps = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                ps.setTimestamp(1, invoice.getInvoiceDate());
                ps.setDouble(2, invoice.getTotalAmount());
                ps.setString(3, invoice.getEmployeeName());
                ps.setString(4, invoice.getCustomerName());
                ps.setString(5, invoice.getCustomerPhone());
                ps.setString(6, invoice.getPaymentMethod());
                ps.setString(7, invoice.getStatus());

                ps.executeUpdate();

                // Lấy ID của hoá đơn vừa tạo
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        invoiceId = rs.getInt(1);
                    }
                }
            }

            // Thêm chi tiết hoá đơn
            if (invoiceId != -1 && details != null && !details.isEmpty()) {
                String detailSql = "INSERT INTO invoice_detail (invoice_id, book_id, book_name, quantity, unit_price, total_price) VALUES (?, ?, ?, ?, ?, ?)";
                try (PreparedStatement detailPs = connection.prepareStatement(detailSql)) {
                    for (InvoiceDetail detail : details) {
                        detailPs.setInt(1, invoiceId);
                        detailPs.setInt(2, detail.getBookId());
                        detailPs.setString(3, detail.getBookName());
                        detailPs.setInt(4, detail.getQuantity());
                        detailPs.setDouble(5, detail.getUnitPrice());
                        detailPs.setDouble(6, detail.getTotalPrice());
                        detailPs.addBatch();
                    }
                    detailPs.executeBatch();
                }

                // Trừ số lượng tồn kho sách (chỉ trừ khi đủ hàng)
                String updateStock = "UPDATE books SET quantity = quantity - ? WHERE book_id = ? AND quantity >= ?";
                try (PreparedStatement updPs = connection.prepareStatement(updateStock)) {
                    for (InvoiceDetail detail : details) {
                        updPs.setInt(1, detail.getQuantity());
                        updPs.setInt(2, detail.getBookId());
                        updPs.setInt(3, detail.getQuantity());
                        updPs.addBatch();
                    }
                    int[] rows = updPs.executeBatch();
                    for (int r : rows) {
                        if (r == 0) {
                            throw new SQLException("Không đủ tồn kho để hoàn tất giao dịch.");
                        }
                    }
                }
            }

            connection.commit();
        } catch (SQLException e) {
            if (connection != null) {
                connection.rollback();
            }
            throw e;
        } finally {
            if (connection != null) {
                connection.setAutoCommit(true);
                connection.close();
            }
        }

        return invoiceId;
    }

    // Lấy tất cả hoá đơn (không pagination)
    public List<Invoice> getAllInvoices() throws ClassNotFoundException, SQLException {
        return getAllInvoices(0, Integer.MAX_VALUE);
    }

    // Lấy tất cả hoá đơn có pagination
    public List<Invoice> getAllInvoices(int offset, int limit) throws ClassNotFoundException, SQLException {
        List<Invoice> invoices = new ArrayList<>();
        String sql = "SELECT id, invoice_date, total_amount, employee_name, customer_name, customer_phone, payment_method, status FROM invoice ORDER BY id DESC LIMIT ? OFFSET ?";

        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, limit);
            ps.setInt(2, offset);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Invoice invoice = new Invoice();
                    invoice.setId(rs.getInt("id"));
                    invoice.setInvoiceDate(rs.getTimestamp("invoice_date"));
                    invoice.setTotalAmount(rs.getDouble("total_amount"));
                    invoice.setEmployeeName(rs.getString("employee_name"));
                    invoice.setCustomerName(rs.getString("customer_name"));
                    invoice.setCustomerPhone(rs.getString("customer_phone"));
                    invoice.setPaymentMethod(rs.getString("payment_method"));
                    invoice.setStatus(rs.getString("status"));
                    invoices.add(invoice);
                }
            }
        }

        return invoices;
    }

    // Lấy lịch sử bán hàng của nhân viên đang đăng nhập (không pagination)
    public List<Invoice> getInvoicesByEmployee(String employeeName) throws ClassNotFoundException, SQLException {
        return getInvoicesByEmployee(employeeName, 0, Integer.MAX_VALUE);
    }

    // Lấy lịch sử bán hàng của nhân viên đang đăng nhập có pagination
    public List<Invoice> getInvoicesByEmployee(String employeeName, int offset, int limit) throws ClassNotFoundException, SQLException {

        List<Invoice> list = new ArrayList<>();

        String sql = """
            SELECT id, invoice_date, total_amount, employee_name,
                customer_name, customer_phone,
                payment_method, status
            FROM invoice
            WHERE employee_name = ?
            ORDER BY invoice_date DESC
            LIMIT ? OFFSET ?
            """;

        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, employeeName);
            ps.setInt(2, limit);
            ps.setInt(3, offset);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Invoice invoice = new Invoice();
                    invoice.setId(rs.getInt("id"));
                    invoice.setInvoiceDate(rs.getTimestamp("invoice_date"));
                    invoice.setTotalAmount(rs.getDouble("total_amount"));
                    invoice.setEmployeeName(rs.getString("employee_name"));
                    invoice.setCustomerName(rs.getString("customer_name"));
                    invoice.setCustomerPhone(rs.getString("customer_phone"));
                    invoice.setPaymentMethod(rs.getString("payment_method"));
                    invoice.setStatus(rs.getString("status"));

                    list.add(invoice);
                }
            }
        }

        return list;
    }

    // Đếm tổng số hoá đơn
    public int countAllInvoices() throws ClassNotFoundException, SQLException {
        String sql = "SELECT COUNT(*) FROM invoice";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    // Đếm số hoá đơn theo nhân viên
    public int countInvoicesByEmployee(String employeeName) throws ClassNotFoundException, SQLException {
        String sql = "SELECT COUNT(*) FROM invoice WHERE employee_name = ?";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, employeeName);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return 0;
    }

    public Invoice getInvoiceById(int invoiceId) throws ClassNotFoundException, SQLException {

        String sql = "SELECT * FROM invoice WHERE id = ?";

        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, invoiceId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                Invoice invoice = new Invoice();
                
                invoice.setId(rs.getInt("id"));
                invoice.setInvoiceDate(rs.getTimestamp("invoice_date"));
                invoice.setEmployeeName(rs.getString("employee_name"));
                invoice.setCustomerName(rs.getString("customer_name"));
                invoice.setCustomerPhone(rs.getString("customer_phone"));
                invoice.setPaymentMethod(rs.getString("payment_method"));
                invoice.setTotalAmount(rs.getDouble("total_amount"));

                return invoice;
            }

        } 
        return null;
    }
    // Lấy chi tiết hoá đơn theo ID
    public List<InvoiceDetail> getInvoiceDetails(int invoiceId) throws ClassNotFoundException, SQLException {
        List<InvoiceDetail> details = new ArrayList<>();
        String sql = "SELECT id, invoice_id, book_id, book_name, quantity, unit_price, total_price FROM invoice_detail WHERE invoice_id = ?";

        try (Connection connection = DBConnection.getConnection(); 
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, invoiceId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                InvoiceDetail detail = new InvoiceDetail();
                detail.setId(rs.getInt("id"));
                detail.setInvoiceId(rs.getInt("invoice_id"));
                detail.setBookId(rs.getInt("book_id"));
                detail.setBookName(rs.getString("book_name"));
                detail.setQuantity(rs.getInt("quantity"));
                detail.setUnitPrice(rs.getDouble("unit_price"));
                detail.setTotalPrice(rs.getDouble("total_price"));
                details.add(detail);
            }

        }
        return details;
    }

    public boolean addInvoiceDetail(InvoiceDetail detail) throws ClassNotFoundException {

        String sql = "INSERT INTO invoice_detail (invoice_id, book_id, book_name, quantity, unit_price, total_price) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, detail.getInvoiceId());
            ps.setInt(2, detail.getBookId());
            ps.setString(3, detail.getBookName());
            ps.setInt(4, detail.getQuantity());
            ps.setDouble(5, detail.getUnitPrice());
            ps.setDouble(6, detail.getTotalPrice());

            return ps.executeUpdate() > 0;

            } catch (SQLException e) {
                throw new RuntimeException(e);
        }
    }

    // Lấy doanh thu theo tuần (Thứ 2 đến Chủ Nhật của tuần hiện tại)
    public List<Invoice> getRevenueLast7Days() throws SQLException, ClassNotFoundException {

        List<Invoice> list = new ArrayList<>();

            String sql =
                "WITH RECURSIVE week_days AS ( " +
                "    SELECT CURDATE() - INTERVAL WEEKDAY(CURDATE()) DAY AS ngay " +
                "    UNION ALL " +
                "    SELECT ngay + INTERVAL 1 DAY " +
                "    FROM week_days " +
                "    WHERE ngay < CURDATE() - INTERVAL WEEKDAY(CURDATE()) DAY + INTERVAL 6 DAY " +
                ") " +
                "SELECT week_days.ngay, COALESCE(SUM(i.total_amount),0) tong " +
                "FROM week_days " +
                "LEFT JOIN invoice i ON DATE(i.invoice_date) = week_days.ngay AND i.status = 'completed' " +
                "GROUP BY week_days.ngay ORDER BY week_days.ngay";

            try (Connection connection = DBConnection.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    Invoice newInvoice = new Invoice();
                    newInvoice.setInvoiceDate(rs.getTimestamp("ngay"));
                    newInvoice.setTotalAmount(rs.getDouble("tong"));
                    list.add(newInvoice);
                }
        }

        return list;
    }

    // Lấy doanh thu theo tháng
    public List<Invoice> getRevenueByMonth() throws ClassNotFoundException, SQLException {
        List<Invoice> list = new ArrayList<>();
        String sql = "WITH RECURSIVE days AS ( " +
        "    SELECT DATE_FORMAT(CURDATE(), '%Y-%m-01') AS ngay " +
        "    UNION ALL " +
        "    SELECT DATE_ADD(ngay, INTERVAL 1 DAY) " +
        "    FROM days " +
        "    WHERE ngay < LAST_DAY(CURDATE()) " +
        ") " +
        "SELECT days.ngay, COALESCE(SUM(i.total_amount),0) tong " +
        "FROM days " +
        "LEFT JOIN invoice i " +
        "ON DATE(i.invoice_date)=days.ngay " +
        "AND i.status='completed' " +
        "GROUP BY days.ngay " +
        "ORDER BY days.ngay";

        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();) {
        

            while (rs.next()) {
                Invoice invoice = new Invoice();
                invoice.setInvoiceDate(rs.getTimestamp("ngay"));
                invoice.setTotalAmount(rs.getDouble("tong"));
                list.add(invoice);
            }           

        } 
        
        return list;
    }


    // Lấy doanh thu hôm nay chia theo ca: [0] = Ca Sáng (08:00-14:00), [1] = Ca Chiều (14:00-20:00)
    // Dựa vào cột created_at (thời gian tạo hóa đơn)
    public double[] getTodayRevenueByShift() throws ClassNotFoundException, SQLException {
        double[] result = new double[] { 0.0, 0.0 };
        String sql = "SELECT "
                + "COALESCE(SUM(CASE WHEN TIME(created_at) >= '08:00:00' AND TIME(created_at) < '14:00:00' "
                + "THEN total_amount ELSE 0 END), 0) AS sang, "
                + "COALESCE(SUM(CASE WHEN TIME(created_at) >= '14:00:00' AND TIME(created_at) < '20:00:00' "
                + "THEN total_amount ELSE 0 END), 0) AS chieu "
                + "FROM invoice WHERE DATE(created_at) = CURDATE() AND status = 'completed'";

        try (Connection connection = DBConnection.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                result[0] = rs.getDouble("sang");
                result[1] = rs.getDouble("chieu");
            }
        }

        return result;
    }

    // Đếm số đơn hôm nay chia theo ca: [0] = Ca Sáng (08:00-14:00), [1] = Ca Chiều (14:00-20:00)
    // Dựa vào cột created_at (thời gian tạo hóa đơn)
    public int[] getTodayOrderCountByShift() throws ClassNotFoundException, SQLException {
        int[] result = new int[] { 0, 0 };
        String sql = "SELECT "
                + "COALESCE(SUM(CASE WHEN TIME(created_at) >= '08:00:00' AND TIME(created_at) < '14:00:00' "
                + "THEN 1 ELSE 0 END), 0) AS sang, "
                + "COALESCE(SUM(CASE WHEN TIME(created_at) >= '14:00:00' AND TIME(created_at) < '20:00:00' "
                + "THEN 1 ELSE 0 END), 0) AS chieu "
                + "FROM invoice WHERE DATE(created_at) = CURDATE() AND status = 'completed'";

        try (Connection connection = DBConnection.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                result[0] = rs.getInt("sang");
                result[1] = rs.getInt("chieu");
            }
        }

        return result;
    }

    // Lấy doanh thu hôm nay (WHERE DATE(invoice_date) = CURDATE())
    // Trả về 0 nếu chưa có doanh thu hôm nay (không lấy số tiền của tháng/tổng)
    public double getTodayRevenue() throws ClassNotFoundException, SQLException {
        String sql = "SELECT COALESCE(SUM(total_amount), 0) FROM invoice "
                + "WHERE DATE(invoice_date) = CURDATE() AND status = 'completed'";

        try (Connection connection = DBConnection.getConnection();
                PreparedStatement ps = connection.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                Double result = rs.getDouble(1);
                return rs.wasNull() ? 0.0 : result;
            }
        }
        return 0.0;
    }


    // Xóa hoá đơn
    public boolean deleteInvoice(int invoiceId) throws ClassNotFoundException {
        String deleteDetailsSql = "DELETE FROM invoice_detail WHERE invoice_id = ?";
        String deleteInvoiceSql = "DELETE FROM invoice WHERE id = ?";

        try (Connection connection = DBConnection.getConnection()) {
            // 1. Tắt AutoCommit để bắt đầu Transaction
            connection.setAutoCommit(false);

            try (PreparedStatement psDetails = connection.prepareStatement(deleteDetailsSql);
                PreparedStatement psInvoice = connection.prepareStatement(deleteInvoiceSql)) {

                // 2. Xóa các bản ghi con trong invoice_detail trước
                psDetails.setInt(1, invoiceId);
                psDetails.executeUpdate(); // Có thể trả về 0 nếu hóa đơn rỗng, điều này bình thường

                // 3. Xóa bản ghi cha trong invoice sau
                psInvoice.setInt(1, invoiceId);
                int rowsAffected = psInvoice.executeUpdate();

                // 4. Nếu cả 2 đều thành công, thực hiện Commit để lưu thay đổi
                connection.commit();
                return rowsAffected > 0;

            } catch (SQLException e) {
                // 5. Nếu có bất kỳ lỗi nào xảy ra (ví dụ đứt cáp, lỗi DB), Rollback lại toàn bộ
                connection.rollback();
                throw new RuntimeException("Lỗi khi xóa chi tiết hoặc hóa đơn: " + e.getMessage(), e);
            } finally {
                // 6. Đặt lại trạng thái AutoCommit về mặc định để trả Connection về Pool an toàn
                connection.setAutoCommit(true);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Lỗi kết nối CSDL: " + e.getMessage(), e);
        }
    }
}