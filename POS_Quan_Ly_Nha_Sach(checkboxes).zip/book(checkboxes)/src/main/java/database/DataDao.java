package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import config.DBConnection;
import structure.Invoice;
import structure.books;
import structure.categories;
import structure.login;
import structure.schedule;

public class DataDao {
    public List<login> getAllEmployees() throws ClassNotFoundException {
        List<login> employees = new ArrayList<>();
        String sql = "SELECT id, name, email, phone, password, role FROM employee";

        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                login emp = new login();
                emp.setId(rs.getInt("id"));
                emp.setUsername(rs.getString("name"));
                emp.setEmail(rs.getString("email"));
                emp.setPhone(rs.getString("phone"));
                emp.setPassword(rs.getString("password"));
                emp.setRole(rs.getString("role"));

                employees.add(emp);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return employees;
    }

    public List<books> getAllBooks() throws ClassNotFoundException {
        List<books> books = new ArrayList<>();
        String sql = "SELECT b.book_id, b.image_url, b.book_name, b.author, b.quantity, b.book_page, b.publicyear, b.selling_price, b.category_id, c.category_name, "
                + "COALESCE(SUM(d.quantity), 0) AS sold "
                + "FROM books b "
                + "JOIN categories c ON b.category_id = c.id "
                + "LEFT JOIN invoice_detail d ON b.book_id = d.book_id "
                + "LEFT JOIN invoice i ON d.invoice_id = i.id AND i.status = 'completed' "
                + "GROUP BY b.book_id, b.image_url, b.book_name, b.author, b.quantity, b.book_page, b.publicyear, b.selling_price, b.category_id, c.category_name "
                + "ORDER BY b.book_id ASC";

        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                books book = new books();
                book.setBook_id(rs.getInt("book_id"));
                book.setImageUrl(rs.getString("image_url"));
                book.setBookName(rs.getString("book_name"));
                book.setAuthor(rs.getString("author"));
                book.setCategory(rs.getString("category_name"));
                book.setCategory_id(rs.getInt("category_id"));
                book.setQuantity(rs.getInt("quantity"));
                book.setBookPage(rs.getInt("book_page"));
                book.setPublicYear(rs.getInt("publicyear"));
                book.setSellingPrice(rs.getDouble("selling_price"));
                book.setSold(rs.getInt("sold"));
                books.add(book);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return books;
    }

    public List<Invoice> getAllInvoices() throws ClassNotFoundException {
        return getAllInvoices(null);
    }

    public List<Invoice> getAllInvoices(String employeeName) throws ClassNotFoundException {
        return getAllInvoices(employeeName, 0, Integer.MAX_VALUE);
    }

    public List<Invoice> getAllInvoices(int offset, int limit) throws ClassNotFoundException {
        return getAllInvoices(null, offset, limit);
    }

    public List<Invoice> getAllInvoices(String employeeName, int offset, int limit) throws ClassNotFoundException {
        List<Invoice> invoices = new ArrayList<>();
        String sql = "SELECT id, invoice_date, total_amount, employee_name, customer_name, customer_phone, payment_method, status FROM invoice";

        // Lọc theo nhân viên (thêm WHERE employee_name)
        if (employeeName != null && !employeeName.trim().isEmpty()) {
            sql += " WHERE employee_name LIKE ?";
        }

        sql += " ORDER BY invoice_date DESC LIMIT ? OFFSET ?";

        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            int paramIndex = 1;
            if (employeeName != null && !employeeName.trim().isEmpty()) {
                ps.setString(paramIndex++, "%" + employeeName.trim() + "%");
            }
            ps.setInt(paramIndex++, limit);
            ps.setInt(paramIndex, offset);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Invoice invoice = new Invoice();
                    invoice.setId(rs.getInt("id"));
                    invoice.setInvoiceDate(rs.getTimestamp("invoice_date"));
                    invoice.setTotalAmount(rs.getDouble("total_amount"));
                    invoice.setEmployeeName(rs.getString("employee_name"));
                    invoice.setCustomerName(rs.getString("customer_name"));
                    invoice.setCustomerPhone(rs.getString("customer_phone"));
                    invoice.setPaymentMethod(rs.getString("payment_method"));
                    invoice.setStatus(rs.getString("status"));
                    invoices.add(invoice);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return invoices;
    }

    // Đếm tổng số hóa đơn
    public int countAllInvoices() throws ClassNotFoundException {
        String sql = "SELECT COUNT(*) FROM invoice";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return 0;
    }

    // Đếm số hóa đơn theo nhân viên
    public int countInvoicesByEmployee(String employeeName) throws ClassNotFoundException {
        String sql = "SELECT COUNT(*) FROM invoice WHERE employee_name LIKE ?";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, "%" + employeeName.trim() + "%");
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return 0;
    }

    //Check số điện thoại
    public boolean isPhoneExists(String phone)
        throws ClassNotFoundException, SQLException {

        String sql = "SELECT 1 FROM employee WHERE phone = ?";

        try (Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, phone);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }


    // Thêm / sửa / xóa / getEmployeeByID Nhân viên
    public int addEmployee(login employee) throws ClassNotFoundException {
        String sql = "INSERT INTO employee (name, email, phone, password, role) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, employee.getUsername());
            ps.setString(2, employee.getEmail());
            ps.setString(3, employee.getPhone());
            ps.setString(4, employee.getPassword());
            ps.setString(5, employee.getRole());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return -1;
    }

    public void updateEmployee(login employee) throws ClassNotFoundException {
        String sql = "UPDATE employee SET name = ?, email = ?, phone = ?, password = ?, role = ? WHERE id = ?";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, employee.getUsername());
            ps.setString(2, employee.getEmail());
            ps.setString(3, employee.getPhone());
            ps.setString(4, employee.getPassword());
            ps.setString(5, employee.getRole());
            ps.setInt(6, employee.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void deleteEmployee(int id) throws ClassNotFoundException{
        String sql = "DELETE FROM employee WHERE id = ?";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public login getEmployeeById(int id) throws ClassNotFoundException {
        login employee = null;
        String sql = "SELECT id, name, email, phone, password, role FROM employee WHERE id = ?";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                employee = new login();
                employee.setId(rs.getInt("id"));
                employee.setUsername(rs.getString("name"));
                employee.setEmail(rs.getString("email"));
                employee.setPhone(rs.getString("phone"));
                employee.setPassword(rs.getString("password"));
                employee.setRole(rs.getString("role"));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return employee;
    }


    public void deleteSchedulesByDate(String workDate) throws ClassNotFoundException {
        String sql = "DELETE FROM employee_schedule WHERE work_date = ?";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setDate(1, java.sql.Date.valueOf(workDate));
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //Thêm / Sửa / Lịch
    public void addEmployeeScheduleWithDate(int employeeId, String workDate, String dayOfWeek, String shift) throws ClassNotFoundException {
        String sql = "INSERT INTO employee_schedule(employee_id, work_date, day_of_week, shift) VALUES (?, ?, ?, ?)";

        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, employeeId);
            ps.setDate(2, java.sql.Date.valueOf(workDate));
            ps.setString(3, dayOfWeek);
            ps.setString(4, shift);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public List<schedule> getScheduleByEmployeeId(int employeeId) throws ClassNotFoundException {

        List<schedule> schedules = new ArrayList<>();

        String sql = "SELECT es.id AS schedule_id, e.id AS employee_id, e.name AS employee_name, es.work_date, es.day_of_week, es.shift FROM employee e INNER JOIN employee_schedule es ON e.id = es.employee_id WHERE e.id = ? ";


        try(Connection connection = DBConnection.getConnection();

            PreparedStatement ps =
                connection.prepareStatement(sql)){

            ps.setInt(1, employeeId);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){

                schedule s = new schedule();

                s.setId(rs.getInt("schedule_id"));
                s.setEmployeeId(rs.getInt("employee_id"));
                s.setEmployeeName(rs.getString("employee_name"));
                s.setWorkDate(rs.getDate("work_date"));
                s.setDayOfWeek(rs.getString("day_of_week"));
                s.setShift(rs.getString("shift"));

                schedules.add(s);
            }

        }catch(SQLException e){
            System.out.println("Lỗi");
            throw new RuntimeException(e);
        }

        return schedules;
    }
    
    // Lấy tất cả lịch làm việc trong khoảng thời gian (cho filter "Tất cả nhân viên")
    public List<schedule> getAllSchedulesByDateRange(String startDate, String endDate) throws ClassNotFoundException {
        List<schedule> schedules = new ArrayList<>();

        String sql = "SELECT es.id AS schedule_id, e.id AS employee_id, e.name AS employee_name, es.work_date, es.day_of_week, es.shift " +
                     "FROM employee e INNER JOIN employee_schedule es ON e.id = es.employee_id " +
                     "WHERE es.work_date BETWEEN ? AND ? ORDER BY es.work_date, e.name";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setDate(1, java.sql.Date.valueOf(startDate));
            ps.setDate(2, java.sql.Date.valueOf(endDate));

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                schedule s = new schedule();
                s.setId(rs.getInt("schedule_id"));
                s.setEmployeeId(rs.getInt("employee_id"));
                s.setEmployeeName(rs.getString("employee_name"));
                s.setWorkDate(rs.getDate("work_date"));
                s.setDayOfWeek(rs.getString("day_of_week"));
                s.setShift(rs.getString("shift"));
                schedules.add(s);
            }

        } catch (SQLException e) {
            System.out.println("Lỗi getAllSchedulesByDateRange: " + e.getMessage());
            throw new RuntimeException(e);
        }

        return schedules;
    }


    //Check Sách đã có hay chưa / Thêm / sửa / xóa / getBookByIdSách

    @SuppressWarnings("CallToPrintStackTrace")
    public boolean existsBook(String bookName, String author) throws ClassNotFoundException {
        String sql = "SELECT 1 FROM books WHERE book_name = ? AND author = ? LIMIT 1";

        try (Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, bookName.trim());
            ps.setString(2, author.trim());

            ResultSet rs = ps.executeQuery();
            return rs.next();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public boolean existsBook(String bookName, String author, int excludeId) throws ClassNotFoundException {
        String sql = "SELECT 1 FROM books WHERE book_name = ? AND author = ? AND book_id != ? LIMIT 1";

        try (Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, bookName.trim());
            ps.setString(2, author.trim());
            ps.setInt(3, excludeId);

            ResultSet rs = ps.executeQuery();
            return rs.next();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("CallToPrintStackTrace")
    public boolean addBook(books book) throws ClassNotFoundException {
        String sql = "INSERT INTO books (image_url, book_name, author, category_id, quantity, book_page, publicyear, selling_price) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, book.getImageUrl());
            ps.setString(2, book.getBookName());
            ps.setString(3, book.getAuthor());
            ps.setInt(4, book.getCategory_id());
            ps.setInt(5, book.getQuantity());
            ps.setInt(6, book.getBookPage());
            ps.setInt(7, book.getPublicYear());
            ps.setDouble(8, book.getSellingPrice());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public boolean updateBook(books book) throws ClassNotFoundException {
        String sql = "UPDATE books SET image_url = ?, book_name = ?, author = ?, category_id = ?, quantity = ?, book_page = ?, publicyear = ?, selling_price = ? WHERE book_id = ?";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, book.getImageUrl());
            ps.setString(2, book.getBookName());
            ps.setString(3, book.getAuthor());
            ps.setInt(4, book.getCategory_id());
            ps.setInt(5, book.getQuantity());
            ps.setInt(6, book.getBookPage());
            ps.setInt(7, book.getPublicYear());
            ps.setDouble(8, book.getSellingPrice());
            ps.setInt(9, book.getBook_id());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void deleteBook(int id) throws ClassNotFoundException {
        String sql = "DELETE FROM books WHERE book_id = ?";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }



    public books getBookById(int id) throws ClassNotFoundException {
        books book = null;
        String sql = "SELECT b.book_id, b.image_url, b.book_name, b.author, c.category_name, b.book_page, b.quantity, b.publicyear, b.selling_price "
                + "FROM books b LEFT JOIN categories c ON b.category_id = c.id WHERE b.book_id = ?";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                book = new books();
                book.setBook_id(rs.getInt("book_id"));
                book.setImageUrl(rs.getString("image_url"));
                book.setBookName(rs.getString("book_name"));
                book.setAuthor(rs.getString("author"));
                book.setCategory(rs.getString("category_name"));
                book.setBookPage(rs.getInt("book_page"));
                book.setQuantity(rs.getInt("quantity"));
                book.setPublicYear(rs.getInt("publicyear"));
                book.setSellingPrice(rs.getDouble("selling_price"));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return book;
    }


    public List<categories> getAllCategories() throws ClassNotFoundException {

        List<categories> list = new ArrayList<>();

        String sql = "SELECT * FROM categories ORDER BY category_name";


        try (Connection connection = DBConnection.getConnection();

            PreparedStatement ps = connection.prepareStatement(sql);

            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                categories c = new categories();

                c.setId(rs.getInt("id"));
                c.setCategoryName(rs.getString("category_name"));

                list.add(c);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return list;
    }

    public categories getCategoryById(int id) throws ClassNotFoundException {

        String sql = "SELECT * FROM categories WHERE id=?";


        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                categories c = new categories();

                c.setId(rs.getInt("id"));
                c.setCategoryName(rs.getString("category_name"));

                return c;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return null;
    }

    // Lấy thể loại kèm tổng số sách
    public categories getCategory(int id) throws ClassNotFoundException {

        String sql = "SELECT c.id, c.category_name, COUNT(b.book_id) AS total_book "
                + "FROM categories c "
                + "LEFT JOIN books b ON c.id = b.category_id "
                + "WHERE c.id = ? "
                + "GROUP BY c.id, c.category_name";

        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                categories c = new categories();

                c.setId(rs.getInt("id"));
                c.setCategoryName(rs.getString("category_name"));
                c.setTotalbook(rs.getInt("total_book"));

                return c;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return null;
    }


    // Lấy ID thể loại theo tên
    public int getCategoryByName(String categoryName) throws ClassNotFoundException {
        String sql = "SELECT id FROM categories WHERE category_name = ?";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, categoryName.trim());
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("id");
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return -1;
    }
    // Lấy tất cả thể loại kèm tổng số sách
    public List<categories> getAllCategoriesWithBookCount() throws ClassNotFoundException {

        List<categories> list = new ArrayList<>();

        String sql = "SELECT c.id, c.category_name, COUNT(b.book_id) AS total_book "
                + "FROM categories c "
                + "LEFT JOIN books b ON c.id = b.category_id "
                + "GROUP BY c.id, c.category_name "
                + "ORDER BY c.category_name";


        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                categories c = new categories();

                c.setId(rs.getInt("id"));
                c.setCategoryName(rs.getString("category_name"));
                c.setTotalbook(rs.getInt("total_book"));

                list.add(c);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return list;
    }

    // Thêm thể loại mới
    public boolean addCategory(String categoryName) throws ClassNotFoundException {
        String sql = "INSERT INTO categories (category_name) VALUES (?)";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, categoryName.trim());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    return true;
                }
            }
            return false;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Cập nhật thể loại theo ID và trả về danh sách tất cả thể loại
    public boolean updateCategoryById(int id, String categoryName) throws ClassNotFoundException {
        // Kiểm tra tên thể loại không được null hoặc rỗng
        if (categoryName == null || categoryName.trim().isEmpty()) {
            return false;
        }

        String sql = "UPDATE categories SET category_name = ? WHERE id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, categoryName.trim());
            ps.setInt(2, id);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Xóa thể loại
    public boolean deleteCategory(int id) throws ClassNotFoundException {
        String sql = "DELETE FROM categories WHERE id = ?";
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    
    // Hiệu suất bán sách
    public int countBooks() throws ClassNotFoundException {
        String sql = "SELECT COUNT(*) FROM books";
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return 0;
    }

    // Tổng số quyển đã bán hôm nay (chỉ tính hoá đơn đã hoàn thành)
    public int getSoldToday() throws ClassNotFoundException {
        String sql = "SELECT COALESCE(SUM(d.quantity), 0) "
                + "FROM invoice_detail d JOIN invoice i ON d.invoice_id = i.id "
                + "WHERE DATE(i.invoice_date) = CURDATE() AND i.status = 'completed'";
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return 0;
    }

    // Số đầu sách có tồn kho thấp (<= threshold)
    public int countLowStockBooks(int threshold) throws ClassNotFoundException {
        String sql = "SELECT COUNT(*) FROM books WHERE quantity <= ?";
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, threshold);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return 0;
    }

    // Sách bán chạy nhất (theo tổng số lượng đã bán)
    public List<books> getTopSellers(int limit) throws ClassNotFoundException {
        List<books> list = new ArrayList<>();
        String sql = "SELECT b.book_id, b.image_url, b.book_name, b.author, "
                + "COALESCE(SUM(d.quantity), 0) AS sold "
                + "FROM books b "
                + "LEFT JOIN invoice_detail d ON b.book_id = d.book_id "
                + "LEFT JOIN invoice i ON d.invoice_id = i.id AND i.status = 'completed' "
                + "GROUP BY b.book_id, b.image_url, b.book_name, b.author "
                + "ORDER BY sold DESC, b.book_id ASC LIMIT ?";

        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                books b = new books();
                b.setBook_id(rs.getInt("book_id"));
                b.setImageUrl(rs.getString("image_url"));
                b.setBookName(rs.getString("book_name"));
                b.setAuthor(rs.getString("author"));
                b.setSold(rs.getInt("sold"));
                list.add(b);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    // Danh sách sách tồn kho thấp (kèm số đã bán)
    public List<books> getLowStockBooks(int threshold) throws ClassNotFoundException {
        List<books> list = new ArrayList<>();
        String sql = "SELECT b.book_id, b.book_name, b.author, b.quantity, c.category_name, "
                + "COALESCE(SUM(d.quantity), 0) AS sold "
                + "FROM books b "
                + "LEFT JOIN categories c ON b.category_id = c.id "
                + "LEFT JOIN invoice_detail d ON b.book_id = d.book_id "
                + "LEFT JOIN invoice i ON d.invoice_id = i.id AND i.status = 'completed' "
                + "WHERE b.quantity <= ? "
                + "GROUP BY b.book_id, b.book_name, b.author, b.quantity, c.category_name "
                + "ORDER BY b.quantity ASC, sold DESC";

        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, threshold);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                books b = new books();
                b.setBook_id(rs.getInt("book_id"));
                b.setBookName(rs.getString("book_name"));
                b.setAuthor(rs.getString("author"));
                b.setQuantity(rs.getInt("quantity"));
                b.setCategory(rs.getString("category_name"));
                b.setSold(rs.getInt("sold"));
                list.add(b);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return list;
    }
}