package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {


    private static final String URL = "jdbc:mysql://" 
                    + DBConfig.get("db.host")+ ":"
                    + DBConfig.get("db.port")+ "/"
                    + DBConfig.get("db.name")+ "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8";

    public static Connection getConnection()
        throws SQLException, ClassNotFoundException {

    Class.forName("com.mysql.cj.jdbc.Driver");

    return DriverManager.getConnection(
            URL,
            DBConfig.get("db.username"),
            DBConfig.get("db.password"));
}
}
