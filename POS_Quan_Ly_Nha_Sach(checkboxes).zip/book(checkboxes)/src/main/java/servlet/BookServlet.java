package servlet;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import config.DBConfig;
import database.DataDao;
import structure.books;
import structure.categories;
import util.CapitalizeUtil;

@MultipartConfig
@WebServlet("/books")
public class BookServlet extends HttpServlet{
        private static final long serialVersionUID = 1L;
    private DataDao dataDao;

    @Override
    public void init() {
        this.dataDao = new DataDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        switch (action) {
            case "add" -> {
                request.getRequestDispatcher("/admin.jsp").forward(request, response);
            }
                

            case "edit" -> {
                int id = Integer.parseInt(request.getParameter("id"));
                books book = null;
                try {
                    book = dataDao.getBookById(id);
                } catch (ClassNotFoundException ex){
                    System.out.println("Lỗi");
                }
                request.setAttribute("book", book);
                request.setAttribute("editMode", true);
                request.getRequestDispatcher("/admin.jsp").forward(request, response);
            }
                

            case "delete" -> {
                    int id = Integer.parseInt(request.getParameter("id"));
                    HttpSession session = request.getSession();
                    try {
                        dataDao.deleteBook(id);
                        session.setAttribute("successMessage", "Xóa sách thành công!");
                    } catch (ClassNotFoundException e) {
                        session.setAttribute("errorMessage", "Lỗi khi xóa sách: " + e.getMessage());
                    }
                    response.sendRedirect(request.getContextPath() + "/data?table=books");
            }

            
            default -> {
                response.sendRedirect(request.getContextPath() + "/admin.jsp");

            }
        }
            
    }

    @Override
        @SuppressWarnings("UseSpecificCatch")
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");

        if ("add".equals(action)) {
            String book_name = CapitalizeUtil.capitalize(request.getParameter("book_name").trim());
            String author = CapitalizeUtil.capitalize(request.getParameter("author").trim());
            Part image_url= request.getPart("image_url");
            int category_id = Integer.parseInt(request.getParameter("category_id"));
            int book_page;
            int publicyear;
            int quantity;
            Double selling_price;

            try {
                book_page = Integer.parseInt(request.getParameter("book_page"));
            } catch (NumberFormatException e) {
                book_page = 0;
            }
            try {
                publicyear = Integer.parseInt(request.getParameter("publicyear"));
            } catch (NumberFormatException e) {
                publicyear = 0;
            }
            try {
                quantity = Integer.parseInt(request.getParameter("quantity"));
            } catch (NumberFormatException e) {
                quantity = 0;
            }
            try {
                selling_price = Double.valueOf(request.getParameter("selling_price"));
            } catch (NumberFormatException e) {
                selling_price = 0.0;
            }

            //nếu không có ảnh
            if (image_url == null || image_url.getSubmittedFileName() == null
                    || image_url.getSubmittedFileName().trim().isEmpty()) {

                HttpSession session = request.getSession();

                session.setAttribute("error",
                    "Vui lòng chọn ảnh trước khi thêm sách.");

                // Lưu lại các dữ liệu khác
                session.setAttribute("book_name", book_name);
                session.setAttribute("author", author);
                session.setAttribute("category_id", category_id);
                session.setAttribute("book_page", book_page);
                session.setAttribute("publicyear", publicyear);
                session.setAttribute("quantity", quantity);
                session.setAttribute("selling_price", selling_price);

                response.sendRedirect(request.getContextPath() + "/data?table=books");
                return;
            }


            // Kiểm tra sách đã tồn tại
            try {
                if (dataDao.existsBook(book_name, author)) {
                    HttpSession session = request.getSession();

                    session.setAttribute("error",
                            "Sách \"" + book_name + "\" của tác giả \"" + author + "\" đã tồn tại!");

                    session.setAttribute("book_name", book_name);
                    session.setAttribute("author", author);
                    session.setAttribute("category_id", category_id);
                    session.setAttribute("book_page", book_page);
                    session.setAttribute("publicyear", publicyear);
                    session.setAttribute("quantity", quantity);
                    session.setAttribute("selling_price", selling_price);

                    response.sendRedirect(request.getContextPath() + "/data?table=books");
                    return;
                }
            } catch (ClassNotFoundException e) {
                throw new ServletException(e);
            }

            // Lưu ảnh vào folder
            String uploadPath = DBConfig.get("upload.path");
            String fileName = Paths.get(image_url.getSubmittedFileName()).getFileName().toString();
            File folder = new File(uploadPath);
            if (!folder.exists()) {
                folder.mkdirs();
            }
            image_url.write(uploadPath + File.separator + fileName);
            
            categories category = null;
            try {
                category = dataDao.getCategoryById(category_id);
            } catch (ClassNotFoundException e) {
                System.out.println("Lỗi");
            }

            if (category == null) {
                throw new ServletException("Không tìm thấy thể loại với id = " + category_id);
            }
            
            if (publicyear < 1800 || publicyear > java.time.Year.now().getValue()) {
                HttpSession session = request.getSession();
                session.setAttribute("error","Năm xuất bản không hợp lệ!");
                session.setAttribute("book_name", book_name);
                session.setAttribute("author", author);
                session.setAttribute("category_id", category_id);
                session.setAttribute("book_page", book_page);
                session.setAttribute("publicyear", publicyear);
                session.setAttribute("quantity", quantity);
                session.setAttribute("selling_price", selling_price);

                response.sendRedirect(request.getContextPath() + "/data?table=books");
                return;
            }
            
            books book = new books();
            book.setImageUrl(fileName);
            book.setBookName(book_name);
            book.setAuthor(author);
            book.setCategory_id(category_id);
            book.setCategory(category.getCategoryName());
            book.setBookPage(book_page);
            book.setPublicYear(publicyear);
            book.setQuantity(quantity);
            book.setSellingPrice(selling_price);

            try {
                dataDao.addBook(book);
                HttpSession session = request.getSession();

                session.removeAttribute("error");
                session.removeAttribute("book_name");
                session.removeAttribute("author");
                session.removeAttribute("category_id");
                session.removeAttribute("book_page");
                session.removeAttribute("publicyear");
                session.removeAttribute("quantity");
                session.removeAttribute("selling_price");
                session.setAttribute("successMessage", "Thêm sách thành công!");
                response.sendRedirect(request.getContextPath() + "/data?table=books");
            } catch (ClassNotFoundException e) {
                HttpSession session = request.getSession();
                session.setAttribute("errorMessage", "Lỗi khi thêm sách: " + e.getMessage());
                response.sendRedirect(request.getContextPath() + "/data?table=books");
            }

        } else if ("edit".equals(action)) {

            // Update book
            Part image_url= request.getPart("image_url");
            String fileName;
            String uploadPath = DBConfig.get("upload.path");
            File folder = new File(uploadPath);

            if (!folder.exists()) {
                folder.mkdirs();
            }
            int id = Integer.parseInt(request.getParameter("id"));
            String book_name = CapitalizeUtil.capitalize(request.getParameter("book_name"));
            String author = CapitalizeUtil.capitalize(request.getParameter("author"));
            int category_id = Integer.parseInt(request.getParameter("category_id"));
            categories category = null;

            try {
                category = dataDao.getCategoryById(category_id);
            } catch (ClassNotFoundException e) {
                throw new ServletException(e);
            }
            if (category == null) {
                throw new ServletException("Không tìm thấy thể loại với id = " + category_id);
            }
            int book_page;
            int publicyear;
            int quantity;
            Double selling_price;

            try {
                book_page = Integer.parseInt(request.getParameter("book_page"));
            } catch (NumberFormatException e) {
                book_page = 0;
            }
            try {
                publicyear = Integer.parseInt(request.getParameter("publicyear"));
            } catch (NumberFormatException e) {
                publicyear = 0;
            }
            try {
                quantity = Integer.parseInt(request.getParameter("quantity"));
            } catch (NumberFormatException e) {
                quantity = 0;
            }
            try {
                selling_price = Double.valueOf(request.getParameter("selling_price"));
            } catch (NumberFormatException e) {
                selling_price = 0.0;
            }

            // Kiểm tra năm xuất bản hợp lệ
            if (publicyear < 1800 || publicyear > java.time.Year.now().getValue()) {
                HttpSession session = request.getSession();
                session.setAttribute("editBookId", id);
                session.setAttribute("editBookName", book_name);
                session.setAttribute("editAuthor", author);
                session.setAttribute("editCategoryId", category_id);
                session.setAttribute("editBookPage", book_page);
                session.setAttribute("editPublicYear", publicyear);
                session.setAttribute("editQuantity", quantity);
                session.setAttribute("editSellingPrice", selling_price);
                session.setAttribute("editImage", image_url != null && image_url.getSize() > 0 ? image_url.getSubmittedFileName() : "");
                session.setAttribute("editError", "Năm xuất bản không hợp lệ!");
                response.sendRedirect(request.getContextPath() + "/data?table=books");
                return;
            }

            // Kiểm tra sách đã tồn tại (loại trừ sách hiện tại)
            try {
                if (dataDao.existsBook(book_name, author, id)) {
                    HttpSession session = request.getSession();
                    session.setAttribute("editBookId", id);
                    session.setAttribute("editBookName", book_name);
                    session.setAttribute("editAuthor", author);
                    session.setAttribute("editCategoryId", category_id);
                    session.setAttribute("editBookPage", book_page);
                    session.setAttribute("editPublicYear", publicyear);
                    session.setAttribute("editQuantity", quantity);
                    session.setAttribute("editSellingPrice", selling_price);
                    session.setAttribute("editImage", image_url != null && image_url.getSize() > 0 ? image_url.getSubmittedFileName() : "");
                    session.setAttribute("editError", "Sách \"" + book_name + "\" của tác giả \"" + author + "\" đã tồn tại!");
                    response.sendRedirect(request.getContextPath() + "/data?table=books");
                    return;
                }
            } catch (Exception e) {
                throw new ServletException(e);
            }

            books oldBook = null;
            if (image_url != null && image_url.getSize() > 0) {

                fileName = Paths.get(image_url.getSubmittedFileName()).getFileName().toString();

                image_url.write(uploadPath + File.separator + fileName);

            } else {
                try {
                    oldBook = dataDao.getBookById(id);
                } catch (ClassNotFoundException e) {
                    throw new ServletException(e);
                }
                if (oldBook == null) {
                    throw new ServletException("Không tìm thấy sách.");
                }
                fileName = oldBook.getImageUrl();

            }

            books book = new books();
            book.setBook_id(id);
            book.setImageUrl(fileName);
            book.setBookName(book_name);
            book.setAuthor(author);
            book.setCategory_id(category_id);
            book.setCategory(category.getCategoryName());
            book.setBookPage(book_page);
            book.setPublicYear(publicyear);
            book.setQuantity(quantity);
            book.setSellingPrice(selling_price);

            try {
                dataDao.updateBook(book);
                HttpSession session = request.getSession();
                session.setAttribute("successMessage", "Cập nhật sách thành công!");
                response.sendRedirect(request.getContextPath() + "/data?table=books");
            } catch (ClassNotFoundException e) {
                HttpSession session = request.getSession();
                session.setAttribute("errorMessage", "Lỗi khi cập nhật sách: " + e.getMessage());
                response.sendRedirect(request.getContextPath() + "/data?table=books");
            }
        }
    }
}
