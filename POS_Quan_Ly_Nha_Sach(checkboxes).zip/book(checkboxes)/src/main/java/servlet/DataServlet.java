package servlet;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.DataDao;
import database.InvoiceDAO;
import structure.Invoice;
import structure.books;
import structure.categories;
import structure.login;
import structure.schedule;

@WebServlet("/data")
public class DataServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DataDao dataDao;
    private static final int PAGE_SIZE = 10;

    @Override
    public void init() {
        this.dataDao = new DataDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    String table = request.getParameter("table");

    if (table == null) {
        response.sendRedirect(request.getContextPath() + "/data?table=invoice");
        return;
    }

    // Xử lý xóa hóa đơn (Quản lý hóa đơn)
    String action = request.getParameter("action");
    if ("invoices".equals(table) && "delete".equals(action)) {
        String idParam = request.getParameter("id");
        HttpSession session = request.getSession();
        if (idParam != null && !idParam.trim().isEmpty()) {
            try {
                int id = Integer.parseInt(idParam.trim());
                InvoiceDAO invoiceDAO = new InvoiceDAO();
                boolean deleted = invoiceDAO.deleteInvoice(id);
                if (deleted) {
                    session.setAttribute("successMessage", "Xóa hóa đơn thành công!");
                } else {
                    session.setAttribute("errorMessage", "Không tìm thấy hóa đơn để xóa.");
                }

            } catch (ClassNotFoundException | RuntimeException e) {
                session.setAttribute("errorMessage", "Lỗi xóa hóa đơn: " + e.getMessage());
            }
        }
        // Sau khi xóa, quay lại trang hiện tại hoặc trang 1
        String redirectPage = request.getParameter("page");
        if (redirectPage == null || redirectPage.trim().isEmpty()) {
            redirectPage = "1";
        }
        String employeeName = request.getParameter("employeeName");
        try {
            int page = Integer.parseInt(redirectPage);
            if (page < 1) page = 1;
            int offset = (page - 1) * PAGE_SIZE;
            List<Invoice> invoices;
            int totalInvoices;
            if (employeeName != null && !employeeName.trim().isEmpty()) {
                invoices = dataDao.getAllInvoices(employeeName, offset, PAGE_SIZE);
                totalInvoices = dataDao.countInvoicesByEmployee(employeeName);
            } else {
                invoices = dataDao.getAllInvoices(offset, PAGE_SIZE);
                totalInvoices = dataDao.countAllInvoices();
            }
            int totalPages = (int) Math.ceil((double) totalInvoices / PAGE_SIZE);
            request.setAttribute("tableName", "invoices");
            request.setAttribute("invoices", invoices);
            request.setAttribute("currentPage", page);
            request.setAttribute("totalPages", totalPages);
            request.setAttribute("totalInvoices", totalInvoices);
            request.setAttribute("employeeName", employeeName);
            response.sendRedirect(request.getContextPath() + "/data?table=invoices");
            return;
        } catch (NumberFormatException | ClassNotFoundException e) {
            session.setAttribute("errorMessage", "Lỗi kết nối database");
            response.sendRedirect(request.getContextPath() + "/data?table=invoices");
            return;
        }
    }

    try {
        switch (table) {
            case "books" ->  {
                List<books> books = dataDao.getAllBooks();
                List<categories> categoryList = dataDao.getAllCategoriesWithBookCount();

                request.setAttribute("tableName", "books");
                request.setAttribute("categoryList", categoryList);
                request.setAttribute("books", books);
            }

            case "employees" ->  {
                List<login> employees = dataDao.getAllEmployees();
                request.setAttribute("tableName", "employees");
                request.setAttribute("employees", employees);
                String scheduleId = request.getParameter("schedule");

                if (scheduleId != null && !scheduleId.isEmpty()) {

                    int employeeId = Integer.parseInt(scheduleId);

                    List<schedule> schedules =
                            dataDao.getScheduleByEmployeeId(employeeId);

                    Map<String, String> weekSchedule = new LinkedHashMap<>();

                    String[] days = {
                        "T2","T3","T4","T5","T6","T7","CN"
                    };

                    for (String day : days) {
                        weekSchedule.put(day, "-");
                    }

                    for (schedule s : schedules) {

                        String current = weekSchedule.get(s.getDayOfWeek());

                        if ("-".equals(current)) {
                            weekSchedule.put(s.getDayOfWeek(), s.getShift());
                        } else if (!current.equals(s.getShift())) {
                            weekSchedule.put(s.getDayOfWeek(), "Cả ngày");
                        }
                    }

                    request.setAttribute("weekSchedule", weekSchedule);
                    request.setAttribute("showScheduleModal", true);
                }
            }

            case "invoices" ->  {
                // Pagination
                int page = 1;
                String pageParam = request.getParameter("page");
                if (pageParam != null && !pageParam.trim().isEmpty()) {
                    try {
                        page = Integer.parseInt(pageParam);
                        if (page < 1) page = 1;
                    } catch (NumberFormatException e) {
                        page = 1;
                    }
                }
                int offset = (page - 1) * PAGE_SIZE;

                String employeeName = request.getParameter("employeeName");
                List<Invoice> invoices;
                int totalInvoices;
                int totalPages;

                if (employeeName != null && !employeeName.trim().isEmpty()) {
                    invoices = dataDao.getAllInvoices(employeeName, offset, PAGE_SIZE);
                    totalInvoices = dataDao.countInvoicesByEmployee(employeeName);
                } else {
                    invoices = dataDao.getAllInvoices(offset, PAGE_SIZE);
                    totalInvoices = dataDao.countAllInvoices();
                }
                totalPages = (int) Math.ceil((double) totalInvoices / PAGE_SIZE);

                List<login> employees = dataDao.getAllEmployees();
                request.setAttribute("tableName", "invoices");
                request.setAttribute("invoices", invoices);
                request.setAttribute("employees", employees);
                request.setAttribute("employeeName", employeeName);
                request.setAttribute("currentPage", page);
                request.setAttribute("totalPages", totalPages);
                request.setAttribute("totalInvoices", totalInvoices);
            }

            default -> {
                response.sendRedirect(request.getContextPath() + "/admin.jsp");
                return;
            }
        }


        request.getRequestDispatcher("/admin.jsp").forward(request, response);

        } catch (ServletException | ClassNotFoundException e) {
            request.setAttribute("error", "Lỗi kết nối database");
            request.getRequestDispatcher("/admin.jsp").forward(request, response);
        }
    }

}
