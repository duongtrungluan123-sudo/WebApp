package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.DataDao;
import structure.login;
import util.CapitalizeUtil;

@WebServlet("/employees")
public class EmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DataDao dataDao;

    @Override
    public void init() {
        this.dataDao = new DataDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        switch (action) {
            case "add" -> {
                    HttpSession session = request.getSession();

                    try {
                        session.setAttribute(
                            "successMessage",
                            "Thêm nhân viên thành công!"
                        );

                    } catch (NumberFormatException e) {

                        session.setAttribute(
                            "errorMessage",
                            "ID nhân viên không hợp lệ!"
                        );

                    } catch (Exception e) {

                        session.setAttribute(
                            "errorMessage",
                            "Lỗi khi thêm nhân viên: " + e.getMessage()
                        );
                    }

                    response.sendRedirect(
                        request.getContextPath() + "/data?table=employees"
                    );
            }
                
            case "edit" -> {
                String idParam = request.getParameter("id");
                HttpSession session = request.getSession(); // Lấy session để lưu thông báo tạm thời
                login employee = null;
                try {
                    int id = Integer.parseInt(idParam);
                    employee = dataDao.getEmployeeById(id);
                    session.setAttribute("successMessage", "Cập nhật nhân viên thành công!");
                } catch (ClassNotFoundException ex) {
                    session.setAttribute("errorMessage", "Lỗi khi xóa nhân viên: " + ex.getMessage());
                }
                request.setAttribute("employee", employee);
                request.setAttribute("editMode", true);
                response.sendRedirect(request.getContextPath() + "/data?table=employees");
            }
                

            case "delete" -> {
                    String idParam = request.getParameter("id");
                    HttpSession session = request.getSession(); // Lấy session để lưu thông báo tạm thời
                    
                    try {
                        int id = Integer.parseInt(idParam);
                        dataDao.deleteEmployee(id);
                        session.setAttribute("successMessage", "Xóa nhân viên thành công!");
                    } catch (NumberFormatException e) {
                        session.setAttribute("errorMessage", "ID nhân viên không hợp lệ!");
                    } catch (ClassNotFoundException e) { // Bắt cả ClassNotFoundException hoặc SQLException từ DAO
                        session.setAttribute("errorMessage", "Lỗi khi xóa nhân viên: " + e.getMessage());
                    }
                    
                    // Dùng redirect an toàn
                    response.sendRedirect(request.getContextPath() + "/data?table=employees");
            }

            
            default -> {
                response.sendRedirect(request.getContextPath() + "/admin.jsp");

            }
        }
            
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");

        if ("add".equals(action)) {
            // Add new employee
            String username = CapitalizeUtil.capitalize(request.getParameter("username"));
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String password = request.getParameter("password");
            String role = request.getParameter("role");
            
            try {
                if (dataDao.isPhoneExists(phone)) {
                    HttpSession session = request.getSession();
                    session.setAttribute("employeeError", "Số điện thoại đã tồn tại!");
                    session.setAttribute("username", username);
                    session.setAttribute("email", email);
                    session.setAttribute("phone", phone);
                    session.setAttribute("password", password);

                    response.sendRedirect(request.getContextPath() + "/data?table=employees");
                    return;
                }
            } catch (ClassNotFoundException | SQLException e) {
                request.setAttribute("error", "Lỗi kết nối database");
                response.sendRedirect(request.getContextPath() + "/data?table=employees");
                return; 
            }

            if (phone != null && phone.trim().length() > 10) {
                // Lưu thông báo lỗi vào session giống như mẫu Thêm Sách
                HttpSession session = request.getSession();
                session.setAttribute("employeeError", "Số điện thoại không được vượt quá 10 chữ số!");
                session.setAttribute("username", username);
                session.setAttribute("email", email);
                session.setAttribute("phone", phone);
                session.setAttribute("password", password);

                // Redirect về lại trang quản lý nhân viên
                response.sendRedirect(request.getContextPath() + "/data?table=employees");
                return; 
            }

            login employee = new login();
            employee.setUsername(username);
            employee.setEmail(email);
            employee.setPhone(phone);
            employee.setPassword(password);
            employee.setRole(role);

            try {
                int employeeId = dataDao.addEmployee(employee);
                HttpSession session = request.getSession();
                session.removeAttribute("employeeError");
                session.removeAttribute("username");
                session.removeAttribute("phone");
                session.removeAttribute("password");

                if (employeeId <= 0) {
                    throw new ServletException("Không thể tạo nhân viên.");
                }
                session.setAttribute("successMessage", "Thêm nhân viên thành công!");
                response.sendRedirect(request.getContextPath() + "/data?table=employees");
            } catch (ClassNotFoundException e) {
                HttpSession session = request.getSession();
                session.setAttribute("errorMessage", "Lỗi khi thêm nhân viên: " + e.getMessage());
                response.sendRedirect(request.getContextPath() + "/data?table=employees");
            }

        } else if ("edit".equals(action)) {
            // Update employee
            int id = Integer.parseInt(request.getParameter("id"));
            String username = request.getParameter("username");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String password = request.getParameter("password");
            String role = request.getParameter("role");
            
            if (phone != null && phone.trim().length() > 10) {
                HttpSession session = request.getSession();
                session.setAttribute("employeeEditError", "Số điện thoại không được vượt quá 10 chữ số!");
                session.setAttribute("editid", id);
                session.setAttribute("editusername", username);
                session.setAttribute("editemail", email);
                session.setAttribute("editphone", phone);
                session.setAttribute("editpassword", password);
                
                // Redirect về lại trang quản lý nhân viên
                response.sendRedirect(request.getContextPath() + "/data?table=employees");
                return; // Dừng luồng chạy tại đây, không xuống db
            }

            login employee = new login();
            employee.setId(id);
            employee.setUsername(username);
            employee.setEmail(email);
            employee.setPhone(phone);
            employee.setPassword(password);
            employee.setRole(role);

            try {
                dataDao.updateEmployee(employee);
                HttpSession session = request.getSession();
                session.removeAttribute("editid");
                session.removeAttribute("employeeEditError");
                session.removeAttribute("editusername");
                session.removeAttribute("editphone");
                session.removeAttribute("editpassword");
                session.setAttribute("successMessage", "Cập nhật nhân viên thành công!");
            } catch (ClassNotFoundException e) {
                HttpSession session = request.getSession();
                session.setAttribute("errorMessage", "Lỗi khi cập nhật nhân viên: " + e.getMessage());
            }
            response.sendRedirect(request.getContextPath() + "/data?table=employees");
        }
    }

}