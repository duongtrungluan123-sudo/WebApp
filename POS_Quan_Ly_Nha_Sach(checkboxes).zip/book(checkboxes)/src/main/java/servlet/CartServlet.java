package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.DataDao;
import structure.books;
import structure.categories;
import util.ShiftUtil;

@WebServlet("/createCart")
public class CartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private DataDao dataDao;

    @Override
    public void init() {
        this.dataDao = new DataDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //kiểm tra đăng nhập
        HttpSession session = request.getSession();
        structure.login user = (structure.login) session.getAttribute("user");

        // Bắt buộc kiểm tra Session ngay tại Servlet
        if (user == null) {
            session.setAttribute("error", "Vui lòng đăng nhập");
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return; // Dừng ngay lập tức, không query DB hay forward
        }
        
        String shiftLabel = ShiftUtil.currentShiftLabel();
        try {
            List<books> bookList = dataDao.getAllBooks();
            List<categories> categoryList = dataDao.getAllCategories();
            request.setAttribute("books", bookList);
            request.setAttribute("categoryList", categoryList);
            request.setAttribute("shiftLabel", shiftLabel);
            request.getRequestDispatcher("/createCart.jsp").forward(request, response);
        } catch (ClassNotFoundException | RuntimeException e) {
            request.setAttribute("error", "Lỗi kết nối database: " + e.getMessage());
            request.setAttribute("shiftLabel", shiftLabel);
            request.getRequestDispatcher("/createCart.jsp").forward(request, response);
        }
    }
}
