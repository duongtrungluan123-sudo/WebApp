package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.DataDao;
import database.InvoiceDAO;
import structure.Invoice;
import structure.InvoiceDetail;
import structure.books;
import structure.login;
import util.CapitalizeUtil;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private DataDao dataDao;
    private InvoiceDAO invoiceDAO;

    @Override
    public void init() {
        this.dataDao = new DataDao();
        this.invoiceDAO = new InvoiceDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json; charset=UTF-8");
        PrintWriter out = response.getWriter();

        String paymentRaw = request.getParameter("paymentMethod");
        String bookIds = request.getParameter("bookIds");
        String quantities = request.getParameter("quantities");
        String customerName = CapitalizeUtil.capitalize(request.getParameter("customerName"));
        String customerPhone = request.getParameter("customerPhone");
        String paymentMethod = "Tiền mặt".equals(paymentRaw) ? "Tiền mặt" : "Chuyển khoản";

        if (customerPhone != null) {
            customerPhone = customerPhone.trim();

            if (!customerPhone.isEmpty() && !customerPhone.matches("\\d{10}")) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"error\":\"Số điện thoại khách hàng phải gồm đúng 10 chữ số.\"}");
                return;
            }
        }
        
        try {
            if (bookIds == null || bookIds.isBlank()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"error\":\"Giỏ hàng đang trống.\"}");
                return;
            }

            String[] idArr = bookIds.split(",");
            String[] qtyArr = quantities != null ? quantities.split(",") : new String[0];

            List<InvoiceDetail> details = new ArrayList<>();
            double total = 0;

            for (int i = 0; i < idArr.length; i++) {
                int bookId = Integer.parseInt(idArr[i].trim());
                int qty = (i < qtyArr.length) ? Integer.parseInt(qtyArr[i].trim()) : 1;
                if (qty <= 0) {
                    continue;
                }

                books b = dataDao.getBookById(bookId);
                if (b == null) {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    out.print("{\"error\":\"Sách mã " + bookId + " không tồn tại.\"}");
                    return;
                }
                if (b.getQuantity() < qty) {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    out.print("{\"error\":\"Sách '" + b.getBookName() + "' chỉ còn " + b.getQuantity() + " trong kho.\"}");
                    return;
                }

                InvoiceDetail d = new InvoiceDetail();
                d.setBookId(bookId);
                d.setBookName(b.getBookName());
                d.setQuantity(qty);
                d.setUnitPrice(b.getSellingPrice());
                d.setTotalPrice(b.getSellingPrice() * qty);
                details.add(d);
                total += b.getSellingPrice() * qty;
            }

            if (details.isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"error\":\"Giỏ hàng đang trống.\"}");
                return;
            }

            Invoice invoice = new Invoice();
            invoice.setInvoiceDate(new Timestamp(System.currentTimeMillis()));
            invoice.setTotalAmount(total);
            invoice.setPaymentMethod(paymentMethod);
            invoice.setStatus("completed");

            String employeeName = "";
            HttpSession session = request.getSession(false);
            if (session != null) {
                login user = (login) session.getAttribute("user");
                if (user != null && user.getUsername() != null) {
                    employeeName = user.getUsername();
                }
            }
            invoice.setEmployeeName(employeeName);
            invoice.setCustomerName(customerName != null ? customerName.trim() : "");
            invoice.setCustomerPhone(customerPhone != null ? customerPhone.trim() : "");

            int invoiceId = invoiceDAO.createInvoice(invoice, details);
            out.print("{\"invoiceId\":" + invoiceId + "}");

        } catch (ClassNotFoundException | NumberFormatException | SQLException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\":\"Lỗi khi thanh toán: " + e.getMessage() + "\"}");
        }
    }
}
