package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.forgetDao;

@WebServlet("/forget")
public class forgetServlet extends HttpServlet {
   private forgetDao forgetDb;

   @Override
   public void init() {
      this.forgetDb = new forgetDao();
   }

   @Override
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      String phone = request.getParameter("phone");
      String newpassword = request.getParameter("newpassword");
      String confirmpassword = request.getParameter("confirmpassword");
      if (!newpassword.equals(confirmpassword)) {
         request.setAttribute("error", "Confirm password does not match");
         request.getRequestDispatcher("forget.jsp").forward(request, response);
      }

      try {
         boolean status = this.forgetDb.resetPassword(phone, newpassword);
         if (status) {
            response.sendRedirect("index.jsp");
         } else {
            request.setAttribute("error", "Phone does not exist.");
            request.getRequestDispatcher("forget.jsp").forward(request, response);
         }
      } catch (ClassNotFoundException e) {
         System.out.println("Không thể lưu dữ liệu!" + e.getMessage());
      }

   }
}
