package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.InvoiceDAO;
import structure.Invoice;
import structure.login;
import util.ShiftUtil;

@WebServlet("/history")
public class HistoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private InvoiceDAO invoiceDAO;
    private static final int PAGE_SIZE = 10;

    @Override
    public void init() {
        this.invoiceDAO = new InvoiceDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        login user = (session != null) ? (login) session.getAttribute("user") : null;

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }
        String employeeName = user.getUsername();
        if (employeeName == null || employeeName.isBlank()) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }
        String shiftLabel = ShiftUtil.currentShiftLabel();

        // Pagination
        int page = 1;
        String pageParam = request.getParameter("page");
        if (pageParam != null && !pageParam.trim().isEmpty()) {
            try {
                page = Integer.parseInt(pageParam);
                if (page < 1) page = 1;
            } catch (NumberFormatException e) {
                page = 1;
            }
        }
        int offset = (page - 1) * PAGE_SIZE;

        try {
            List<Invoice> invoices = invoiceDAO.getInvoicesByEmployee(employeeName, offset, PAGE_SIZE);
            int totalInvoices = invoiceDAO.countInvoicesByEmployee(employeeName);
            int totalPages = (int) Math.ceil((double) totalInvoices / PAGE_SIZE);

            request.setAttribute("invoices", invoices);
            request.setAttribute("shiftLabel", shiftLabel);
            request.setAttribute("currentPage", page);
            request.setAttribute("totalPages", totalPages);
            request.setAttribute("totalInvoices", totalInvoices);
            request.getRequestDispatcher("/viewHistory.jsp").forward(request, response);
        }
        catch (ClassNotFoundException | SQLException e) {
            request.setAttribute("error", "Lỗi kết nối database: " + e.getMessage());
            request.setAttribute("shiftLabel", shiftLabel);
            request.getRequestDispatcher("/viewHistory.jsp").forward(request, response);
        }
    }
}
