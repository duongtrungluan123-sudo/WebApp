package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.DataDao;
import structure.categories;
import util.CapitalizeUtil;

@MultipartConfig
@WebServlet("/categories")
public class CategoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DataDao dataDao;

    @Override
    public void init() {
        this.dataDao = new DataDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Delegate to doPost for simplicity (or implement GET logic separately)
        doPost(request, response);
    }

    @Override
    @SuppressWarnings("UseSpecificCatch")
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");

        PrintWriter out = response.getWriter();

        Map<String, Object> result = new HashMap<>();
        
        
        if (action == null) {
            result.put("success", false);
            result.put("message", "Action bị null");
            out.print(toJson(result));
            return;
        }

        try {
            switch (action) {
                case "addCategory" -> {
                    String categoryName = CapitalizeUtil.capitalize(request.getParameter("categoryName"));
                    if (categoryName == null || categoryName.trim().isEmpty()) {
                        result.put("success", false);
                        result.put("message", "Tên thể loại không được để trống!");
                    } else {
                        try {
                            int newId = dataDao.getCategoryByName(categoryName.trim());

                            // 2. Kiểm tra xem ID lấy lên có hợp lệ không (ID trong CSDL luôn > 0)
                            if (newId > 0) {
                                categories newCategory = dataDao.getCategory(newId);
                                
                                result.put("success", true);
                                result.put("message", "Thêm thể loại thành công!");
                                
                                Map<String, Object> catMap = new HashMap<>();
                                catMap.put("id", newId); // ID chuẩn từ DB
                                
                                // Đề phòng hàm getCategory bị lỗi trả về null, ta dùng data mặc định
                                if (newCategory != null) {
                                    catMap.put("categoryName", newCategory.getCategoryName());
                                    catMap.put("totalbook", newCategory.getTotalbook());
                                } else {
                                    catMap.put("categoryName", categoryName.trim());
                                    catMap.put("totalbook", 0);
                                }
                                
                                result.put("category", catMap);
                                
                            } else {
                                // 3. Xử lý khi Insert thành công nhưng không lấy được ID (newId = -1)
                                // Trả về false để UI không render ra dòng dữ liệu có ID = -1
                                result.put("success", false);
                                result.put("message", "Thêm thể loại thất bại!");
                            }
                            
                        } catch (RuntimeException e) {
                            // Bắt lỗi trùng tên thể loại hoặc lỗi DB khác
                            String msg = e.getMessage();
                            if (msg != null && msg.toLowerCase().contains("duplicate")) {
                                result.put("success", false);
                                result.put("message", "Thể loại \"" + categoryName.trim() + "\" đã tồn tại trong hệ thống!");
                            } else {
                                result.put("success", false);
                                result.put("message", "Lỗi khi thêm thể loại: " + e.getMessage());
                            }
                        }
                    }
                }

                case "editCategory" ->{
                    String idParam = request.getParameter("id");
                    if (idParam == null || idParam.trim().isEmpty()) {
                        result.put("success", false);
                        result.put("message", "ID thể loại không hợp lệ!");
                    } else {
                        try {
                            int id = Integer.parseInt(idParam.trim());
                            String categoryName = request.getParameter("categoryName");

                            boolean isSuccess = dataDao.updateCategoryById(id, categoryName);

                            if (isSuccess) {
                                result.put("success", true);
                                result.put("message", "Cập nhật thể loại thành công!");
                                result.put("categoryName", categoryName.trim());
                            } else {
                                result.put("success", false);
                                result.put("message", "Tên thể loại không hợp lệ hoặc cập nhật thất bại!");
                            }
                        } catch (NumberFormatException e) {
                            result.put("success", false);
                            result.put("message", "ID thể loại không hợp lệ!");
                        }
                    }
                }

                case "deleteCategory" -> {
                    String idParam = request.getParameter("id");
                    if (idParam == null || idParam.trim().isEmpty()) {
                        result.put("success", false);
                        result.put("message", "ID thể loại không hợp lệ!");
                    } else {
                        try {
                            int id = Integer.parseInt(idParam.trim());
                            // Kiểm tra số sách trước khi xóa
                            categories cat = dataDao.getCategory(id);
                            if (cat != null && cat.getTotalbook() > 0) {
                                result.put("success", false);
                                result.put("message", "Không thể xóa thể loại đang được sử dụng!");
                            } else {
                                boolean deleted = dataDao.deleteCategory(id);
                                if (deleted) {
                                    result.put("success", true);
                                    result.put("message", "Xóa thể loại thành công!");
                                } else {
                                    result.put("success", false);
                                    result.put("message", "Xóa thể loại thất bại!");
                                }
                            }
                        } catch (NumberFormatException e) {
                            result.put("success", false);
                            result.put("message", "ID thể loại không hợp lệ!");
                        }
                    }
                }
                default -> {
                    result.put("success", false);
                    result.put("message", "Hành động không hợp lệ!");
                }
            }
        } catch (ClassNotFoundException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            result.put("success", false);
            result.put("message", "Lỗi server: " + e.getMessage());
        } catch (RuntimeException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);

            Throwable cause = e.getCause();

            result.put("success", false);
            result.put(
                "message",
                cause != null ? cause.getMessage() : e.getMessage()
            );
            
        } catch (Exception e) {
            // Catch-all for any unexpected exceptions
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            result.put("success", false);
            result.put("message", "Lỗi server không xác định: " + e.getMessage());
        }

        // Manual JSON serialization
        out.print(toJson(result));
        out.flush();
    }

    // Simple JSON serialization for Map<String, Object>
    private String toJson(Map<String, Object> map) {
        StringBuilder json = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (!first) json.append(",");
            json.append("\"").append(escapeJson(entry.getKey())).append("\":");
            json.append(toJsonValue(entry.getValue()));
            first = false;
        }
        json.append("}");
        return json.toString();
    }

    @SuppressWarnings("unchecked")
    private String toJsonValue(Object value) {
        if (value == null) {
            return "null";
        } else if (value instanceof String string) {
            return "\"" + escapeJson(string) + "\"";
        } else if (value instanceof Number || value instanceof Boolean) {
            return value.toString();
        } else if (value instanceof Map) {
            return toJson((Map<String, Object>) value);
        } else {
            return "\"" + escapeJson(value.toString()) + "\"";
        }
    }

    private String escapeJson(String str) {
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
}