package servlet;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import config.DBConfig;
import database.InvoiceDAO;
import structure.Invoice;
import structure.InvoiceDetail;

@WebServlet("/invoice/pdf")
public class PdfServlet extends HttpServlet {

    /* ---- Brand palette (matches webapp: secondary #2b1c15, third #dcb37b) ---- */
    private static final Color BROWN = new Color(0x2b, 0x1c, 0x15);
    private static final Color GOLD = new Color(0xdc, 0xb3, 0x7b);
    private static final Color CREAM = new Color(0xfa, 0xf6, 0xee);
    private static final Color TEXT_DARK = new Color(0x2e, 0x28, 0x20);
    private static final Color TEXT_MUTED = new Color(0x8c, 0x83, 0x75);
    private static final Color WHITE = Color.WHITE;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        InvoiceDAO invoiceDAO = new InvoiceDAO();
        List<InvoiceDetail> details;
        int invoiceId = Integer.parseInt(request.getParameter("invoiceId"));
        
        Invoice invoice;
        try {
            invoice = invoiceDAO.getInvoiceById(invoiceId);
            details = invoiceDAO.getInvoiceDetails(invoiceId);
        } catch (SQLException | ClassNotFoundException ex) {
            throw new ServletException("Không lấy được hóa đơn", ex);
        }

        BaseFont bf = BaseFont.createFont(
                "C:/Windows/Fonts/arial.ttf",
                BaseFont.IDENTITY_H,
                BaseFont.EMBEDDED);

        /* ---- Fonts ---- */
        Font fBrand = new Font(bf, 22, Font.BOLD, GOLD);
        Font fTitle = new Font(bf, 22, Font.BOLD, BROWN);
        Font fTitleSub = new Font(bf, 9, Font.NORMAL, TEXT_MUTED);
        Font fLabel = new Font(bf, 9, Font.NORMAL, TEXT_MUTED);
        Font fValue = new Font(bf, 10, Font.NORMAL, TEXT_DARK);
        Font fValueBold = new Font(bf, 10, Font.BOLD, TEXT_DARK);
        Font fInfoTitle = new Font(bf, 11, Font.BOLD, BROWN);
        Font fTh = new Font(bf, 10, Font.BOLD, WHITE);
        Font fTd = new Font(bf, 10, Font.NORMAL, TEXT_DARK);
        Font fTdNum = new Font(bf, 10, Font.NORMAL, TEXT_DARK);
        Font fTotalLabel = new Font(bf, 11, Font.NORMAL, TEXT_MUTED);
        Font fTotalValue = new Font(bf, 17, Font.BOLD, BROWN);
        Font fFooter = new Font(bf, 9, Font.NORMAL, TEXT_MUTED);
        Font fFooterGold = new Font(bf, 11, Font.BOLD, GOLD);

        /* ---- Formatters ---- */
        DecimalFormat df = new DecimalFormat("#,##0");
        SimpleDateFormat dateFmt = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        SimpleDateFormat onlyDate = new SimpleDateFormat("dd/MM/yyyy");

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Document document = new Document(PageSize.A4, 38, 38, 38, 38);
        try {
            PdfWriter.getInstance(document, baos);
            document.open();

            /* ===== HEADER ===== */
            PdfPTable header = new PdfPTable(2);
            header.setWidthPercentage(100);
            header.setWidths(new float[]{1, 1});

            // Left: store brand
            PdfPCell brandCell = new PdfPCell();
            brandCell.setBorder(PdfPCell.NO_BORDER);
            brandCell.setPadding(0);
            brandCell.addElement(new Paragraph("NHÀ SÁCH MINH CHÂU", fBrand));
            header.addCell(brandCell);

            // Right: invoice title + meta (top-right aligned)
            PdfPCell titleCell = new PdfPCell();
            titleCell.setBorder(PdfPCell.NO_BORDER);
            titleCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
            titleCell.setPadding(0);
            Paragraph pTitle = new Paragraph("HÓA ĐƠN BÁN HÀNG", fTitle);
            pTitle.setAlignment(Element.ALIGN_RIGHT);
            titleCell.addElement(pTitle);
            Paragraph pMeta = new Paragraph(
                    "Mã: #" + invoice.getId() + "    |    Ngày: "
                            + dateFmt.format(invoice.getInvoiceDate()), fTitleSub);
            pMeta.setAlignment(Element.ALIGN_RIGHT);
            titleCell.addElement(pMeta);
            header.addCell(titleCell);
            document.add(header);

            // Gold divider band
            PdfPTable band = new PdfPTable(1);
            band.setWidthPercentage(100);
            band.setSpacingBefore(8);
            band.setSpacingAfter(12);
            PdfPCell bandCell = new PdfPCell();
            bandCell.setFixedHeight(3f);
            bandCell.setBorder(PdfPCell.NO_BORDER);
            bandCell.setBackgroundColor(GOLD);
            band.addCell(bandCell);
            document.add(band);

            /* ===== INFO CARDS (Customer / Transaction) ===== */
            PdfPTable info = new PdfPTable(2);
            info.setWidthPercentage(100);
            info.setWidths(new float[]{1, 1});
            info.setSpacingAfter(14);

            // Determine shift from invoice time (sáng 08:00-14:00, chiều 14:00-20:00)
            String shift = "chiều";
            java.sql.Timestamp invTs = invoice.getInvoiceDate();
            if (invTs != null) {
                int invHour = invTs.toLocalDateTime().getHour();
                shift = (invHour < 14) ? "sáng" : "chiều";
            }

            info.addCell(infoCard("THÔNG TIN KHÁCH HÀNG", new String[][]{
                    {"Tên khách hàng", invoice.getCustomerName() != null ? invoice.getCustomerName() : "-"},
                    {"Số điện thoại", invoice.getCustomerPhone() != null ? invoice.getCustomerPhone() : "-"},
                    {"Phương thức", invoice.getPaymentMethod() != null ? invoice.getPaymentMethod() : "-"}
            }, fInfoTitle, fLabel, fValue));

            info.addCell(infoCard("THÔNG TIN GIAO DỊCH", new String[][]{
                    {"Nhân viên", invoice.getEmployeeName() != null ? invoice.getEmployeeName() : "-"},
                    {"Ca làm việc", shift},
                    {"Ngày lập", onlyDate.format(invoice.getInvoiceDate())}
            }, fInfoTitle, fLabel, fValue));

            document.add(info);

            /* ===== ITEMS TABLE ===== */
            PdfPTable table = new PdfPTable(5);
            table.setWidthPercentage(100);
            table.setWidths(new float[]{0.8f, 4.6f, 0.8f, 2f, 2.4f});
            table.setSpacingAfter(12);

            // Header row (brown)
            String[] headers = {"STT", "Tên sách", "SL", "Đơn giá", "Thành tiền"};
            for (String h : headers) {
                PdfPCell th = new PdfPCell(new Phrase(h, fTh));
                th.setBackgroundColor(BROWN);
                th.setHorizontalAlignment(Element.ALIGN_CENTER);
                th.setVerticalAlignment(Element.ALIGN_MIDDLE);
                th.setPadding(8);
                if (h.equals("Tên sách")) {
                    th.setHorizontalAlignment(Element.ALIGN_LEFT);
                } else if (h.equals("Đơn giá") || h.equals("Thành tiền")) {
                    th.setHorizontalAlignment(Element.ALIGN_RIGHT);
                }
                table.addCell(th);
            }

            int stt = 1;
            int totalQuantity = 0;
            double totalMoney = 0;
            boolean zebra = false;

            for (InvoiceDetail d : details) {
                Color rowBg = zebra ? CREAM : WHITE;
                zebra = !zebra;

                table.addCell(cell(String.valueOf(stt++), fTd, Element.ALIGN_CENTER, rowBg, 7));
                table.addCell(cell(d.getBookName() != null ? d.getBookName() : "-", fTd, Element.ALIGN_LEFT, rowBg, 7));
                table.addCell(cell(String.valueOf(d.getQuantity()), fTdNum, Element.ALIGN_CENTER, rowBg, 7));
                table.addCell(cell(df.format(d.getUnitPrice()) + " đ", fTdNum, Element.ALIGN_RIGHT, rowBg, 7));
                table.addCell(cell(df.format(d.getTotalPrice()) + " đ", fTdNum, Element.ALIGN_RIGHT, rowBg, 7));

                totalQuantity += d.getQuantity();
                totalMoney += d.getTotalPrice();
            }

            // If invoice has no details (data gap), still show total from header
            if (details.isEmpty()) {
                totalMoney = invoice.getTotalAmount();
            }
            document.add(table);

            /* ===== TOTALS ===== */
            PdfPTable totals = new PdfPTable(2);
            totals.setWidthPercentage(100);
            totals.setWidths(new float[]{1, 1});

            PdfPCell spacer = new PdfPCell();
            spacer.setBorder(PdfPCell.NO_BORDER);
            totals.addCell(spacer);

            PdfPCell totalsCell = new PdfPCell();
            totalsCell.setPadding(0);

            totalsCell.setBorder(PdfPCell.NO_BORDER);

            Paragraph qLine = new Paragraph();
        
            qLine.add(new Phrase("Tổng số lượng:  ", fTotalLabel));
            qLine.add(new Phrase(String.valueOf(totalQuantity) + " quyển", fValueBold));
            qLine.setAlignment(Element.ALIGN_RIGHT);
            qLine.setSpacingAfter(6);
            totalsCell.addElement(qLine);

            // Emphasized grand total
            PdfPTable grandBox = new PdfPTable(1);
            grandBox.setWidthPercentage(100);
            PdfPCell grandCell = new PdfPCell();
            grandCell.setPadding(10);
            grandCell.setBorder(PdfPCell.TOP);
            grandCell.setBorderWidthTop(1f);
            grandCell.setBorderColorTop(GOLD);
            Paragraph g = new Paragraph();
            g.add(new Phrase("TỔNG THÀNH TIỀN", fTotalLabel));
            g.add(new Phrase("\n" + df.format(totalMoney) + " VNĐ", fTotalValue));
            g.setAlignment(Element.ALIGN_RIGHT);
            grandCell.addElement(g);
            grandBox.addCell(grandCell);
            totalsCell.addElement(grandBox);

            totals.addCell(totalsCell);
            document.add(totals);

            /* ===== FOOTER ===== */
            Paragraph thanks = new Paragraph("Cảm ơn Quý khách đã mua sách tại Nhà Sách Minh Châu!", fFooterGold);
            thanks.setAlignment(Element.ALIGN_CENTER);
            thanks.setSpacingBefore(22);
            document.add(thanks);

            Paragraph note = new Paragraph("Hóa đơn được tạo tự động vào " + dateFmt.format(invoice.getInvoiceDate()), fFooter);
            note.setAlignment(Element.ALIGN_CENTER);
            note.setSpacingBefore(4);
            document.add(note);

        } catch (DocumentException e) {
            throw new ServletException("Không thể tạo file PDF", e);
        } finally {
            try {
                document.close();
            } catch (DocumentException ignore) {
            }
        }

        byte[] pdfBytes = baos.toByteArray();

        // Gửi PDF về trình duyệt để preview (modal)
        response.setContentType("application/pdf");
        response.setHeader(
                "Content-Disposition",
                "inline; filename=invoice-" + invoiceId + ".pdf");
        response.setContentLength(pdfBytes.length);
        response.getOutputStream().write(pdfBytes);
        response.getOutputStream().flush();

        // Lưu file PDF vào thư mục invoice.folder (application.properties)
        String folder = DBConfig.get("invoice.folder");
        if (folder != null && !folder.trim().isEmpty()) {
            try {
                File dir = new File(folder.trim());
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                File outFile = new File(dir, "invoice-" + invoiceId + ".pdf");
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    fos.write(pdfBytes);
                }
            } catch (IOException e) {
                System.err.println("Không thể lưu file PDF vào " + folder + ": " + e.getMessage());
            }
        }
    }

    /* ---- Helpers ---- */

    private static PdfPCell cell(String text, Font font, int align, Color bg, float pad) {
        PdfPCell c = new PdfPCell(new Phrase(text, font));
        c.setHorizontalAlignment(align);
        c.setVerticalAlignment(Element.ALIGN_MIDDLE);
        c.setBackgroundColor(bg);
        c.setPadding(pad);
        return c;
    }

    private static PdfPCell infoCard(String title, String[][] rows,
                                    Font titleFont, Font labelFont, Font valueFont) {
        PdfPCell card = new PdfPCell();
        card.setBackgroundColor(CREAM);
        card.setBorderColor(GOLD);
        card.setBorderWidth(0.75f);
        card.setPadding(10);
        Paragraph t = new Paragraph(title, titleFont);
        t.setSpacingAfter(6);
        card.addElement(t);

        for (String[] row : rows) {
            Paragraph line = new Paragraph();
            line.add(new Phrase(row[0] + ":  ", labelFont));
            line.add(new Phrase(row[1], valueFont));
            line.setSpacingAfter(3);
            card.addElement(line);
        }
        return card;
    }
}
