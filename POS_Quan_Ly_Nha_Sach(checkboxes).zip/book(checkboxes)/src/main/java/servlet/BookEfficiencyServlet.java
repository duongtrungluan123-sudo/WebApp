package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.DataDao;
import structure.books;

@WebServlet("/book-efficiency")
public class BookEfficiencyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Ngưỡng tồn kho thấp
    private static final int LOW_STOCK_THRESHOLD = 10;

    private DataDao dataDao;

    @Override
    public void init() {
        this.dataDao = new DataDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            int totalTitles = dataDao.countBooks();
            int soldToday = dataDao.getSoldToday();
            int lowStockCount = dataDao.countLowStockBooks(LOW_STOCK_THRESHOLD);
            List<books> topSellers = dataDao.getTopSellers(3);
            List<books> lowStockBooks = dataDao.getLowStockBooks(LOW_STOCK_THRESHOLD);
            List<books> allBooks = dataDao.getAllBooks();

            // Tìm số bán cao nhất để tính độ rộng thanh tiến trình
            int maxSold = 0;
            for (books b : topSellers) {
                if (b.getSold() > maxSold) {
                    maxSold = b.getSold();
                }
            }

            request.setAttribute("totalTitles", totalTitles);
            request.setAttribute("soldToday", soldToday);
            request.setAttribute("lowStockCount", lowStockCount);
            request.setAttribute("topSellers", topSellers);
            request.setAttribute("lowStockBooks", lowStockBooks);
            request.setAttribute("allBooks", allBooks);
            request.setAttribute("maxSold", maxSold);
            request.setAttribute("lowStockThreshold", LOW_STOCK_THRESHOLD);

            request.getRequestDispatcher("/book_efficiency.jsp").forward(request, response);

        } catch (ClassNotFoundException | RuntimeException e) {
            request.setAttribute("error", "Lỗi kết nối database: " + e.getMessage());
            request.getRequestDispatcher("/book_efficiency.jsp").forward(request, response);
        }
    }
}
