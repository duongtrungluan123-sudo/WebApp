package servlet;

import java.io.IOException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.DataDao;
import structure.login;
import structure.schedule;
import util.ShiftUtil;

@MultipartConfig
@WebServlet("/viewSchedule")
public class ViewScheduleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DataDao dataDao;

    @Override
    public void init() {
        dataDao = new DataDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Check login
        login user = (login) request.getSession().getAttribute("user");
        if (user == null) {
            request.getSession().setAttribute("error", "Vui lòng đăng nhập");
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        String monthParam = request.getParameter("month");
        String employeeIdParam = request.getParameter("employeeId");

        YearMonth yearMonth;
        if (monthParam != null && !monthParam.isEmpty()) {
            String[] parts = monthParam.split("-");
            yearMonth = YearMonth.of(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]));
        } else {
            yearMonth = YearMonth.now();
        }

        int year = yearMonth.getYear();
        int month = yearMonth.getMonthValue();

        // Get all employees for filter dropdown
        try {
            List<login> employees = dataDao.getAllEmployees();
            request.setAttribute("employees", employees);

        } catch (ClassNotFoundException e) {
            throw new ServletException("Lỗi khi lấy danh sách nhân viên", e);
        }

        // Xác định employeeId để lấy lịch
        // Nếu là nhân viên thì chỉ xem được lịch của mình
        int targetEmployeeId = -1;
        String EmployeeName = "";
        if ("Quản Lý".equals(user.getRole())) {
            // Admin có thể xem lịch nhân viên khác qua tham số
            if (employeeIdParam != null && !employeeIdParam.isEmpty()) {
                try {
                    targetEmployeeId = Integer.parseInt(employeeIdParam);
                } catch (NumberFormatException e) {
                    targetEmployeeId = -1;
                }
            }

        } else {
            // Nhân viên chỉ xem được lịch của mình
            targetEmployeeId = user.getId();

            // Tự động xóa employeeIdParam để tránh filter sai
            employeeIdParam = String.valueOf(targetEmployeeId);
        }
        // Get schedule data if employee identified
        // If targetEmployeeId == -1 and user is admin (selected "Tất cả nhân viên"), get all schedules for the month
        boolean isAllEmployees = ("Quản Lý".equals(user.getRole()) && (employeeIdParam == null || employeeIdParam.isEmpty()));
        if (targetEmployeeId != -1 || isAllEmployees) {
            try {
                Map<String, List<schedule>> scheduleMap = new LinkedHashMap<>();

                if (targetEmployeeId != -1) {
                    // Get schedule for specific employee using getScheduleById

                    List<schedule> schedules = dataDao.getScheduleByEmployeeId(targetEmployeeId);

                    // Separate into dated and weekly schedules
                    List<schedule> datedSchedules = new ArrayList<>();
                    Map<String, String> weeklyRoutine = new java.util.HashMap<>();

                    for (schedule s : schedules) {
                        if (s.getWorkDate() != null) {
                            datedSchedules.add(s);
                            EmployeeName = datedSchedules.get(0).getEmployeeName();
                        } else if (s.getDayOfWeek() != null) {
                            weeklyRoutine.put(s.getDayOfWeek(), s.getShift());
                        }
                    }

                    // Group by work_date for the selected month
                    LocalDate startOfMonth = yearMonth.atDay(1);
                    int daysInMonth = yearMonth.lengthOfMonth();

                    for (int day = 1; day <= daysInMonth; day++) {
                        LocalDate current = startOfMonth.plusDays(day - 1);
                        String dateKey = current.toString();

                        int val = current.getDayOfWeek().getValue();
                        String mappedDay = (val == 7) ? "CN" : "T" + val;

                        // 1. Check for dated schedules on this specific day
                        List<schedule> daySchedules = new ArrayList<>();
                        for (schedule ds : datedSchedules) {
                            if (ds.getWorkDate() != null && ds.getWorkDate().toString().equals(dateKey)) {
                                daySchedules.add(ds);
                            }
                        }

                        if (!daySchedules.isEmpty()) {
                            scheduleMap.put(dateKey, daySchedules);
                        } else {
                            // 2. If no dated schedule, apply weekly routine
                            String weeklyShift = weeklyRoutine.get(mappedDay);
                            if (weeklyShift != null) {
                                schedule s = new schedule();
                                s.setWorkDate(java.sql.Date.valueOf(dateKey));
                                s.setDayOfWeek(mappedDay);
                                s.setShift(weeklyShift);
                                s.setEmployeeId(targetEmployeeId);
                                s.setEmployeeName(EmployeeName);
                                scheduleMap.put(dateKey, java.util.Collections.singletonList(s));
                            }
                        }
                    }
                    String shiftLabel = ShiftUtil.currentShiftLabel();
                    request.setAttribute("shiftLabel", shiftLabel);
                    request.setAttribute("selectedEmployeeId", targetEmployeeId);
                    request.setAttribute("EmployeeName", EmployeeName);

                } else {
                    // targetEmployeeId == -1 && admin: get ALL employees' schedules for the month
                    LocalDate startOfMonth = yearMonth.atDay(1);
                    LocalDate endOfMonth = yearMonth.atEndOfMonth();
                    String startDateStr = startOfMonth.toString();
                    String endDateStr = endOfMonth.toString();

                    List<schedule> allSchedules = dataDao.getAllSchedulesByDateRange(startDateStr, endDateStr);

                    // Group by date
                    for (schedule s : allSchedules) {
                        if (s.getWorkDate() != null) {
                            String dateKey = s.getWorkDate().toString();
                            scheduleMap.computeIfAbsent(dateKey, k -> new ArrayList<>()).add(s);
                        }
                    }

                    request.setAttribute("selectedEmployeeId", -1);
                    request.setAttribute("EmployeeName", "Tất cả nhân viên");
                }

                request.setAttribute("scheduleMap", scheduleMap);

            } catch (ClassNotFoundException e) {
                throw new ServletException("Lỗi khi lấy lịch làm việc", e);
            }
        }

        // Set calendar data
        request.setAttribute("year", year);
        request.setAttribute("month", month);
        request.setAttribute("yearMonth", yearMonth);
        request.setAttribute("selectedMonth", yearMonth.toString());


        if ("Quản Lý".equals(user.getRole())) {
            request.getRequestDispatcher("/viewSchedule.jsp").forward(request, response);
        } else {
            request.getRequestDispatcher("/viewSchedule-staff.jsp").forward(request, response);
        }
    }
}