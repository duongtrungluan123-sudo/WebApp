package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.loginDao;
import structure.login;

@WebServlet("/login")
public class loginServlet extends HttpServlet {
   private static final long serialVersionUID = 1L;
   private loginDao loginDao;

   @Override
   public void init() {
      this.loginDao = new loginDao();
   }

   @Override
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      String email = request.getParameter("email");
      String password = request.getParameter("password");
      login newlogin = new login();
      newlogin.setEmail(email);
      newlogin.setPassword(password);


      try {
         login user = loginDao.validate(newlogin);
         HttpSession session = request.getSession();
         if (user != null) {
            session.setAttribute("user", user);
            session.removeAttribute("error");
            String displayName = user.getUsername() != null && !user.getUsername().isBlank()
                  ? user.getUsername()
                  : user.getEmail();
            session.setAttribute("success", "Xin chào " + displayName + ", bạn đã đăng nhập thành công");
            if ("Quản Lý".equals(user.getRole())) {
               response.sendRedirect(request.getContextPath() + "/dashboard");
            } else {
               response.sendRedirect(request.getContextPath() + "/createCart");
            }
         } else {
            session.setAttribute("error", "Đăng nhập thất bại. Vui lòng kiểm tra lại email hoặc mật khẩu.");
            request.getRequestDispatcher("index.jsp").forward(request, response);
         }

      } catch (ClassNotFoundException e) {
         throw new ServletException("Error occurred while validating login", e);
      }
   }
}

