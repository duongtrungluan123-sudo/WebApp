package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.DataDao;
import database.InvoiceDAO;
import structure.Invoice;
import structure.books;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private InvoiceDAO invoiceDAO;
    private DataDao dataDao;

    @Override
    public void init() {
        this.invoiceDAO = new InvoiceDAO();
        this.dataDao = new DataDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            List<Invoice> revenue7Days = invoiceDAO.getRevenueLast7Days();
            double todayRevenue = invoiceDAO.getTodayRevenue();
            List<Invoice> revenueMonth = invoiceDAO.getRevenueByMonth();
            double[] todayShift = invoiceDAO.getTodayRevenueByShift();
            int[] todayOrderShift = invoiceDAO.getTodayOrderCountByShift();
            List<books> topSellers = dataDao.getTopSellers(5);

            request.setAttribute("todayRevenue", todayRevenue);
            request.setAttribute("revenueMonth", revenueMonth);
            request.setAttribute("revenue7Days", revenue7Days);
            request.setAttribute("todayShiftMorning", todayShift[0]);
            request.setAttribute("todayShiftAfternoon", todayShift[1]);
            request.setAttribute("todayOrderMorning", todayOrderShift[0]);
            request.setAttribute("todayOrderAfternoon", todayOrderShift[1]);
            request.setAttribute("topSellers", topSellers);

            request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
        } catch (ClassNotFoundException | SQLException e) {
            request.setAttribute("error", "Lỗi kết nối database: " + e.getMessage());
        }

    }
}