package servlet;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.DataDao;

@MultipartConfig
@WebServlet("/saveSchedule")
public class SaveScheduleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DataDao dataDao;

    @Override
    public void init() {
        dataDao = new DataDao();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        
        String action = request.getParameter("action");

        switch (action) {
            case "saveShifts" -> saveShifts(request, response);
            case "saveWeeklySchedule" -> saveWeeklySchedule(request, response);
            case "delete" -> deleteShiftsByDate(request, response);
            default -> {
                response.setContentType("application/json");
                response.getWriter().write("{\"success\":false,\"message\":\"Action không hợp lệ: " + action + "\"}");
            }
        }
    }

    private void saveShifts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            String workDateStr = request.getParameter("workDate"); // format: yyyy-MM-dd
            String[] employeeIds = request.getParameterValues("employeeId");
            String[] shifts = request.getParameterValues("shift");

            if (workDateStr == null || workDateStr.isEmpty() || employeeIds == null || shifts == null) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"Thiếu dữ liệu bắt buộc (Ngày, Nhân viên hoặc Ca làm)\"}");
                return;
            }

            LocalDate localDate = LocalDate.parse(workDateStr);
            String[] dayNames = {"CN", "T2", "T3", "T4", "T5", "T6", "T7"};
            String dayOfWeek = dayNames[localDate.getDayOfWeek().getValue() % 7];
            
            // Clear existing schedules for this date to prevent duplicates
            dataDao.deleteSchedulesByDate(workDateStr);
            

            for (int i = 0; i < employeeIds.length; i++) {
                if (employeeIds[i] != null && !employeeIds[i].isEmpty() &&
                    shifts[i] != null && !shifts[i].isEmpty() && !"-".equals(shifts[i])) {

                    int employeeId = Integer.parseInt(employeeIds[i]);
                    String shift = shifts[i];

                    // Handle "Cả ngày" - save as two shifts
                    if ("Cả ngày".equals(shift)) {
                        dataDao.addEmployeeScheduleWithDate(employeeId, workDateStr, dayOfWeek, "Sáng");
                        dataDao.addEmployeeScheduleWithDate(employeeId, workDateStr, dayOfWeek, "Chiều");
                    } else {
                        dataDao.addEmployeeScheduleWithDate(employeeId, workDateStr, dayOfWeek, shift);
                    }
                }
            }

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("{\"success\": true, \"message\": \"Lưu lịch làm việc thành công!\"}");

        } catch (ClassNotFoundException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("{\"success\": false, \"message\": \"Lỗi hệ thống: " + e.getMessage() + "\"}");
        }
    }

    private void saveWeeklySchedule(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String startDateStr = request.getParameter("startDate"); // format: yyyy-MM-dd
            String[] employeeIds = request.getParameterValues("employeeId");
            String[][] shifts = new String[7][]; // 7 days

            // Parse shifts for each day
            String[] dayNames = {"T2", "T3", "T4", "T5", "T6", "T7", "CN"};
            for (int i = 0; i < 7; i++) {
                shifts[i] = request.getParameterValues("shift_" + dayNames[i]);
            }

            if (startDateStr == null || startDateStr.isEmpty() || employeeIds == null) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"success\": false, \"message\": \"Thiếu dữ liệu bắt buộc\"}");
                return;
            }

            LocalDate startDate = LocalDate.parse(startDateStr);

            // Save shifts for each day
            for (int dayIdx = 0; dayIdx < 7; dayIdx++) {
                LocalDate workDate = startDate.plusDays(dayIdx);
                String workDateStr = workDate.toString(); // yyyy-MM-dd
                String dayOfWeek = dayNames[dayIdx];

                if (shifts[dayIdx] != null) {
                    for (int i = 0; i < shifts[dayIdx].length && i < employeeIds.length; i++) {
                        if (employeeIds[i] != null && !employeeIds[i].isEmpty() &&
                            shifts[dayIdx][i] != null && !shifts[dayIdx][i].isEmpty() && !"-".equals(shifts[dayIdx][i])) {

                            int employeeId = Integer.parseInt(employeeIds[i]);
                            String shift = shifts[dayIdx][i];

                            if ("Cả ngày".equals(shift)) {
                                dataDao.addEmployeeScheduleWithDate(employeeId, workDateStr, dayOfWeek, "Sáng");
                                dataDao.addEmployeeScheduleWithDate(employeeId, workDateStr, dayOfWeek, "Chiều");
                            } else {
                                dataDao.addEmployeeScheduleWithDate(employeeId, workDateStr, dayOfWeek, shift);
                            }
                        }
                    }
                }
            }

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("{\"success\": true, \"message\": \"Lưu lịch tuần thành công!\"}");

        } catch (ClassNotFoundException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("{\"success\": false, \"message\": \"Lỗi: " + e.getMessage() + "\"}");
        }
    }


    private void deleteShiftsByDate(HttpServletRequest request, HttpServletResponse response) 
        throws IOException {
    
        String workDateStr = request.getParameter("workDate");
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        if (workDateStr == null || workDateStr.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"success\": false, \"message\": \"Thiếu ngày cần xóa!\"}");
            return;
        }

        try {
            // Tận dụng luôn hàm deleteAllSchedulesByDate bạn đã thêm ở bước trước đó
            dataDao = new database.DataDao();
            dataDao.deleteSchedulesByDate(workDateStr);
            
            response.getWriter().write("{\"success\": true, \"message\": \"Đã xóa toàn bộ ca làm của ngày này!\"}");
            
        } catch (ClassNotFoundException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"success\": false, \"message\": \"Lỗi hệ thống: " + e.getMessage() + "\"}");
        }
    }
}