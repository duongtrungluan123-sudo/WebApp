package structure;

public class books {
    private int book_id;
    private String imageUrl;
    private String bookName;
    private String author;
    private String category;
    private int bookPage;
    private int quantity;
    private int publicYear;
    private double sellingPrice;
    private int category_id;
    private int sold;


    public String getImageUrl(){
        return imageUrl;
    }

    public void setImageUrl(String imgageUrl){
        this.imageUrl = imgageUrl;
    }

    public String getBookName(){
        return bookName;
    }

    public void setBookName(String bookName){
        this.bookName = bookName;
    }

    public String getAuthor(){
        return author;
    }

    public void setAuthor(String author){
        this.author = author;
    }

    public String getCategory(){
        return category;
    }

    public void setCategory(String category){
        this.category = category;
    }

    public int getBookPage(){
        return bookPage;
    }

    public void setBookPage(int bookPage){
        this.bookPage = bookPage;
    }
    
    public int getQuantity(){
        return quantity;
    }

    public void setQuantity(int quantity){
        this.quantity = quantity;
    }


    public int getPublicYear(){
        return publicYear;
    }

    public void setPublicYear(int publicYear){
        this.publicYear = publicYear;
    }
    public double getSellingPrice(){
        return sellingPrice;
    }

    public void setSellingPrice(double sellingPrice){
        this.sellingPrice = sellingPrice;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id){
        this.book_id = book_id;
    }

    public int getCategory_id() {
        return category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public int getSold() {
        return sold;
    }

    public void setSold(int sold) {
        this.sold = sold;
    }
}
