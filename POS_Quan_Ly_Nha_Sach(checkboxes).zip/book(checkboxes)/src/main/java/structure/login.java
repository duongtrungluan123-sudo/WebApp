package structure;

import java.io.Serializable;

public class login implements Serializable {
   private static final long serialVersionUID = 1L;
   private int id;
   private String username;
   private String password;
   private String email;
   private String role;
   private String phone;

   public void setId(int id) {
      this.id = id;
   }

   public int getId() {
      return id;
   }

   public String getUsername() {
      return username;
   }

   public void setUsername(String username) {
      this.username = username;
   }

   public String getPassword() {
      return password;
   }

   public void setPassword(String password) {
      this.password = password;
   }

   public String getEmail() {
      return email;
   }

   public void setEmail(String email) {
      this.email = email;
   }

   public String getRole() {
      return role;
   }

   public void setRole(String role) {
      this.role = role;
   }

   public String getPhone() {
      return phone;
   }

   public void setPhone(String phone) {
      this.phone = phone;
   }
}
