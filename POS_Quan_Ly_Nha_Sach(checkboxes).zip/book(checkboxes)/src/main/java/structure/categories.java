package structure;

public class categories {
    private int id;
    private String categoryName;
    private int totalbook;

    public categories(){
    }

    public categories(int id, String categoryName) {
        this.id = id;
        this.categoryName = categoryName;
    }

    public categories(int id, String categoryName, int totalbook) {
        this.id = id;
        this.categoryName = categoryName;
        this.totalbook = totalbook;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public int getTotalbook() {
        return totalbook;
    }

    public void setTotalbook(int totalbook) {
        this.totalbook = totalbook;
    }
}
