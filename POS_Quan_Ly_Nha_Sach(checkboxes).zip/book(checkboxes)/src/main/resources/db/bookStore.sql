CREATE DATABASE  IF NOT EXISTS `bookstore` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bookstore`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bookstore
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `book_id` int NOT NULL AUTO_INCREMENT,
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `book_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL DEFAULT '0',
  `book_page` int NOT NULL,
  `publicyear` year NOT NULL,
  `selling_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `category_id` int DEFAULT NULL,
  PRIMARY KEY (`book_id`),
  KEY `fk_books_category` (`category_id`),
  CONSTRAINT `fk_books_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (1,'1_Dac_Nhan_Tam.jpg','Đắc Nhân Tâm','Dale Carnegie',41,320,2019,85000.00,1),(2,'2_Nha_Gia_Kim.jpg','Nhà Giả Kim','Paulo Coelho',39,224,2020,85000.00,2),(3,'3_Sapiens_Luoc_su_ve_loai_nguoi.jpg','Sapiens: Lược Sử Loài Người','Yuval Noah Harari',20,576,2019,120000.00,3),(4,'4_Tuoi_tre_dang_gia_bao_nhieu.jpg','Tuổi Trẻ Đáng Giá Bao Nhiêu','Rosie Nguyễn',6,272,2018,75000.00,1),(5,'5_Di_tim_le_song.jpg','Đi Tìm Lẽ Sống','Viktor Frankl',30,208,2021,85000.00,4),(6,'6_Cay_cam_ngot_cua_toi.jpg','Cây Cam Ngọt Của Tôi','J.M. de Vasconcelos',11,264,2020,950000.00,2),(7,'7_Homo_Deus.jpg','Homo Deus','Yuval Noah Harari',30,464,2021,200000.00,5),(8,'8_Nguoi_dua_dieu.jpg','Người Đua Diều','Khaled Hosseini',76,400,2022,90000.00,2),(9,'9_Toi_thay_hoa_vang_tren_co_xanh.jpg','Tôi Thấy Hoa Vàng Trên Cỏ Xanh','Nguyễn Nhật Ánh',6,336,2021,75000.00,6),(10,'10_Rich_dad_poor_dad.jpg','Rich Dad Poor Dad','Robert Kiyosaki',30,336,2022,110000.00,7);
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_name` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (5,'Khoa Học'),(1,'Kỹ Năng Sống'),(3,'Lịch Sử'),(7,'Tài Chính'),(4,'Tâm Lý Học'),(6,'Thiếu Nhi'),(2,'Văn Học');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `role` varchar(10) DEFAULT 'STAFF',
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'admin','0912345678','admin@gmail.com','123','Quản Lý'),(2,'staff01','0987654321','staff01@gmail.com','staff123','Nhân Viên'),(6,'a2','1234567891','a2@gmail.com','555','Nhân Viên');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_schedule`
--

DROP TABLE IF EXISTS `employee_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_schedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `work_date` date DEFAULT NULL,
  `day_of_week` enum('T2','T3','T4','T5','T6','T7','CN') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shift` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_employee_schedule` (`employee_id`),
  CONSTRAINT `fk_employee_schedule` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_schedule`
--

LOCK TABLES `employee_schedule` WRITE;
/*!40000 ALTER TABLE `employee_schedule` DISABLE KEYS */;
INSERT INTO `employee_schedule` VALUES (1,2,'2026-07-25','T7','Sáng'),(2,6,'2026-07-25','T7','Chiều'),(3,2,'2026-07-26','CN','Sáng'),(4,2,'2026-07-26','CN','Chiều'),(5,6,'2026-07-27','T2','Sáng'),(6,2,'2026-07-27','T2','Chiều');
/*!40000 ALTER TABLE `employee_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `employee_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','completed','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `payment_method` enum('Tiền mặt','Chuyển khoản') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
INSERT INTO `invoice` VALUES (1,'2026-07-01 00:00:00',185000.00,'staff01','Nguyễn Văn A','0901234567','completed','Tiền mặt','2026-07-05 06:35:06','2026-07-05 09:33:01'),(2,'2026-07-01 00:00:00',120000.00,'staff01','Trần Thị B','0912345678','completed','Chuyển khoản','2026-07-05 06:35:06','2026-07-05 09:33:01'),(3,'2026-07-02 00:00:00',350000.00,'staff01','Lê Văn C','0988888888','completed','Chuyển khoản','2026-07-05 06:35:06','2026-07-05 09:33:01'),(4,'2026-07-03 00:00:00',95000.00,'staff01','Phạm Văn D','0933333333','completed','Tiền mặt','2026-07-05 06:35:06','2026-07-05 09:33:01'),(5,'2026-07-04 00:00:00',260000.00,'staff01','Hoàng Minh E','0977777777','completed','Chuyển khoản','2026-07-05 06:35:06','2026-07-05 09:33:01'),(6,'2026-07-05 00:00:00',180000.00,'staff01','Khách lẻ',NULL,'completed','Chuyển khoản','2026-07-05 06:35:06','2026-07-05 09:33:01'),(7,'2026-07-13 00:00:00',1510000.00,'staff01',NULL,NULL,'completed','Tiền mặt','2026-07-13 04:24:50','2026-07-13 04:24:50'),(8,'2026-07-13 00:00:00',85000.00,'staff01',NULL,NULL,'completed','Tiền mặt','2026-07-13 04:33:08','2026-07-13 04:33:08'),(9,'2026-07-13 00:00:00',85000.00,'staff01',NULL,NULL,'completed','Tiền mặt','2026-07-13 05:16:47','2026-07-13 05:16:47'),(10,'2026-07-13 00:00:00',75000.00,'staff01',NULL,NULL,'completed','Tiền mặt','2026-07-13 10:05:59','2026-07-13 10:05:59'),(11,'2026-07-13 11:49:48',180000.00,'staff01','Nguyễn Văn A','0123456789','completed','Chuyển khoản','2026-07-13 11:49:47','2026-07-13 11:49:47'),(12,'2026-07-15 07:06:16',265000.00,'staff01','Nguyễn Văn B','0987654321','completed','Tiền mặt','2026-07-15 07:06:15','2026-07-15 07:06:15');
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_detail`
--

DROP TABLE IF EXISTS `invoice_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `book_id` int NOT NULL,
  `book_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `invoice_detail_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoice_detail_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_detail`
--

LOCK TABLES `invoice_detail` WRITE;
/*!40000 ALTER TABLE `invoice_detail` DISABLE KEYS */;
INSERT INTO `invoice_detail` VALUES (1,1,2,'Đắc Nhân Tâm',2,85000.00,170000.00),(2,1,4,'Tuổi trẻ đáng giá bao nhiêu',2,85000.00,170000.00),(3,7,1,'Đắc nhân tâm',2,85000.00,170000.00),(4,7,2,'Nhà Giả Kim',2,85000.00,170000.00),(5,7,6,'Cây Cam Ngọt Của Tôi',1,950000.00,950000.00),(6,7,10,'Rich Dad Poor Dad',2,110000.00,220000.00),(7,8,1,'Đắc nhân tâm',1,85000.00,85000.00),(8,9,1,'Đắc nhân tâm',1,85000.00,85000.00),(9,10,4,'Tuổi Trẻ Đáng Giá Bao Nhiêu',1,75000.00,75000.00),(10,11,8,'Người Đua Diều',2,90000.00,180000.00),(11,12,2,'Nhà Giả Kim',1,85000.00,85000.00),(12,12,8,'Người Đua Diều',2,90000.00,180000.00);
/*!40000 ALTER TABLE `invoice_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-16 10:25:14
