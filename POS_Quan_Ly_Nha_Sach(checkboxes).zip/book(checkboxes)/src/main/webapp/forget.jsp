<!DOCTYPE html>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Quên mật khẩu</title>
        <link rel="icon" href="<%=request.getContextPath()%>/favicon.svg" type="image/svg+xml">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="<%=request.getContextPath()%>/css/admin.css">
    </head>

    <body class="auth-body">
        <div class="auth-card">
            <div class="auth-brand">
                <div class="auth-brand-icon"><i class="fa-solid fa-book-open"></i></div>
                <div class="auth-brand-text">
                    <span class="auth-brand-name">Nhà Sách Minh Châu</span>
                    <span class="auth-brand-sub">Hệ thống quản lý</span>
                </div>
            </div>
            <h1>Quên Mật Khẩu</h1>
            <form action="<%=request.getContextPath()%>/forget" method="post">
                <table>
                    <tr>
                        <td>Số Điện Thoại:</td>
                        <td><input type="text" placeholder = "Nhập Số điện thoại" name="phone" required/></td>
                    </tr>
                    <tr>
                        <td>Mật Khẩu Mới:</td>
                        <td><input type="password" placeholder ="Nhập mật khẩu mới" name = "newpassword" required/></td>
                    </tr>
                    <tr>
                        <td>Nhập Lại Mật Khẩu Mới:</td>
                        <td>
                            <input type="password" placeholder = "Nhập lại mật khẩu mới" name = "confirmpassword" required/>
                            <%  String error = (String) request.getAttribute("error");
                                if (error != null) {
                            %>
                                <span class="auth-error"><%=error%></span>
                            <%
                                }
                            %>
                        </td>
                    </tr>
                </table>
                <button type="submit">Thay Đổi Mật Khẩu</button>
                <button type="button" class="btn-secondary" onclick="window.location.href='<%=request.getContextPath()%>/index.jsp'">Quay Về Trang Đăng Nhập</button>
            </form>
        </div>
    </body>
</html>