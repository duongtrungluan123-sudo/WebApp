<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%@ page import="java.util.LinkedHashMap" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.util.Calendar" %>
<%@ page import="java.time.LocalDate" %>
<%@ page import="java.time.YearMonth" %>
<%@ page import="java.time.DayOfWeek" %>
<%@ page import="java.time.format.DateTimeFormatter" %>
<%@ page import="structure.login" %>
<%@ page import="structure.schedule" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Lịch làm việc - Nhà Sách Minh Châu</title>
        <link rel="icon" href="<%=request.getContextPath()%>/favicon.svg" type="image/svg+xml">
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="<%=request.getContextPath()%>/css/admin.css">
        <style>
            .calendar-container {
                padding: 24px;
                overflow-y: hidden;
                flex: 1;
                margin-top:-40px;
            }

            .top-header{
                display:flex;
                gap:1180px;
                margin-bottom: 22px;
                border-bottom: 1px solid var(--border-color);
                align-items: center;
                padding-bottom:16px;
            }

            .top-header h1 {
                margin: 0;
                font-size: 23px;
                font-weight: 800;
                position: relative;
                padding-left: 14px;
            }

            /* gold accent tab before page titles */
            .top-header h1::before {
                content: "";
                position: absolute;
                left: 0;
                top: 3px;
                bottom: 3px;
                width: 5px;
                border-radius: 4px;
                background: var(--grad-gold);
            }


            .calendar-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
                gap:15px;
            }

            .month-selector select {
                padding: 8px 14px;
                border-radius: 8px;
                border: 1px solid var(--border-color);
                background: #fff;
                font-family: var(--font-num);
                font-weight: 500;
                color: var(--text-main);
                outline: none;
                transition: var(--transition);
                box-shadow: var(--shadow-sm);
            }

            .month-selector select:focus {
                border-color: var(--accent-gold);
                box-shadow: 0 0 0 3px rgba(220,179,123,0.22);
            }

            .calendar-grid {
                display: grid;
                grid-template-columns: repeat(7, 1fr);
                height:85%;
                gap: 1px;
                background-color: var(--border-color); /* Acts as border */
                border: 1px solid var(--border-color);
                border-radius: 12px;
                box-shadow: var(--shadow-sm);
            }

            .calendar-day-header {
                background: var(--grad-surface);
                padding: 12px;
                text-align: center;
                font-weight: 700;
                color: var(--accent-brown-dark);
                font-size: 0.875rem;
            }

            .calendar-day {
                background-color: #fff;
                padding: 10px;
                position: relative;
                transition: background var(--transition);
            }
            
            .calendar-day:hover {
                background-color: #faf7f2;
            }

            .calendar-day.other-month {
                background-color: #fcfbfa;
                color: #cfc4b2;
            }

            .calendar-day.today {
                background-color: #fffdf9;
                box-shadow: inset 0 0 0 2px var(--accent-gold);
            }

            .day-number {
                font-family: var(--font-num);
                font-weight: 600;
                font-size: 0.95rem;
                margin-bottom: 8px;
                color: var(--text-dark);
            }
            
            .calendar-day.other-month .day-number {
                color: #cfc4b2;
            }

            .shift-item {
                padding: 6px 10px;
                margin-bottom: 5px;
                border-radius: 6px;
                font-size: 0.75rem;
                font-weight: 500;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                border-left: 3px solid transparent;
                box-shadow: 0 1px 3px rgba(0,0,0,0.04);
            }

            /* Theming the shifts to match the POS warm vibe while keeping distinction */
            .shift-item.morning {
                background-color: #f0f7ff;
                border-left-color: #4a90e2;
                color: #2c5282;
            }
            .shift-item.afternoon {
                background-color: #fff8f0;
                border-left-color: #f6ad55;
                color: #9c4221;
            }
            .shift-item.fullday {
                background-color: #fff1f2;
                border-left-color: #f43f5e;
                color: #9f1239;
            }

            .no-shifts {
                color: var(--text-muted);
                font-size: 0.75rem;
                font-style: italic;
                text-align: center;
                padding-top: 15px;
            }

            .legend {
                display: flex;
                gap: 20px;
                margin-top: 24px;
                flex-wrap: wrap;
                background: #fff;
                padding: 16px 24px;
                border-radius: 12px;
                border: 1px solid var(--border-color);
                box-shadow: var(--shadow-sm);
            }

            .legend-item {
                display: flex;
                align-items: center;
                gap: 8px;
                font-size: 0.875rem;
                font-weight: 500;
                color: var(--text-main);
            }

            .legend-color {
                width: 20px;
                height: 20px;
                border-radius: 4px;
                border-left: 3px solid;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            }
            
            .top-header .btn {
                border: none;
                border-radius: var(--radius-sm);
                cursor: pointer;
                text-decoration: none;
                display: inline-block;
                font-size: 14px;
                font-family: var(--font-sans);
                transition: all var(--transition);
            }

            .top-header .btn-add {
                background: var(--grad-gold);
                color: #3a2a17;
                padding: 12px 25px;
                font-weight: 700;
                text-decoration: none;
                border-radius: var(--radius-sm);
                box-shadow: var(--shadow-gold);
                transition: all var(--transition);
            }

            .top-header .btn-add:hover {
                background: var(--grad-brown);
                color: #fff;
                transform: translateY(-2px);
                box-shadow: 0 8px 20px rgba(122, 92, 67, 0.34);
            }
        </style>
    </head>
    <body>
        <%
            // Kiểm tra đăng nhập
            structure.login user = (structure.login) session.getAttribute("user");
            if (user == null) {
                session.setAttribute("error", "Vui lòng đăng nhập");
                response.sendRedirect(request.getContextPath() + "/index.jsp");
                return;
            }
        %>
        <div class="layout">
            <!-- Sidebar -->
            <nav class="sidebar">
                <div class="sidebar-brand">
                    <i class="fa-solid fa-book-open"></i>
                    <div class="brand-text">
                        <span class="brand-name">Nhà Sách Minh Châu</span>
                        <span class="brand-sub">Hệ thống quản lý</span>
                    </div>
                </div>
                <ul class="sidebar-menu">
                        <li><a href= "<%=request.getContextPath()%>/dashboard"><i class="fa-solid fa-chart-column"></i> Báo Cáo Doanh Thu</a></li>
                        <li><a href= "<%=request.getContextPath()%>/data?table=books"><i class="fa-solid fa-book"></i> Quản Lý Sách</a></li>
                        <li><a href= "<%=request.getContextPath()%>/data?table=employees"><i class="fa-solid fa-users"></i> Quản Lý Nhân Viên</a></li>
                        <li><a href="<%=request.getContextPath()%>/book-efficiency"><i class="fa-solid fa-arrow-trend-up"></i> Hiệu Suất Bán Hàng</a></li>
                        <li><a href="<%=request.getContextPath()%>/data?table=invoices"><i class="fa-regular fa-clock"></i> Quản Lý Hóa Đơn</a></li>
                        <li class= "active">
                            <a href="<%=request.getContextPath()%>/viewSchedule"><i class="fa-solid fa-calendar-days"></i> Lịch làm việc</a>
                        </li>
                </ul>
                <div class="sidebar-footer">
                    <%
                        structure.login headerUser = (structure.login) session.getAttribute("user");
                        String headerName = (headerUser != null && headerUser.getUsername() != null && !headerUser.getUsername().isBlank())
                                ? headerUser.getUsername() : "Người dùng";
                        String headerRole = (headerUser != null && headerUser.getRole() != null) ? headerUser.getRole() : "";
                        String headerInitial = headerName.substring(0, 1).toUpperCase();
                    %>
                    <div class="header-user">
                        <div class="avatar"><%= headerInitial %></div>
                        <span><%= headerName %><br><small><%= headerRole %></small></span>
                    </div>
                    <button class="logout-btn" onclick="window.location.href='<%=request.getContextPath()%>/index.jsp'">
                        <i class="fa-solid fa-right-from-bracket"></i> Đăng xuất
                    </button>
                </div>
            </nav>

            <!-- Main Content -->
        <main class="main-content">
            <header class="top-header">
                <h1>Lịch làm việc nhân viên</h1>
                <a href="<%=request.getContextPath()%>/data?table=employees" class="btn btn-add">
                    <i class="fa-solid fa-arrow-left"></i> Quay lại
                </a>
            </header>

            <div class="calendar-container" style = "overflow:hidden">
                <div class="calendar-header">
                    <div class="month-selector">
                        <form id="monthForm" method="GET" action="<%=request.getContextPath()%>/viewSchedule" class="d-flex align-items-center gap-2">
                            <input type="hidden" name="employeeId" value="${param.employeeId}">
                            <label for="monthSelect" class="form-label mb-0 fw-semibold" style="color: var(--text-main);">Tháng:</label>
                            <select id="monthSelect" name="month" class="form-select form-select-sm" style="width: auto;" onchange="this.form.submit()">
                                <%
                                    int currentYear = java.time.LocalDate.now().getYear();
                                    int currentMonth = java.time.LocalDate.now().getMonthValue();
                                    String paramMonth = request.getParameter("month");

                                    // Lặp qua năm hiện tại và năm tiếp theo (y = currentYear đến currentYear + 1)
                                    for (int m = 1; m <= 12; m++) {
                                        String valueStr = currentYear + "-" + String.format("%02d", m);
                                        String selected = "";

                                        if (paramMonth != null && paramMonth.equals(valueStr)) {
                                            selected = "selected";
                                        } else if (paramMonth == null && m == currentMonth) {
                                            // Mặc định chọn đúng tháng hiện tại
                                            selected = "selected";
                                        }

                                        String monthName = java.time.Month.of(m).getDisplayName(java.time.format.TextStyle.FULL, new java.util.Locale("vi", "VN"));
                                        String capitalizedMonth = monthName.substring(0, 1).toUpperCase() + monthName.substring(1);
                                %>
                                <option value="<%=valueStr%>" <%=selected%>><%=capitalizedMonth%> <%=currentYear%></option>
                                <%
                                    }
                                %>
                            </select>
                        </form>
                    </div>
                    <!-- Legend -->
                    <div class="legend">
                        <div class="legend-item">
                            <div class="legend-color" style="background-color: #f0f7ff; border-left-color: #4a90e2;"></div>
                            <span>Ca Sáng</span>
                        </div>
                        <div class="legend-item">
                            <div class="legend-color" style="background-color: #fff8f0; border-left-color: #f6ad55;"></div>
                            <span>Ca Chiều</span>
                        </div>
                        <div class="legend-item">
                            <div class="legend-color" style="background-color: #fff1f2; border-left-color: #f43f5e;"></div>
                            <span>Cả ngày</span>
                        </div>
                    </div>
                </div>

                <%
                    // Lấy params từ request
                    String monthParam = request.getParameter("month");
                    String employeeIdParam = request.getParameter("employeeId");

                    // Mặc định là tháng hiện tại
                    YearMonth yearMonth;
                    if (monthParam != null && !monthParam.isEmpty()) {
                        String[] parts = monthParam.split("-");
                        yearMonth = YearMonth.of(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]));
                    } else {
                        yearMonth = YearMonth.now();
                    }

                    int year = yearMonth.getYear();
                    int month = yearMonth.getMonthValue();

                    // Tính ngày đầu tháng và số ngày trong tháng
                    LocalDate firstDayOfMonth = yearMonth.atDay(1);
                    int daysInMonth = yearMonth.lengthOfMonth();
                    int firstDayOfWeek = firstDayOfMonth.getDayOfWeek().getValue() % 7;

                    // Lấy lịch từ request
                    Map<String, List<schedule>> scheduleMap = (Map<String, List<schedule>>) request.getAttribute("scheduleMap");
                    String EmployeeName = (String) request.getAttribute("EmployeeName");
                    if (scheduleMap == null) {
                        scheduleMap = new LinkedHashMap<>();
                    }
                %>

                <%
                    // Kiểm tra User có phải Admin không để hiển thị bộ lọc
                    structure.login viewUser = (structure.login) session.getAttribute("user");
                    boolean isAdmin = (viewUser != null && "Quản Lý".equals(viewUser.getRole()));
                %>
                
                <!-- Employee Filter (Chỉ hiển thị cho Quản lý) -->
                <% if (isAdmin) { %>
                <div class="mb-4 d-flex align-items-center gap-2" style = "margin-top:-20px">
                    <label for="employeeFilter" class="form-label mb-0 fw-semibold" style="color: var(--text-main);">Lọc theo nhân viên:</label>
                    <select id="employeeFilter" class="form-select form-select-sm" style="width: auto; max-width: 300px; box-shadow: var(--shadow-sm); border-color: var(--border-color);" onchange="filterByEmployee(this.value)">
                        <option value="">Tất cả nhân viên</option>
                        <c:forEach var="emp" items="${employees}">
                            <c:if test="${emp.role != 'Quản Lý'}">
                                <option value="${emp.id}" ${param.employeeId == emp.id ? 'selected' : ''}>${emp.username}</option>
                            </c:if>
                        </c:forEach>
                    </select>
                </div>
                <% } %>

                <!-- Calendar Grid -->
                <div class="calendar-grid" id="calendarGrid">
                    <!-- Day Headers -->
                    <div class="calendar-day-header">CN</div>
                    <div class="calendar-day-header">T2</div>
                    <div class="calendar-day-header">T3</div>
                    <div class="calendar-day-header">T4</div>
                    <div class="calendar-day-header">T5</div>
                    <div class="calendar-day-header">T6</div>
                    <div class="calendar-day-header">T7</div>

                    <%
                        // In các ô trống của tháng trước
                        for (int i = 0; i < firstDayOfWeek; i++) {
                    %>
                    <div class="calendar-day other-month"></div>
                    <%
                        }

                        // In các ngày trong tháng
                        LocalDate today = LocalDate.now();
                        for (int day = 1; day <= daysInMonth; day++) {
                            LocalDate currentDate = LocalDate.of(year, month, day);
                            String dateKey = currentDate.toString();
                            boolean isToday = currentDate.equals(today);

                            List<schedule> daySchedules = scheduleMap.get(dateKey);
                    %>
                    <div class="calendar-day <%= isToday ? "today" : "" %>" data-date="<%= dateKey %>">
                        <div class="day-number"><%= day %></div>
                        <%
                            if (daySchedules != null && !daySchedules.isEmpty()) {
                                // Nhóm ca làm việc theo nhân viên để gộp thành "Cả ngày"
                                Map<String, List<String>> employeeShifts = new LinkedHashMap<>();
                                for (schedule s : daySchedules) {
                                    String empName = s.getEmployeeName();
                                    String shift = s.getShift();
                                    employeeShifts.computeIfAbsent(empName, k -> new ArrayList<>()).add(shift);
                                }

                                for (Map.Entry<String, List<String>> entry : employeeShifts.entrySet()) {
                                    String empName = entry.getKey();
                                    List<String> shifts = entry.getValue();
                                    String shiftClass = "";
                                    String displayShift = "";

                                    boolean hasMorning = shifts.contains("Sáng");
                                    boolean hasAfternoon = shifts.contains("Chiều");
                                    boolean hasFullDay = shifts.contains("Cả ngày");

                                    if (hasFullDay || (hasMorning && hasAfternoon)) {
                                        shiftClass = "fullday";
                                        displayShift = "Cả ngày";
                                    } else if (hasMorning) {
                                        shiftClass = "morning";
                                        displayShift = "Ca Sáng";
                                    } else if (hasAfternoon) {
                                        shiftClass = "afternoon";
                                        displayShift = "Ca Chiều";
                                    } else {
                                        shiftClass = "fullday";
                                        displayShift = shifts.get(0);
                                    }
                        %>
                        <div class="shift-item <%= shiftClass %>">
                            <span class="shift-employee"><%= displayShift %>: <%= empName %></span>
                        </div>
                        <%
                                }
                            } else {
                        %>
                        <div class="no-shifts">Không có ca</div>
                        <%
                            }
                        %>
                    </div>
                    <%
                        }
                    %>
                </div>

                
            </div>
        </main>
        
        
        <!-- JS của staff (Đặt trước thẻ đóng </body>) -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            // Filter by employee
            function filterByEmployee(employeeId) {
                const url = new URL(window.location.href);
                if (employeeId) {
                    url.searchParams.set('employeeId', employeeId);
                } else {
                    url.searchParams.delete('employeeId');
                }
                window.location.href = url.toString();
            }

            // Highlight today on load
            document.addEventListener('DOMContentLoaded', function() {
                const today = new Date().toISOString().split('T')[0];
                const todayCell = document.querySelector('.calendar-day[data-date="' + today + '"]');
                if (todayCell) {
                    todayCell.classList.add('today');
                }
            });
        </script>
    </body>
</html>