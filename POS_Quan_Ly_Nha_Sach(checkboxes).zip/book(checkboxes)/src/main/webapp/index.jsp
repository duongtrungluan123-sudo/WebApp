<!DOCTYPE html>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Đăng nhập</title>
        <link rel="icon" href="<%=request.getContextPath()%>/favicon.svg" type="image/svg+xml">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="<%=request.getContextPath()%>/css/admin.css">
    </head>
    <body class="auth-body">
        <%
            String success = (String) session.getAttribute("success");
            String error = (String) session.getAttribute("error");

            if (success != null) {
        %>
            <script>
                alert("<%= success %>");
            </script>
        <%
                session.removeAttribute("success");
            }

            if (error != null) {
        %>
            <script>
                alert("<%= error %>");
            </script>
        <%
                session.removeAttribute("error");
            }
        %>
        <div class="auth-card">
            <div class="auth-brand">
                <div class="auth-brand-icon"><i class="fa-solid fa-book-open"></i></div>
                <div class="auth-brand-text">
                    <span class="auth-brand-name">Nhà Sách Minh Châu</span>
                    <span class="auth-brand-sub">Hệ thống quản lý</span>
                </div>
            </div>
            <h1>ĐĂNG NHẬP</h1>
            <form action="login" method="post">
                <table>
                    <tr>
                    <td>Email:</td>
                    <td><input type="email" placeholder = "Nhập địa chỉ email" name="email" required/></td>
                    </tr>
                    <tr>
                    <td>Password:</td>
                    <td><input type="password" placeholder = "Nhập mật khẩu" name="password" required/></td>
                    </tr>
                </table>
            <button type="submit">Đăng nhập</button>
            </form>
            <a href="<%=request.getContextPath()%>/forget.jsp">Quên mật khẩu?</a>
        </div>

    </body>
</html>