<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="structure.books" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hiệu suất bán hàng - Nhà Sách Minh Châu</title>
    <link rel="icon" href="<%=request.getContextPath()%>/favicon.svg" type="image/svg+xml">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<%=request.getContextPath()%>/css/admin.css">

</head>
    <body>
        <%
            // Kiểm tra đăng nhập và role ADMIN
            structure.login user = (structure.login) session.getAttribute("user");
            if (user == null || !"Quản Lý".equals(user.getRole())) {
                session.setAttribute("error", "Vui lòng đăng nhập với tài khoản admin");
                response.sendRedirect(request.getContextPath() + "/index.jsp");
                return;
            }
        %>
        <%
            String success = (String) session.getAttribute("success");
            String error = (String) session.getAttribute("error");
            if (success != null) {
        %>
            <script>
                alert("<%= success %>");
            </script>

        <%
                session.removeAttribute("success");
            }
            if (error != null) {
        %>

            <script>
                alert("<%= error %>");
            </script>

        <%
                session.removeAttribute("error");
            }
        %>
        <div class="layout">
            <nav class="sidebar">
                <div class="sidebar-brand">
                    <i class="fa-solid fa-book-open"></i>
                    <div class="brand-text">
                        <span class="brand-name">Nhà Sách Minh Châu</span>
                        <span class="brand-sub">Hệ thống quản lý</span>
                    </div>
                </div>
                <ul class="sidebar-menu">
                    <li><a href= "<%=request.getContextPath()%>/dashboard"><i class="fa-solid fa-chart-column"></i> Báo Cáo Doanh Thu</a></li>
                    <li><a href= "<%=request.getContextPath()%>/data?table=books"><i class="fa-solid fa-book"></i> Quản Lý Sách</a></li>
                    <li><a href= "<%=request.getContextPath()%>/data?table=employees"><i class="fa-solid fa-users"></i> Quản Lý Nhân Viên</a></li>
                    <li class="active"><a href="<%=request.getContextPath()%>/book-efficiency"><i class="fa-solid fa-arrow-trend-up"></i> Hiệu Suất Bán Hàng</a></li>
                    <li><a href="<%=request.getContextPath()%>/data?table=invoices"><i class="fa-regular fa-clock"></i> Quản Lý Hóa Đơn</a></li>
                    <li class="<%= "viewSchedule".equals(request.getParameter("page")) ? "active" : "" %>">
                        <a href="<%=request.getContextPath()%>/viewSchedule"><i class="fa-solid fa-calendar-days"></i> Lịch làm việc</a>
                    </li>
                </ul>
                <div class="sidebar-footer">
                    <%
                        structure.login effUser = (structure.login) session.getAttribute("user");
                        String effName = (effUser != null && effUser.getUsername() != null && !effUser.getUsername().isBlank())
                                ? effUser.getUsername() : "Quản Lý";
                        String effRole = (effUser != null && effUser.getRole() != null) ? effUser.getRole() : "";
                        String effInitial = effName.substring(0, 1).toUpperCase();
                    %>
                    <div class="header-user">
                        <div class="avatar"><%= effInitial %></div>
                        <span><%= effName %><br><small><%= effRole %></small></span>
                    </div>
                    <button class="logout-btn" onclick="window.location.href='<%=request.getContextPath()%>/index.jsp'">
                        <i class="fa-solid fa-right-from-bracket"></i> Đăng xuất
                    </button>
                </div>
            </nav>

            <div class="main-content">
                <div class="header-top">
                    <h4 class="mb-0">Hiệu Suất Bán Hàng</h4>
                </div>

                <%
                    String effError = (String) request.getAttribute("error");
                    if (effError != null && !effError.isEmpty()) {
                %>
                <div class="alert alert-danger" role="alert"><%= effError %></div>
                <%
                    }
                %>

                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="stat-card">
                            <div class="stat-label">TỔNG ĐẦU SÁCH</div>
                            <div class="stat-value"><%= request.getAttribute("totalTitles") != null ? request.getAttribute("totalTitles") : 0 %> <span style="font-size: 0.9rem; font-weight: normal; color: #777;">đầu sách</span></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-card">
                            <div class="stat-label">ĐÃ BÁN HÔM NAY</div>
                            <div class="stat-value"><%= request.getAttribute("soldToday") != null ? request.getAttribute("soldToday") : 0 %> <span style="font-size: 0.9rem; font-weight: normal; color: #777;">quyển</span></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-card">
                            <div class="stat-label" style="color: var(--danger-text);">TỒN KHO THẤP</div>
                            <div class="stat-value text-danger-custom"><%= request.getAttribute("lowStockCount") != null ? request.getAttribute("lowStockCount") : 0 %> <span style="font-size: 0.9rem; font-weight: normal; color: #777;">đầu sách</span></div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-6">
                        <div class="card-panel">
                            <div class="card-title">
                                <i class="fa-regular fa-star" style="color: #dcb37b;"></i> Sách bán chạy nhất
                            </div>
                            
                            <%
                                List<books> topSellers = (List<books>) request.getAttribute("topSellers");
                                Integer maxSold = (Integer) request.getAttribute("maxSold");
                                if (topSellers != null) {
                                    int rank = 1;
                                    for (books b : topSellers) {
                                        int sold = b.getSold();
                                        int pct = (maxSold != null && maxSold > 0) ? (sold * 100 / maxSold) : 0;
                                        String img = b.getImageUrl() != null ? b.getImageUrl() : "";
                                        String title = b.getBookName() != null ? b.getBookName() : "";
                                        String author = b.getAuthor() != null ? b.getAuthor() : "";
                            %>
                            <div class="top-selling-item">
                                <div class="rank">#<%= rank %></div>
                                <img src="<%=request.getContextPath()%>/image?name=<%= img %>" alt="Book" class="book-img" onerror="this.src='https://via.placeholder.com/40x55'">
                                <div class="book-info">
                                    <div class="book-title"><%= title %></div>
                                    <div class="book-author"><%= author %></div>
                                    <div class="progress-bar-custom"><div class="progress-fill" style="width: <%= pct %>%;"></div></div>
                                </div>
                                <div class="sold-count"><%= sold %><br><small style="font-size: 0.9rem; font-weight: normal;">đã bán</small></div>
                            </div>
                            <%
                                        rank++;
                                    }
                                    if (topSellers.isEmpty()) {
                            %>
                            <div class="text-muted">Chưa có dữ liệu bán hàng.</div>
                            <%
                                    }
                                }
                            %>

                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="card-panel" style = "overflow-y:scroll; height:352px">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div class="card-title mb-0">
                                    <i class="fa-solid fa-box-open" style="color: var(--danger-text);"></i> Tồn kho thấp
                                </div>
                                <span class="badge bg-light text-dark border"><i class="fa-solid fa-filter"></i> ≤ 10 quyển</span>
                            </div>
                            
                            <table class="table table-custom table-borderless">
                                <thead>
                                    <tr>
                                        <th>SÁCH</th>
                                        <th class="text-center">CÒN LẠI</th>
                                        <th class="text-end">ĐÃ BÁN</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <%
                                        List<books> lowStockBooks = (List<books>) request.getAttribute("lowStockBooks");
                                        if (lowStockBooks != null) {
                                            for (books b : lowStockBooks) {
                                                String name = b.getBookName() != null ? b.getBookName() : "";
                                                String cat = b.getCategory() != null ? b.getCategory() : "";
                                    %>
                                    <tr>
                                        <td>
                                            <div class="font-weight-bold"><%= name %></div>
                                            <small class="text-muted"><%= cat %></small>
                                        </td>
                                        <td class="text-center"><span class="badge bg-danger"><%= b.getQuantity() %></span></td>
                                        <td class="text-end"><%= b.getSold() %></td>
                                    </tr>
                                    <%
                                            }
                                            if (lowStockBooks.isEmpty()) {
                                    %>
                                    <tr><td colspan="3" class="text-center text-muted">Không có sách tồn kho thấp.</td></tr>
                                    <%
                                            }
                                        }
                                    %>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="card-panel pos-table-container">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div class="card-title mb-0">
                                    <i class="fa-solid fa-desktop" style="color: var(--accent-brown);"></i> Danh Sách Bán Chạy — Tất Cả Đầu Sách
                                </div>
                                <div class="input-group" style="width: 500px;">
                                    <input type="text" id="allBooksSearchInput" class="form-control" placeholder="Tìm kiếm tên sách, tác giả, thể loại...">
                                    <button class="btn btn-outline-secondary" type="button"><i class="fa-solid fa-magnifying-glass"></i></button>
                                </div>
                            </div>

                            <div class="table-responsive">
                                <table id="allBooksTable" class="table table-hover align-middle table-custom">
                                    <thead class="table-light">
                                        <tr>
                                            <th id="sortHash" style="cursor: pointer;" title="Sắp xếp theo Đã bán (giảm dần)">#<i class="fa-solid fa-sort"></i></th>
                                            <th>HÌNH ẢNH</th>
                                            <th>TÊN SÁCH & TÁC GIẢ</th>
                                            <th>THỂ LOẠI</th>
                                            <th>GIÁ BÁN</th>
                                            <th class="text-center">TỒN KHO</th>
                                            <th class="text-end">ĐÃ BÁN</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <%
                                            List<books> allBooks = (List<books>) request.getAttribute("allBooks");
                                            if (allBooks != null) {
                                                int rowNo = 1;
                                                for (books b : allBooks) {
                                                    String img = b.getImageUrl() != null ? b.getImageUrl() : "";
                                                    String name = b.getBookName() != null ? b.getBookName() : "";
                                                    String author = b.getAuthor() != null ? b.getAuthor() : "";
                                                    String cat = b.getCategory() != null ? b.getCategory() : "";
                                                    String badgeClass = b.getQuantity() <= 10 ? "bg-danger" : "bg-success";
                                        %>
                                        <tr>
                                            <td>
                                                <% if (rowNo <= 3) { %>
                                                    <span class="medal medal-<%= rowNo %>"><%= rowNo %></span>
                                                <% } else { %>
                                                    <%= rowNo %>
                                                <% } %>
                                            </td>
                                            <td><img src="<%=request.getContextPath()%>/image?name=<%= img %>" alt="Book" class="rounded" style="width:40px;" onerror="this.src='https://via.placeholder.com/40x55'"></td>
                                            <td>
                                                <strong><%= name %></strong><br>
                                                <small class="text-muted"><%= author %></small>
                                            </td>
                                            <td><%= cat %></td>
                                            <td><%= String.format("%,.0f", b.getSellingPrice()) %> đ</td>
                                            <td class="text-center"><span class="badge <%= badgeClass %>"><%= b.getQuantity() %></span></td>
                                            <td class="text-end"><%= b.getSold() %></td>
                                        </tr>
                                        <%
                                                rowNo++;
                                                }
                                                if (allBooks.isEmpty()) {
                                        %>
                                        <tr><td colspan="7" class="text-center text-muted">Chưa có sách trong kho.</td></tr>
                                        <%
                                                }
                                            }
                                        %>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            (function () {
                var table = document.getElementById('allBooksTable');
                if (!table) return;
                var tbody = table.tBodies[0];
                var hashTh = document.getElementById('sortHash');
                var icon = hashTh.querySelector('i');
                // Mặc định: sắp xếp Đã bán giảm dần (DESC).
                var asc = false;

                function sortRows() {
                    var allRows = Array.prototype.slice.call(tbody.querySelectorAll('tr'));
                    var dataRows = allRows.filter(function (r) { return r.children.length >= 7; });
                    var msgRows = allRows.filter(function (r) { return r.children.length < 7; });

                    dataRows.sort(function (a, b) {
                        var av = parseInt((a.children[6].textContent || '0').replace(/[^\d]/g, ''), 10) || 0;
                        var bv = parseInt((b.children[6].textContent || '0').replace(/[^\d]/g, ''), 10) || 0;
                        return asc ? av - bv : bv - av;
                    });

                    // Đánh số cột # từ 1 đến hết theo thứ tự hiển thị hiện tại,
                    // top 3 hiển thị huy chương (vàng/bạc/đồng).
                    dataRows.forEach(function (r, k) {
                        var num = k + 1;
                        var cell = r.children[0];
                        if (num <= 3) {
                            cell.innerHTML = '<span class="medal medal-' + num + '">' + num + '</span>';
                        } else {
                            cell.textContent = num;
                        }
                        tbody.appendChild(r);
                    });
                    msgRows.forEach(function (r) { tbody.appendChild(r); });

                    if (icon) {
                        icon.className = asc ? 'fa-solid fa-sort-up' : 'fa-solid fa-sort-down';
                    }
                }

                // Sắp xếp mặc định theo Đã bán (DESC) khi tải trang.
                sortRows();

                hashTh.addEventListener('click', function () {
                    asc = !asc;
                    sortRows();
                });

                // ---- Tìm kiếm: lọc theo tên sách, tác giả, thể loại ----
                var searchInput = document.getElementById('allBooksSearchInput');
                if (searchInput) {
                    searchInput.addEventListener('input', function () {
                        var term = searchInput.value.trim().toLowerCase();
                        var dataRows = Array.prototype.slice.call(tbody.querySelectorAll('tr'))
                            .filter(function (r) { return r.children.length >= 7; });
                        dataRows.forEach(function (r) {
                            var nameAuthor = (r.children[2].textContent || '').toLowerCase();
                            var cat = (r.children[3].textContent || '').toLowerCase();
                            var match = nameAuthor.indexOf(term) !== -1 || cat.indexOf(term) !== -1;
                            r.style.display = match ? '' : 'none';
                        });
                    });
                }
            })();
        </script>
    </body>
</html>
