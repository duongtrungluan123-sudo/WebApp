<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="structure.login" %>
<%@ page import="structure.books" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="structure.Invoice"%>
<%@ page import="structure.schedule" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Nhà Sách Minh Châu</title>
        <link rel="icon" href="<%=request.getContextPath()%>/favicon.svg" type="image/svg+xml">
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="<%=request.getContextPath()%>/css/admin.css">
    </head>
    <body>
        <%
            // Kiểm tra đăng nhập và role ADMIN
            structure.login user = (structure.login) session.getAttribute("user");
            if (user == null || !"Quản Lý".equals(user.getRole())) {
                session.setAttribute("error", "Vui lòng đăng nhập tài khoản admin");
                response.sendRedirect(request.getContextPath() + "/index.jsp");
                return;
            }
        %>

        <% String error = (String) session.getAttribute("error"); %>
        <% String Editerror = (String) session.getAttribute("Editerror"); %>
        <% String employeeError = (String) session.getAttribute("employeeError");%>
        <% String employeeEditError = (String) session.getAttribute("employeeEditError");%>
        



        <div class="layout">
            <!-- Sidebar với thanh chọn -->
            <nav class="sidebar">
                <div class="sidebar-brand">
                    <i class="fa-solid fa-book-open"></i>
                    <div class="brand-text">
                        <span class="brand-name">Nhà Sách Minh Châu</span>
                        <span class="brand-sub">Hệ thống quản lý</span>
                    </div>
                </div>
                <ul class="sidebar-menu">
                    <li class="<%= "dashboard".equals(request.getParameter("page")) ? "active" : "" %>">
                        <a href="<%=request.getContextPath()%>/dashboard"><i class="fa-solid fa-chart-column"></i> Báo Cáo Doanh Thu</a>
                    </li>
                    <li class="<%= "books".equals(request.getAttribute("tableName")) ? "active" : "" %>">
                        <a href="<%=request.getContextPath()%>/data?table=books"><i class="fa-solid fa-book"></i> Quản Lý Sách</a>
                    </li>
                    <li class="<%= "employees".equals(request.getAttribute("tableName")) ? "active" : "" %>">
                        <a href="<%=request.getContextPath()%>/data?table=employees"><i class="fa-solid fa-users"></i> Quản Lý Nhân Viên</a>
                    </li>
                    <li class="<%= "book-efficiency".equals(request.getParameter("page")) ? "active" : "" %>">
                        <a href="<%=request.getContextPath()%>/book-efficiency"><i class="fa-solid fa-arrow-trend-up"></i> Hiệu Suất Bán Hàng</a>
                    </li>
                    <li class="<%= "invoices".equals(request.getAttribute("tableName")) ? "active" : "" %>">
                        <a href="<%=request.getContextPath()%>/data?table=invoices"><i class="fa-regular fa-clock"></i> Quản Lý Hóa Đơn</a>
                    </li>
                    <li class="<%= "viewSchedule".equals(request.getParameter("page")) ? "active" : "" %>">
                        <a href="<%=request.getContextPath()%>/viewSchedule"><i class="fa-solid fa-calendar-days"></i> Lịch làm việc</a>
                    </li>
                </ul>

                <div class="sidebar-footer">
                    <%
                        structure.login headerUser = (structure.login) session.getAttribute("user");
                        String headerName = (headerUser != null && headerUser.getUsername() != null && !headerUser.getUsername().isBlank())
                                ? headerUser.getUsername() : "Người dùng";
                        String headerRole = (headerUser != null && headerUser.getRole() != null) ? headerUser.getRole() : "";
                        String headerInitial = headerName.substring(0, 1).toUpperCase();
                    %>
                    <div class="header-user">
                        <div class="avatar"><%= headerInitial %></div>
                        <span><%= headerName %><br><small><%= headerRole %></small></span>
                    </div>
                    <button class="logout-btn" onclick="window.location.href='<%=request.getContextPath()%>/index.jsp'">
                        <i class="fa-solid fa-right-from-bracket"></i> Đăng xuất
                    </button>
                </div>
            </nav>

            <!-- Nội dung chính -->
            <div class="main-content">
                <div class="header">
                    <%  String tableName = (String) request.getAttribute("tableName");
                        String title = "";
                        String selectedEmp = (String) request.getAttribute("employeeName");

                        if("employees".equals(tableName)){
                            title = "Quản Lý Nhân Viên";
                        } else if ("books".equals(tableName)){
                            title = "Quản Lý Sách";
                        } else if("invoices".equals(tableName)){
                            title = "Quản Lý Hóa Đơn";
                        }
                    %>
                    

                    <h1><%= title %></h1>

                    <% if ("employees".equals(tableName)) { %>
                        <input type="text" id="employeeSearchInput" class="EmployeeSearch-bar" placeholder="Tìm Nhân Viên, Số Điện Thoại...">
                        <a href="<%=request.getContextPath()%>/viewSchedule" class="btn btn-add">
                            <i class="fa-solid fa-calendar-days"></i> Xem lịch Làm Việc
                        </a>

                    <% } else if ("books".equals(tableName)) { %>
                        <input type="text" id="bookSearchInput" class="search-bar" placeholder="Tìm Sách, Tác Giả...">

                    <% } else if ("invoices".equals(tableName)) { %>
                        <div class="filters" id="invoiceEmployeeBar" style="margin:0;">
                            <button type="button" class="filter-btn ${empty employeeName ? 'active' : ''}"
                                    onclick="window.location.href='<%=request.getContextPath()%>/data?table=invoices'">Tất cả</button>
                            <c:forEach var="emp" items="${employees}">
                                <button type="button" class="filter-btn ${emp.username eq employeeName ? 'active' : ''}"
                                        onclick="window.location.href='<%=request.getContextPath()%>/data?table=invoices&employeeName=${emp.username}'">${emp.username}</button>
                            </c:forEach>
                        </div>
                    <%
                        }
                    %>

                    <% if ("employees".equals(tableName)) { %>
                        <button type="button" class="btn btn-add" data-bs-toggle="modal" data-bs-target="#addEmployeeModal">
                            <i class = "fa-solid fa-user-plus"></i>Thêm Nhân Viên
                        </button>
                    <% } else if ("books".equals(tableName)) {%>
                        <button type="button" class="btn btn-add" data-bs-toggle="modal" data-bs-target="#addBookModal">
                            <i class = "fa-solid fa-plus"></i>Thêm Sách
                        </button>
                        <button type="button" class="btn btn-add" data-bs-toggle="modal" data-bs-target="#categoryModal" style="margin-left: 10px;">
                            <i class="fa-solid fa-tags"></i> Quản lý thể loại
                        </button>
                    <% } %>

                </div>

                <!-- Hàng chọn thể loại (chỉ hiển thị ở mục Quản lý sách) -->
                <% if ("books".equals(tableName)) { %>
                <div class="filters" id="bookFilterBar">
                    <button class="filter-btn active" data-cat="Tất cả">Tất cả</button>
                    <c:forEach var="c" items="${categoryList}">
                        <button class="filter-btn" data-cat="${c.categoryName}">${c.categoryName}</button>
                    </c:forEach>
                </div>
                <% } %>

                <%
                    String successMsg = (String) session.getAttribute("successMessage");
                    String errorMsg = (String) session.getAttribute("errorMessage");
                    
                    if (successMsg != null) {
                %>
                    <div class="alert alert-success"><%= successMsg %></div>
                <%
                        session.removeAttribute("successMessage"); 
                    }
                    
                    if (errorMsg != null) {
                %>
                    <div class="alert alert-danger"><%= errorMsg %></div>
                <%
                        session.removeAttribute("errorMessage"); // Xóa ngay sau khi hiển thị
                    }
                %>

                <%
                    if ("employees".equals(tableName)) {

                        List<structure.login> employees =
                            (List<structure.login>) request.getAttribute("employees");

                        // Calculate dates for shift scheduling dropdown (tomorrow + 4 days)
                        java.util.Calendar cal = java.util.Calendar.getInstance();
                        cal.add(java.util.Calendar.DAY_OF_MONTH, 1); // tomorrow
                        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy");
                        java.text.SimpleDateFormat sdfValue = new java.text.SimpleDateFormat("yyyy-MM-dd");
                        String[] shiftDates = new String[5];
                        String[] shiftDateValues = new String[5];
                        for (int i = 0; i < 5; i++) {
                            shiftDates[i] = sdf.format(cal.getTime());
                            shiftDateValues[i] = sdfValue.format(cal.getTime());
                            cal.add(java.util.Calendar.DAY_OF_MONTH, 1);
                        }
                        request.setAttribute("shiftDates", shiftDates);
                        request.setAttribute("shiftDateValues", shiftDateValues);

                        database.DataDao scheduleDao = new database.DataDao();
                        List<schedule> weekSchedules = new java.util.ArrayList<>();
                        if (shiftDateValues[0] != null) {
                            weekSchedules = scheduleDao.getAllSchedulesByDateRange(shiftDateValues[0], shiftDateValues[4]);
                        }
                %>

                <script>
                    const allSchedules = [
                        <% for (int i = 0; i < weekSchedules.size(); i++) {
                            schedule s = weekSchedules.get(i);
                        %>
                        {
                            employeeId: <%= s.getEmployeeId() %>,
                            workDate: "<%= s.getWorkDate().toString() %>",
                            shift: "<%= s.getShift() %>"
                        }<%= (i < weekSchedules.size() - 1) ? "," : "" %>
                        <% } %>
                    ];
                </script>
                
                <% 
                    if (employees == null || employees.isEmpty()) { 
                %>

                <div class="loading">Không có dữ liệu nhân viên</div>

                <%
                        } else {
                %>

                <!-- Bảng 1: Xếp ca làm -->
                <div class="shift-schedule-section">
                    <h3 class="section-title">Xếp ca làm</h3>
                    <div class="shift-date-selector">
                        <label for="shiftDateSelect">Ngày:</label>
                        <select id="shiftDateSelect" name="workDate" class="form-select" style="width: auto; display: inline-block;">
                            <c:forEach var="i" begin="0" end="4">
                                <option value="${shiftDateValues[i]}" ${i == 0 ? 'selected' : ''}>${shiftDates[i]}</option>
                            </c:forEach>
                        </select>
                        <button type="button" id="saveShiftBtn" class="btn btn-add">
                            <i class="fa-solid fa-save"></i> Lưu ca làm
                        </button>
                        <button type="button" id="deleteShiftBtn" class="btn btn-add" style="margin-left: 10px">
                            <i class="fa-solid fa-trash"></i> Xóa ca làm
                        </button>
                    </div>
                    <div class="shift-table-container" style="overflow-x: auto;">
                        <table class="data-table shift-table">
                            <thead>
                                <tr>
                                    <th class="shift-col-shift" style="position: sticky; left: 0; z-index: 1; background: #fff;">Ca làm</th>
                                    <c:forEach var="emp" items="${employees}">
                                        <c:if test="${emp.role != 'Quản Lý'}">
                                            <th class="shift-col-emp" style="min-width: 120px; text-align: center;">${emp.username}</th>
                                        </c:if>
                                    </c:forEach>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="shift-col-shift" style="position: sticky; left: 0; z-index: 1; background: #fff; font-weight: 500;">Ca Sáng</td>
                                    <c:forEach var="emp" items="${employees}">
                                        <c:if test="${emp.role != 'Quản Lý'}">
                                            <td class="shift-col-emp" style="text-align: center;">
                                                <label class="shift-employee-checkbox">
                                                    <input type="checkbox" name="employeeId" value="${emp.id}" data-shift="Sáng" data-emp-name="${emp.username}">
                                                    <span class="visually-hidden">Ca Sáng - ${emp.username}</span>
                                                </label>
                                            </td>
                                        </c:if>
                                    </c:forEach>
                                </tr>
                                <tr>
                                    <td class="shift-col-shift" style="position: sticky; left: 0; z-index: 1; background: #fff; font-weight: 500;">Ca Chiều</td>
                                    <c:forEach var="emp" items="${employees}">
                                        <c:if test="${emp.role != 'Quản Lý'}">
                                            <td class="shift-col-emp" style="text-align: center;">
                                                <label class="shift-employee-checkbox">
                                                    <input type="checkbox" name="employeeId" value="${emp.id}" data-shift="Chiều" data-emp-name="${emp.username}">
                                                    <span class="visually-hidden">Ca Chiều - ${emp.username}</span>
                                                </label>
                                            </td>
                                        </c:if>
                                    </c:forEach>
                                </tr>
                                <tr>
                                    <td class="shift-col-shift" style="position: sticky; left: 0; z-index: 1; background: #fff; font-weight: 500;">Cả Ngày</td>
                                    <c:forEach var="emp" items="${employees}">
                                        <c:if test="${emp.role != 'Quản Lý'}">
                                            <td class="shift-col-emp" style="text-align: center;">
                                                <label class="shift-employee-checkbox">
                                                    <input type="checkbox" name="employeeId" value="${emp.id}" data-shift="Cả ngày" data-emp-name="${emp.username}">
                                                    <span class="visually-hidden">Cả Ngày - ${emp.username}</span>
                                                </label>
                                            </td>
                                        </c:if>
                                    </c:forEach>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Bảng 2: Thông tin nhân viên -->
                <div class="employee-info-section">
                    <h3 class="section-title">Thông tin nhân viên</h3>
                    <table class="data-table">

                        <thead>
                            <tr>
                                <th>Tên Nhân Viên</th>
                                <th>Tài Khoản Email</th>
                                <th>Số Điện Thoại</th>
                                <th>Mật Khẩu</th>
                                <th>Quyền Hạn</th>
                                <th>Hành Động</th>
                            </tr>
                        </thead>
                        <tbody id="employeeTableBody">
                            <% for (structure.login emp : employees) { %>
                            <tr data-username="<%= emp.getUsername() != null ? emp.getUsername() : "" %>"
                                data-phone="<%= emp.getPhone() != null ? emp.getPhone() : "" %>"
                                data-email="<%= emp.getEmail() != null ? emp.getEmail() : "" %>">
                                <td><%= emp.getUsername() %></td>
                                <td><%= emp.getEmail() %></td>
                                <td><%= emp.getPhone() %></td>
                                <td><%= emp.getPassword() %></td>
                                <td><%= emp.getRole() %></td>
                                <td>
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#editEmployeeModal" data-id="<%= emp.getId() %>"
                                    data-username="<%= emp.getUsername() %>"
                                    data-email="<%= emp.getEmail() %>"
                                    data-phone="<%= emp.getPhone() %>"
                                    data-password="<%= emp.getPassword() %>"
                                    data-role="<%= emp.getRole() %>"
                                    class="btn btn-view btn-sm"
                                    style="margin-right: 5px;">
                                    <i class="fa-solid fa-pencil" style="font-size:12px; height:12px; width:12px; display:inline-block;" aria-hidden="true"></i></a>

                                    <a href="<%=request.getContextPath()%>/employees?action=delete&id=<%= emp.getId() %>"
                                    class="btn btn-view btn-sm"
                                    onclick="return confirm('Bạn có chắc muốn xóa nhân viên này không?')">
                                    <i class="fa-solid fa-trash" style="font-size:12px; height:12px; width:12px; display:inline-block;" aria-hidden="true"></i></a>
                                </td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                </div>

                <%
                        }
                
                    } 
                %>
        <%  String bookSuccess = (String) session.getAttribute("success");
            String bookError = (String) session.getAttribute("error");
            
            if (bookSuccess != null) {
        %>
            <div class="alert alert-success"><%= bookSuccess %></div>
        <%
                session.removeAttribute("success"); 
            }
            
            if (bookError != null) {
        %>
            <div class="alert alert-danger"><%= bookError %></div>
        <%
                session.removeAttribute("error"); // Xóa ngay sau khi hiển thị
            }
        %>


        <%  String invoiceSuccess = (String) session.getAttribute("invoiceSuccess");
            String invoiceError = (String) session.getAttribute("invoiceError");
            
            if (invoiceSuccess != null) {
        %>
            <div class="alert alert-success"><%= invoiceSuccess %></div>
        <%
                session.removeAttribute("invoiceSuccess"); 
            }
            
            if (invoiceError != null) {
        %>
            <div class="alert alert-danger"><%= invoiceError %></div>
        <%
                session.removeAttribute("invoiceError"); // Xóa ngay sau khi hiển thị
            }
        %>
                    
                    
                <%    if ("books".equals(tableName)) {

                        List<structure.books> books =
                            (List<structure.books>) request.getAttribute("books");

                        if (books == null || books.isEmpty()) {
                %>

                <div class="loading">Không có dữ liệu sách</div>

                <%
                        } else {
                %>

                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Hình Ảnh</th>
                            <th>Tên Sách</th>
                            <th>Tác Giả</th>
                            <th>Thể Loại</th>
                            <th>Số Trang</th>
                            <th>Năm Xuất Bản</th>
                            <th>Tồn Kho</th>
                            <th>Giá Bán</th>
                            <th>Hành Động</th>
                        </tr>
                    </thead>
                    <tbody id="bookTableBody">
                        <% for (structure.books book : books) { %>
                            <% String badgeClass = book.getQuantity() <= 10 ? "bg-danger" : "bg-success";%>
                        <tr data-name="<%= book.getBookName() != null ? book.getBookName() : "" %>"
                            data-author="<%= book.getAuthor() != null ? book.getAuthor() : "" %>"
                            data-category="<%= book.getCategory() != null ? book.getCategory() : "" %>">
                            <td><img src="<%=request.getContextPath()%>/image?name=<%= book.getImageUrl() %>"alt="Ảnh sách" width="80" height="120" style="object-fit: cover; border-radius: 5px;"></td>
                            <td><%= book.getBookName() %></td>
                            <td><%= book.getAuthor() %></td>
                            <td><%= book.getCategory() %></td>
                            <td><%= book.getBookPage() %>tr</td>
                            <td><%= book.getPublicYear() %></td>
                            <td><span class = "badge <%= badgeClass %>" style = "font-size:14px; font-weight:normal"><%= book.getQuantity() %></span></td>
                            <td><%= String.format("%,.0f VNĐ", book.getSellingPrice()) %></td>
                            <td>
                                <a href="#" data-bs-toggle="modal" data-bs-target="#editBookModal" 
                                data-id="<%= book.getBook_id() %>"
                                data-image_url="<%= book.getImageUrl() %>"
                                data-book_name="<%= book.getBookName() %>"
                                data-author="<%= book.getAuthor() %>"
                                data-category_id="<%= book.getCategory_id() %>"
                                data-book_page="<%= book.getBookPage() %>"
                                data-publicyear="<%= book.getPublicYear() %>"
                                data-quantity="<%= book.getQuantity() %>"
                                data-selling_price="<%= book.getSellingPrice() %>"
                                class="btn btn-view btn-sm"
                                style="margin-right: 5px;"
                                onclick="openEditModal(this)">
                                <i class="fa-solid fa-pencil" style="font-size:12px; height:12px; width:12px; display:inline-block;" aria-hidden="true"></i></a>

                                <a href="<%=request.getContextPath()%>/books?action=delete&id=<%= book.getBook_id() %>"
                                class="btn btn-view btn-sm"
                                onclick="return confirm('Bạn có chắc muốn xóa sách này không?')">
                                <i class="fa-solid fa-trash" style="font-size:12px; height:12px; width:12px; display:inline-block;" aria-hidden="true"></i></a>
                            </td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>

                <%
                        }

                    
                    } else if ("invoices".equals(tableName)) {

                        List<Invoice> invoices =
                            (List<Invoice>) request.getAttribute("invoices");

                        if (invoices == null || invoices.isEmpty()) {
                %>

                            <div class="loading">Không có dữ liệu hóa đơn</div>

                <%
                        } else{
                %>
                
                <!--Quản lý hóa đơn!-->
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Ngày Lập</th>
                            <th>Tên Nhân Viên</th>
                            <th>Tên Khách Hàng</th>
                            <th>Số Điện Thoại</th>
                            <th>Tổng Tiền</th>
                            <th>Phương Thức Thanh Toán</th>
                            <th>Hành Động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <%
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            String currentDate = "";

                            for (Invoice invoice : invoices) {

                                String invoiceDate = sdf.format(invoice.getInvoiceDate());

                                if (!invoiceDate.equals(currentDate)) {
                                    currentDate = invoiceDate;
                            %>

                            <tr class="day-header-row">
                                <td colspan="7" style = "background-color: #efe6d6">
                                    <strong>📅 Ngày <%= currentDate %></strong>
                                </td>
                            </tr>

                            <%
                                }
                            %>

                            <tr>
                                <td><%= invoiceDate %></td>
                                <td><%= invoice.getEmployeeName() %></td>
                                <td><%= invoice.getCustomerName() != null ? invoice.getCustomerName() : "-" %></td>
                                <td><%= invoice.getCustomerPhone() != null ? invoice.getCustomerPhone() : "-" %></td>
                                <td><%= String.format("%,.0f VNĐ", invoice.getTotalAmount()) %></td>
                                <td><%= invoice.getPaymentMethod() %></td>
                                <td>
                                    <button type="button" 
                                            class="btn btn-view btn-sm" 
                                            onclick="viewPdfModal('<%=request.getContextPath()%>/invoice/pdf?invoiceId=<%= invoice.getId() %>')">
                                        <i class="fa-solid fa-eye me-1"></i>
                                    </button>
                                    <a href="<%=request.getContextPath()%>/data?table=invoices&action=delete&id=<%= invoice.getId() %>" class="btn btn-view btn-sm"
                                        onclick="return confirm('Bạn có chắc muốn xóa hóa đơn này không?')">
                                        <i class="fa-solid fa-trash" style="font-size:12px; height:12px; width:12px; display:inline-block;" aria-hidden="true"></i>
                                    </a>
                                </td>
                            </tr>

                            <%
                            }
                            %>
                    </tbody>
                </table>

                <%
                    Integer currentPage = (Integer) request.getAttribute("currentPage");
                    Integer totalPages = (Integer) request.getAttribute("totalPages");
                    String currentEmployeeName = (String) request.getAttribute("employeeName");
                    if (currentPage == null) currentPage = 1;
                    if (totalPages == null) totalPages = 1;
                %>

                <% if (totalPages > 1) { %>
                <nav aria-label="Phân trang hóa đơn" class="mt-4">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <%= currentPage <= 1 ? "disabled" : "" %>">
                            <a class="page-link" href="<%=request.getContextPath()%>/data?table=invoices&page=<%= currentPage - 1 %><%= currentEmployeeName != null && !currentEmployeeName.trim().isEmpty() ? "&employeeName=" + currentEmployeeName : "" %>">Trước</a>
                        </li>
                        <%
                            int startPage = Math.max(1, currentPage - 2);
                            int endPage = Math.min(totalPages, currentPage + 2);
                            for (int i = startPage; i <= endPage; i++) {
                        %>
                        <li class="page-item <%= i == currentPage ? "active" : "" %>">
                            <a class="page-link" href="<%=request.getContextPath()%>/data?table=invoices&page=<%= i %><%= currentEmployeeName != null && !currentEmployeeName.trim().isEmpty() ? "&employeeName=" + currentEmployeeName : "" %>"><%= i %></a>
                        </li>
                        <% } %>
                        <li class="page-item <%= currentPage >= totalPages ? "disabled" : "" %>">
                            <a class="page-link" href="<%=request.getContextPath()%>/data?table=invoices&page=<%= currentPage + 1 %><%= currentEmployeeName != null && !currentEmployeeName.trim().isEmpty() ? "&employeeName=" + currentEmployeeName : "" %>">Sau</a>
                        </li>
                    </ul>
                </nav>
                <% } %>

                <%
                        }
                    }
                %>
            </div>
        </div>



        <%
            // Lấy lại các giá trị cũ từ session
            String oldName = (String) session.getAttribute("username");
            String oldEmail = (String) session.getAttribute("email");
            String oldPhone = (String) session.getAttribute("phone");
            String oldPassword = (String) session.getAttribute("password");
        %>
        <!-- Modal Thêm Nhân Viên -->
        <div class="modal fade" id="addEmployeeModal" tabindex="-1" aria-labelledby="addEmployeeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-scrollable">
                <div class="modal-content">
                    <form action="<%=request.getContextPath()%>/employees" method="post">
                        <input type="hidden" name="action" value="add">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addEmployeeModalLabel">Thêm Nhân Viên Mới</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <%
                                    if (employeeError != null) {
                                    %>
                                        <div class="alert alert-danger" id="employeeError">
                                            <%= employeeError %>
                                        </div>
                                    <%
                                        session.removeAttribute("employeeError");
                                    }
                            %>
                            <div class="mb-3">
                                <label for="username" class="form-label">Tên Nhân Viên</label>
                                <input type="text" class="form-control" id="username" name="username" value="<%= oldName != null ? oldName : "" %>" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" value="<%= oldEmail != null ? oldEmail : "" %>" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Số Điện Thoại</label>
                                <input type="tel" class="form-control" id="phone" name="phone" value="<%= oldPhone != null ? oldPhone : "" %>" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Mật Khẩu</label>
                                <input type="password" class="form-control" id="password" name="password" value="<%= oldPassword != null ? oldPassword : "" %>" required>
                            </div>
                            <div class="mb-3">
                                <label for="role" class="form-label">Quyền Hạn</label>
                                <select class="form-select" id="role" name="role" required>
                                    <option value="Nhân Viên">Nhân Viên</option>
                                    <option value="Quản Lý">Quản Lý</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                            <button type="submit" class="btn btn-primary">Thêm</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <%
            // Lấy lại các giá trị cũ từ session
            session.removeAttribute("username");
            session.removeAttribute("email");
            session.removeAttribute("phone");
            session.removeAttribute("password");
        %>



        <!-- Modal Sửa Nhân Viên -->
        <%
            // Lấy lại các giá trị cũ từ session
            Integer oldId = (Integer) session.getAttribute("editid");
            oldName = (String) session.getAttribute("editusername");
            oldEmail = (String) session.getAttribute("editemail");
            oldPhone = (String) session.getAttribute("editphone");
            oldPassword = (String) session.getAttribute("editpassword");
        %>

        <div class="modal fade" id="editEmployeeModal" tabindex="-1" aria-labelledby="editEmployeeModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<%=request.getContextPath()%>/employees" method="post">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" id="editid" name="id" value="<%= oldId != null ? oldId : "" %>">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editEmployeeModalLabel">Thay Đổi Thông Tin Nhân Viên</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <%
                                    if (employeeEditError != null) {
                                    %>
                                        <div class="alert alert-danger" id="employeeEditError">
                                            <%= employeeEditError %>
                                        </div>
                                    <%
                                        session.removeAttribute("employeeEditError");
                                    }
                            %>
                            <div class="mb-3">
                                <label for="username" class="form-label">Tên Nhân Viên</label>
                                <input type="text" class="form-control" id="editusername" name="username" value="<%= oldName != null ? oldName : "" %>" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="editemail" name="email" value="<%= oldEmail != null ? oldEmail : "" %>" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Số Điện Thoại</label>
                                <input type="tel" class="form-control" id="editphone" name="phone" value="<%= oldPhone != null ? oldPhone : "" %>" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Mật Khẩu</label>
                                <input type="password" class="form-control" id="editpassword" name="password" value="<%= oldPassword != null ? oldPassword : "" %>" required>
                            </div>
                            <div class="mb-3">
                                <label for="role" class="form-label">Quyền Hạn</label>
                                <select class="form-select" id="editrole" name="role" required>
                                    <option value="Nhân Viên">Nhân Viên</option>
                                    <option value="Quản Lý">Quản Lý</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                            <button type="submit" class="btn btn-primary">Lưu Thay Đổi</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <%
            // Lấy lại các giá trị cũ từ session
            session.removeAttribute("editid");
            session.removeAttribute("editUsername");
            session.removeAttribute("editEmail");
            session.removeAttribute("editPhone");
            session.removeAttribute("editPassword");
        %>
        

        
        

        <!-- Modal Thêm Sách !-->
        <%
            // Lấy lại các giá trị cũ từ session
            String oldBookName = (String) session.getAttribute("book_name"); 
            String oldAuthor = (String) session.getAttribute("author"); 
            Integer oldCategoryId = (Integer) session.getAttribute("category_id"); 
            Integer oldBookPage = (Integer) session.getAttribute("book_page"); 
            Integer oldPublicYear = (Integer) session.getAttribute("publicyear"); 
            Integer oldQuantity = (Integer) session.getAttribute("quantity"); 
            Double oldSellingPrice = (Double) session.getAttribute("selling_price");
        %>

        <div class="modal fade" id="addBookModal" tabindex="-1" aria-labelledby="addbooksModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form action="<%=request.getContextPath()%>/books" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="add">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addbooksModalLabel">Thêm Sách Mới</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <%
                                if (error != null) {
                                %>
                                    <div class="alert alert-danger" id="bookError">
                                        <%= error %>
                                    </div>
                                <%
                                    session.removeAttribute("error");
                                }
                            %>
                            <div class="row">
                                <!-- Cột trái -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                            <label class="form-label">Ảnh</label><br>
                                            <label for="addimage_url" class="custom-file-upload">
                                                <span class="btn-upload">Chọn tệp</span>
                                                <span id="add-file-name">Chưa chọn tệp nào</span>
                                            </label>
                                        <input type="file" class="form-control" id="addimage_url" name="image_url" accept="image/*" style="display:none;">
                                    </div>

                                    <div class="mb-3">
                                        <label for="book_name" class="form-label">Tên Sách</label>
                                        <input type="text" class="form-control" id="book_name" name="book_name" value = "<%= oldBookName != null ? oldBookName : "" %>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="author" class="form-label">Tác Giả</label>
                                        <input type="text" class="form-control" id="author" name="author" value="<%= oldAuthor != null ? oldAuthor : "" %>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="category_id" class="form-label">Thể loại</label>
                                        <select class="form-select" id="category_id" name="category_id">
                                            <c:forEach var="c" items="${categoryList}">
                                                <option value="${c.id}"
                                                    <%= oldCategoryId != null && oldCategoryId == ((structure.categories) pageContext.getAttribute("c")).getId()
                                                            ? "selected" : "" %>>
                                                    ${c.categoryName}
                                                </option>
                                            </c:forEach>
                                        </select>
                                    </div>
                                </div>

                                <!-- Cột phải -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="book_page" class="form-label">Số Trang</label>
                                        <input type="number" class="form-control" id="book_page" name="book_page" value="<%= oldBookPage != null ? oldBookPage : "" %>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="publicyear" class="form-label">Năm Xuất Bản</label>
                                        <input type="number" class="form-control" id="publicyear" name="publicyear" value="<%= oldPublicYear != null ? oldPublicYear : "" %>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="quantity" class="form-label">Tồn Kho</label>
                                        <input type="number" class="form-control" id="quantity" name="quantity" value="<%= oldQuantity != null ? oldQuantity : "" %>" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="selling_price" class="form-label">Giá Bán</label>
                                        <input type="number" step="0.01" class="form-control" id="selling_price" name="selling_price" value="<%= oldSellingPrice != null ? oldSellingPrice : "" %>" required>
                                    </div>
                                </div>
                            </div>
                        </div> 
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                            <button type="submit" class="btn btn-primary">Thêm</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <%
            session.removeAttribute("book_name");
            session.removeAttribute("author");
            session.removeAttribute("category_id");
            session.removeAttribute("book_page");
            session.removeAttribute("publicyear");
            session.removeAttribute("quantity");
            session.removeAttribute("selling_price");
            session.removeAttribute("error");
        %>


        <!-- Modal sửa sách !-->
        <div class="modal fade" id="editBookModal" tabindex="-1" aria-labelledby="editBookModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form action="<%=request.getContextPath()%>/books" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" id="editbookid" name="id">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editBookModal">Thay Đổi Thông Tin Sách</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <%
                                String editError = (String) session.getAttribute("editError");
                                if (editError != null) {
                            %>
                                <div class="alert alert-danger" id="editBookError">
                                    <%= editError %>
                                </div>
                            <%
                                session.removeAttribute("editError");
                            }
                            %>
                        <div class="mb-3">
                            <label class="form-label">Ảnh hiện tại</label><br>
                            <img id="previewImage"
                                src=""
                                alt="Ảnh sách"
                                style="width:120px; height:160px; object-fit:cover; border:1px solid #ccc; margin-bottom:10px;">
                        </div>
                            <div class = "row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                    <label class="form-label">Ảnh thay thế (nếu có)</label><br>
                                    
                                    <!-- Bọc trong label để khi click vào nút giả, input file vẫn kích hoạt -->
                                    <label for="editimage_url" class="custom-file-upload">
                                        <span class="btn-upload">Chọn tệp</span>
                                        <span id="file-name">Chưa chọn tệp nào</span>
                                    </label>
                                    
                                    <!-- Ẩn input mặc định đi -->
                                    <input type="file" class="form-control" id="editimage_url" name="image_url" accept="image/*" style="display: none;">
                                </div>
                                    <div class="mb-3">
                                        <label for="book_name" class="form-label">Tên Sách</label>
                                        <input type="text" class="form-control" id="editbook_name" name="book_name" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="author" class="form-label">Tác Giả</label>
                                        <input type="text" class="form-control" id="editauthor" name="author" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="book_name" class="form-label">Thể loại</label>
                                        <select class="form-select" name="category_id" value = "Thể loại">
                                            <c:forEach var="c" items="${categoryList}">
                                                <option value="${c.id}">
                                                    ${c.categoryName}
                                                </option>
                                            </c:forEach>
                                        </select>
                                    </div>
                                </div>

                                <div class = "col-md-6">    
                                    <div class="mb-3">
                                        <label for= "book_page" class="form-label">Số Trang</label>
                                        <input type="number" class="form-control" id="edit_book_page" name="book_page" required>                                
                                    </div>
                                    <div class="mb-3">
                                        <label for="publicyear" class="form-label">Năm Xuất Bản</label>
                                        <input type="number" class="form-control" id="edit_publicyear" name="publicyear" required>                                
                                    </div>
                                    <div class="mb-3">
                                        <label for="quantity" class="form-label">Tồn Kho</label>
                                        <input type="number" class="form-control" id="edit_quantity" name="quantity" required>                                
                                    </div>
                                    <div class="mb-3">
                                        <label for="selling_price" class="form-label">Giá Bán</label>
                                        <input type="number" step = "0.01" class="form-control" id="edit_selling_price" name="selling_price" required>                                
                                    </div>
                                </div>
                            </div>
                        </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                                    <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
                                </div>
                        </form>
                </div>
            </div>
        </div>


        <!-- Modal Quản lý Thể loại -->
        <div class="modal fade" id="categoryModal" tabindex="-1" aria-labelledby="categoryModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="categoryModalLabel">Quản lý thể loại</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Thêm thể loại -->
                        <div class="mb-4">
                            <h6 class="mb-3">Thêm thể loại</h6>
                            <div class="input-group mb-3" style="max-width: 400px;">
                                <input type="text" class="form-control" id="newCategoryInput" placeholder="Nhập tên thể loại" aria-label="Tên thể loại">
                                <button type="button" class="btn btn-primary" id="btnAddCategory"><i class="fa-solid fa-plus me-1"></i> Thêm</button>
                            </div>
                        </div>

                        <hr class="my-3">

                        <!-- Danh sách thể loại -->
                        <h6 class="mb-3" style="width:700px;">Danh sách thể loại</h6>
                        <div class="table-responsive">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th style = "width:130px">Thể loại</th>
                                        <th class="text-center" style="width: 100px;">Số sách</th>
                                        <th class="text-center" style="width: 120px;">Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody id="categoryTableBody">
                                    <c:forEach var="c" items="${categoryList}">
                                        <tr data-id="${c.id}" data-name="${c.categoryName}" data-total="${c.totalbook}">
                                            <td>${c.categoryName}</td>
                                            <td class="text-center">${c.totalbook}</td>
                                            <td>
                                                <!-- Nút Sửa thể loại -->
                                                <button type="button" 
                                                        class="btn btn-sm btn-primary btn-edit-category me-1" 
                                                        onclick="openEditCategoryModal(event, '${c.id}', '${c.categoryName}')" 
                                                        title="Sửa thể loại">
                                                    <i class="fa-solid fa-pen-to-square"></i> Sửa
                                                </button>
                                                <c:if test="${c.totalbook > 0}">
                                                    <button type="button" class="btn btn-sm btn-secondary" disabled title="Đang sử dụng">
                                                        <i class="fa-solid fa-ban me-1"></i> Đang sử dụng
                                                    </button>
                                                </c:if>
                                                <c:if test="${c.totalbook == 0}">
                                                    <button type="button" class="btn btn-sm btn-danger btn-delete-category" data-id="${c.id}" data-name="${c.categoryName}" title="Xóa thể loại">
                                                        <i class="fa-solid fa-trash me-1"></i> Xóa
                                                    </button>
                                                </c:if>
                                            </td>
                                        </tr>
                                    </c:forEach>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Chỉnh sửa thể loại -->
        <div class="modal fade" id="editCategoryModal" style = "z-index: 1060 !important" tabindex="-1" aria-labelledby="editCategoryModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editCategoryModalLabel">Chỉnh sửa thể loại</h5>
                        <button type="button" class="btn-close" onclick="closeEditCategoryModal()" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="editCategoryId">
                        <div class="mb-3">
                            <label for="editCategoryNameInput" class="form-label">Tên thể loại mới</label>
                            <input type="text" class="form-control" id="editCategoryNameInput" placeholder="Nhập tên thể loại mới">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="closeEditCategoryModal()">Hủy</button>
                        <button type="button" class="btn btn-primary" id="btnSaveCategoryEdit">Lưu thay đổi</button>
                    </div>
                </div>
            </div>
        </div>


        <!-- Modal Xem PDF Hóa Đơn -->
        <div class="modal fade" id="pdfViewerModal" tabindex="-1" aria-labelledby="pdfViewerModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-centered" style="height: 90vh;">
                <div class="modal-content h-100" style = "border-radius:8px">
                    <div class="modal-header">
                        <h5 class="modal-title" id="pdfViewerModalLabel">
                            <i class="fa-solid fa-file-pdf text-danger me-2"></i>Chi tiết hóa đơn
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body p-0" style = "height:95vh; max-height:100vh; overflow-y:hidden">
                        <!-- Thẻ iframe để nhúng PDF -->
                        <iframe id="pdfFrame" src="" style="width: 100%; height: 100%; border: none;"></iframe>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Bootstrap JS và jQuery -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


        <!--Add Nhân Viên !-->
        <!-- Mở lại modal nếu có thông báo lỗi Số điện thoại > 10 chữ số Khi thêm nhân viên-->
        <script>
                const addModal = document.getElementById('addEmployeeModal');

                addModal.addEventListener('show.bs.modal', function (event) {
                    if (!event.relatedTarget) return;
                    const button = event.relatedTarget;

                });
            <% if (employeeError != null) { %>
                        document.addEventListener("DOMContentLoaded", function () {
                            const modalElement = document.getElementById("addEmployeeModal");
                            const modal = new bootstrap.Modal(modalElement);
                            modal.show();
                        });
                <%
                    // Xóa session error sau khi đã xử lý hiển thị
                    session.removeAttribute("employeeError");
                    }
                %>

            // Script xóa thông báo lỗi khi người dùng đóng modal
                
            const addEmployeeModal = document.getElementById("addEmployeeModal");
            addEmployeeModal.addEventListener("hidden.bs.modal", function () {
                const errorDiv = document.getElementById("employeeError");
                if (errorDiv) {
                    errorDiv.remove();
                }
                window.location.reload();
            });
            

            //Sửa nhân viên 
            const editModal = document.getElementById('editEmployeeModal');

                editModal.addEventListener('show.bs.modal', function (event) {
                if (!event.relatedTarget) return;
                const button = event.relatedTarget;

                document.getElementById("editid").value = button.dataset.id;
                document.getElementById("editusername").value = button.dataset.username;
                document.getElementById("editemail").value = button.dataset.email;
                document.getElementById("editphone").value = button.dataset.phone;
                document.getElementById("editpassword").value = button.dataset.password;
                document.getElementById("editrole").value = button.dataset.role;
            });
        </script>

        <!-- Mở lại modal nếu có thông báo lỗi Số điện thoại > 10 chữ số Khi thêm nhân viên-->
        <% if (employeeEditError != null) { %>
                <script>
                    document.addEventListener("DOMContentLoaded", function () {
                        const modalElement = document.getElementById("editEmployeeModal");
                        const modal = new bootstrap.Modal(modalElement);
                        modal.show();
                    });
                </script>
            <%
                // Xóa session error sau khi đã xử lý hiển thị
                session.removeAttribute("employeeEditError");
                }
            %>

        

        <!-- Mở lại modal nếu có thông báo lỗi trùng sách-->
                <% if (error != null) { %>
                    <script>
                        document.addEventListener("DOMContentLoaded", function () {
                            const modalElement = document.getElementById("addBookModal");
                            const modal = new bootstrap.Modal(modalElement);
                            modal.show();
                            
                        });
                    </script>
                    <%
                        session.removeAttribute("error");
                    }
        %>

        <!-- Khi tắt mở lại modal thì sẽ xóa thông báo -->
        <script>
            const addBookModal = document.getElementById("addBookModal");

            addBookModal.addEventListener("hidden.bs.modal", function () {
                const errorDiv = document.getElementById("bookError");
                if (errorDiv) {
                    errorDiv.remove();
                }
                window.location.reload();
            });
        </script>

        <!--Sửa Sách !-->
        <script>
            function openEditModal(button) {
                document.getElementById("editbookid").value = button.getAttribute("data-id");
                // Gắp dữ liệu từ nút bấm và nhét vào Form
                document.getElementById("editbookid").value = button.getAttribute("data-id");
                document.getElementById("editbook_name").value = button.getAttribute("data-book_name");
                document.getElementById("editauthor").value = button.getAttribute("data-author");
                document.getElementById("edit_book_page").value = button.getAttribute("data-book_page");
                document.getElementById("edit_publicyear").value = button.getAttribute("data-publicyear");
                document.getElementById("edit_quantity").value = button.getAttribute("data-quantity");
                document.getElementById("edit_selling_price").value = button.getAttribute("data-selling_price");
                
                // Xử lý Thể loại (Category)
                const categorySelect = document.querySelector("#editBookModal select[name='category_id']");
                if(categorySelect) {
                    categorySelect.value = button.getAttribute("data-category_id");
                }

                // Xử lý Ảnh xem trước
                const imageName = button.getAttribute("data-image_url");
                if (imageName && imageName !== "null") {
                    document.getElementById("previewImage").src = "<%=request.getContextPath()%>/image?name=" + imageName;
                } else {
                    document.getElementById("previewImage").src = ""; // Nếu không có ảnh thì để trống
                }
            }

            // 2. Code xử lý đổi chữ khi chọn file (Giữ nguyên như cũ) cho Thêm / Sửa
            document.addEventListener("DOMContentLoaded", function () {
                const addImageUrl = document.getElementById("addimage_url");

                if (addImageUrl) {
                    addImageUrl.addEventListener("change", function () {

                        const fileNameSpan = document.getElementById("add-file-name");

                        if (this.files.length > 0) {
                            fileNameSpan.innerText = this.files[0].name;
                        } else {
                            fileNameSpan.innerText = "Chưa chọn tệp nào";
                        }
                    });
                }

                const editImageUrl = document.getElementById("editimage_url");
                if (editImageUrl) {
                    editImageUrl.addEventListener("change", function () {
                        const fileNameSpan = document.getElementById("file-name");
                        if (this.files.length > 0) {
                            fileNameSpan.innerText = this.files[0].name;
                        } else {
                            fileNameSpan.innerText = "Chưa chọn tệp nào";
                        }
                    });
                }
            });
        </script>


        <%
            Integer editBookId = (Integer) session.getAttribute("editBookId");
            if (editBookId != null) {
            %>

            <script>
            document.addEventListener("DOMContentLoaded", function () {

                const modal = new bootstrap.Modal(document.getElementById("editBookModal"));

                document.getElementById("editbookid").value = "<%=editBookId%>";
                document.getElementById("editbook_name").value = "<%=session.getAttribute("editBookName")%>";
                document.getElementById("editauthor").value = "<%=session.getAttribute("editAuthor")%>";
                document.getElementById("edit_book_page").value = "<%=session.getAttribute("editBookPage")%>";
                document.getElementById("edit_publicyear").value = "<%=session.getAttribute("editPublicYear")%>";
                document.getElementById("edit_quantity").value = "<%=session.getAttribute("editQuantity")%>";
                document.getElementById("edit_selling_price").value = "<%=session.getAttribute("editSellingPrice")%>";

                document.querySelector("#editBookModal select[name='category_id']").value =
                        "<%=session.getAttribute("editCategoryId")%>";

                const image = "<%=session.getAttribute("editImage")%>";

                if(image && image !== "null"){
                    document.getElementById("previewImage").src =
                        "<%=request.getContextPath()%>/image?name=" + image;
                }

                modal.show();
            });
            </script>

            <%
                session.removeAttribute("editError");
                session.removeAttribute("editBookId");
                session.removeAttribute("editBookName");
                session.removeAttribute("editAuthor");
                session.removeAttribute("editCategoryId");
                session.removeAttribute("editBookPage");
                session.removeAttribute("editPublicYear");
                session.removeAttribute("editQuantity");
                session.removeAttribute("editSellingPrice");
                session.removeAttribute("editImage");
            }
            %>

        <!-- Lọc sách (tìm kiếm + chọn thể loại) giống createCart.jsp -->
        <script>
            // ---- Quản lý sách: tìm kiếm + lọc thể loại ----
            const bookSearchInput = document.getElementById('bookSearchInput');
            const bookFilterBtns = document.querySelectorAll('#bookFilterBar .filter-btn');

            function applyBookFilter() {
                if (!bookSearchInput) return;
                const term = bookSearchInput.value.trim().toLowerCase();
                const activeBtn = document.querySelector('#bookFilterBar .filter-btn.active');
                const activeCat = activeBtn ? activeBtn.dataset.cat : 'Tất cả';

                document.querySelectorAll('#bookTableBody tr').forEach(tr => {
                    const name = (tr.dataset.name || '').toLowerCase();
                    const author = (tr.dataset.author || '').toLowerCase();
                    const cat = tr.dataset.category || '';
                    const matchTerm = name.includes(term) || author.includes(term);
                    const matchCat = activeCat === 'Tất cả' || cat === activeCat;
                    tr.style.display = (matchTerm && matchCat) ? '' : 'none';
                });
            }

            if (bookSearchInput) {
                bookSearchInput.addEventListener('input', applyBookFilter);
                bookFilterBtns.forEach(btn => {
                    btn.addEventListener('click', () => {
                        bookFilterBtns.forEach(b => b.classList.remove('active'));
                        btn.classList.add('active');
                        applyBookFilter();
                    });
                });
            }

            // ---- Quản lý nhân viên: thanh tìm kiếm hoạt động ----
            const employeeSearchInput = document.getElementById('employeeSearchInput');

            function applyEmployeeFilter() {
                if (!employeeSearchInput) return;
                const term = employeeSearchInput.value.trim().toLowerCase();

                document.querySelectorAll('#employeeTableBody tr').forEach(tr => {
                    const username = (tr.dataset.username || '').toLowerCase();
                    const phone = (tr.dataset.phone || '').toLowerCase();
                    const email = (tr.dataset.email || '').toLowerCase();
                    const match = username.includes(term) || phone.includes(term) || email.includes(term);
                    tr.style.display = match ? '' : 'none';
                });
            }

            if (employeeSearchInput) {
                employeeSearchInput.addEventListener('input', applyEmployeeFilter);
            }

            // Load giá trị ca làm có trong ngày hôm đó

            function loadSchedulesForSelectedDate() {
                const selectedDate = document.getElementById('shiftDateSelect').value;
                const allCheckboxes = Array.from(document.querySelectorAll('label.shift-employee-checkbox input[type="checkbox"]'));

                // Reset tất cả checkbox về unchecked
                allCheckboxes.forEach(cb => cb.checked = false);

                // Lọc ra các ca làm thuộc về ngày đang chọn
                const dailySchedules = allSchedules.filter(s => s.workDate === selectedDate);

                // Thu thập tất cả ID nhân viên theo từng loại ca
                const morningIds = new Set();
                const afternoonIds = new Set();

                dailySchedules.forEach(s => {
                    if (s.shift === 'Sáng') morningIds.add(s.employeeId);
                    if (s.shift === 'Chiều') afternoonIds.add(s.employeeId);
                });

                // Xác định nhân viên làm "Cả ngày" (có mặt ở CẢ hai ca Sáng và Chiều)
                const allDayEmpIds = new Set();
                morningIds.forEach(id => {
                    if (afternoonIds.has(id)) {
                        allDayEmpIds.add(id);
                    }
                });

                // Check các checkbox tương ứng
                allCheckboxes.forEach(cb => {
                    const empId = parseInt(cb.value);
                    const shift = cb.dataset.shift;

                    if (shift === 'Cả ngày' && allDayEmpIds.has(empId)) {
                        cb.checked = true;
                    } else if (shift === 'Sáng' && morningIds.has(empId) && !allDayEmpIds.has(empId)) {
                        cb.checked = true;
                    } else if (shift === 'Chiều' && afternoonIds.has(empId) && !allDayEmpIds.has(empId)) {
                        cb.checked = true;
                    }
                });
            }

            // Lắng nghe sự thay đổi mỗi khi Admin chọn ngày khác
            const shiftDateSelect = document.getElementById('shiftDateSelect');
            if (shiftDateSelect) {
                shiftDateSelect.addEventListener('change', loadSchedulesForSelectedDate);
                // Kích hoạt ngay lần đầu load trang
                loadSchedulesForSelectedDate();
            }
        
            // Handle Save Shift button
            const saveShiftBtn = document.getElementById('saveShiftBtn');
            if (saveShiftBtn) {
                saveShiftBtn.addEventListener('click', function() {

                    const workDateSelect = document.getElementById('shiftDateSelect');
                    const allCheckboxes = Array.from(document.querySelectorAll('label.shift-employee-checkbox input[type="checkbox"]'));

                    // Verify elements exist
                    if (!workDateSelect) {
                        console.error('shiftDateSelect not found!');
                        alert('Lỗi: Không tìm thấy dropdown chọn ngày');
                        return;
                    }
                    if (allCheckboxes.length === 0) {
                        console.error('No shift-employee-checkbox elements found!');
                        alert('Lỗi: Không tìm thấy danh sách nhân viên');
                        return;
                    }

                    const employeeIds = [];
                    const shifts = [];

                    // Collect checked checkboxes grouped by shift
                    const shiftTypes = ['Sáng', 'Chiều', 'Cả ngày'];
                    shiftTypes.forEach(shift => {
                        const checkedForShift = allCheckboxes.filter(cb => cb.checked && cb.dataset.shift === shift);
                        checkedForShift.forEach(cb => {
                            employeeIds.push(cb.value);
                            shifts.push(shift);
                        });
                    });

                    if (employeeIds.length === 0) {
                        alert('Vui lòng chọn ít nhất một nhân viên cho ca làm!');
                        return;
                    }

                    // Send data to server
                    const formData = new FormData();

                    formData.append('action', 'saveShifts');
                    formData.append('workDate', workDateSelect.value);

                    employeeIds.forEach(id => formData.append('employeeId', id));
                    shifts.forEach(s => formData.append('shift', s));

                    fetch('<%=request.getContextPath()%>/saveSchedule', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => {
                        console.log('Response status:', response.status);
                        console.log('Response headers:', [...response.headers.entries()]);
                        return response.json();
                    })
                    .then(data => {
                        console.log('Response data:', data);
                        if (data.success) {
                            alert(data.message);
                            location.reload();
                        } else {
                            alert('Lỗi: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Có lỗi xảy ra khi lưu lịch làm việc! Xem console để biết chi tiết.');
                    });
                });
            }

            // Bắt sự kiện nút xóa ca làm
            const deleteShiftBtn = document.getElementById('deleteShiftBtn');
            if (deleteShiftBtn) {
                deleteShiftBtn.addEventListener('click', function() {
                    const selectedDate = document.getElementById('shiftDateSelect').value;
                    
                    if (!selectedDate) {
                        alert("Vui lòng chọn ngày để xóa ca làm.");
                        return;
                    }

                    // Hiển thị hộp thoại xác nhận trước khi xóa
                    if (confirm('Bạn có chắc chắn muốn xóa toàn bộ ca làm của ngày ${selectedDate} không?')) {
                        const url = '<%=request.getContextPath()%>/saveSchedule?action=delete&workDate=' + selectedDate;
                        // Gọi API tới SaveScheduleServlet với tham số action=delete
                        fetch(url, {
                            method: 'POST'
                        })
                        .then(async response => {
                            // Đọc dạng text trước để nếu server văng lỗi HTML thì ta vẫn tóm được
                            const text = await response.text(); 
                            try {
                                return JSON.parse(text); // Ép kiểu về JSON
                            } catch (e) {
                                console.error("Lỗi trả về từ server (Không phải JSON):", text);
                                throw new Error("Dữ liệu server trả về không đúng định dạng JSON.");
                            }
                        })
                        .then(data => {
                            if (data.success) {
                                alert(data.message);
                                location.reload(); // Reload lại trang để làm mới giao diện
                            } else {
                                alert("Lỗi: " + data.message);
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            alert("Đã xảy ra lỗi khi kết nối với máy chủ.");
                        });
                    }
                });
            }
        </script>

        <!-- Sửa dữ liệu sách !-->

        

        <!-- Script for Category Modal -->
        <script>
            // Category Modal: Add & Delete Category
            document.addEventListener('DOMContentLoaded', function() {
                const urlParams = new URLSearchParams(window.location.search);

                // Code cũ của bạn giữ nguyên
                if (urlParams.get('openCategoryModal') === 'true') {

                    // Mở Modal Quản lý thể loại
                    const categoryModalEl = document.getElementById('categoryModal');
                    if (categoryModalEl) {
                        // Sử dụng setTimeout nhẹ để đảm bảo Bootstrap đã load xong DOM hoàn toàn
                        setTimeout(() => {
                            const categoryModal = new bootstrap.Modal(categoryModalEl);
                            categoryModal.show();
                        }, 100);
                    }

                    // 2. Xóa riêng tham số 'openCategoryModal' khỏi URL nhưng GIỮ LẠI các tham số khác
                    urlParams.delete('openCategoryModal');
                    
                    // Tạo lại URL mới gọn sạch
                    const newSearch = urlParams.toString() ? '?' + urlParams.toString() : '';
                    const newUrl = window.location.pathname + newSearch + window.location.hash;
                    
                    // Cập nhật lại thanh địa chỉ trình duyệt mà không làm reload
                    window.history.replaceState({}, document.title, newUrl);
                }
                const newCategoryInput = document.getElementById('newCategoryInput');
                const btnAddCategory = document.getElementById('btnAddCategory');
                const categoryTableBody = document.getElementById('categoryTableBody');
                const categoryModal = document.getElementById('categoryModal');

                if (btnAddCategory && newCategoryInput) {
                    btnAddCategory.addEventListener('click', function() {
                        const categoryName = newCategoryInput.value.trim();
                        if (!categoryName) {
                            alert('Vui lòng nhập tên thể loại!');
                            return;
                        }

                        const formData = new FormData();
                        formData.append('action', 'addCategory');
                        formData.append('categoryName', categoryName);
                        console.log([...formData.entries()]);
                        
                        fetch('<%=request.getContextPath()%>/categories', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.json())
                        .then(data => {
                            console.log(data);
                            if (data.success) {
                                alert(data.message);
                                newCategoryInput.value = '';
                                // Thêm dòng mới vào bảng
                                const newRow = document.createElement('tr');

                                newRow.dataset.id = data.category.id;
                                newRow.dataset.name = data.category.categoryName;
                                newRow.dataset.total = data.category.totalbook;

                                categoryTableBody.appendChild(newRow);
                                // Cập nhật dropdown filter thể loại ở trang quản lý sách
                                updateCategoryFilter(data.category);
                                const currentUrl = new URL(window.location.href);
                                currentUrl.searchParams.set('openCategoryModal', 'true');
                                window.location.href = currentUrl.toString();
                            } else {
                                alert('Lỗi: ' + data.message);
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            alert('Có lỗi xảy ra khi thêm thể loại!');
                        });
                    });

                    // Enter để thêm
                    newCategoryInput.addEventListener('keypress', function(e) {
                        if (e.key === 'Enter') {
                            btnAddCategory.click();
                        }
                    });
                }

                // Delete category (event delegation)
                if (categoryTableBody) {
                    categoryTableBody.addEventListener('click', function(e) {
                        const deleteBtn = e.target.closest('.btn-delete-category');
                        if (!deleteBtn) return;

                        const categoryId = deleteBtn.dataset.id;
                        const categoryName = deleteBtn.dataset.name;
                        const confirmMessage = 'Bạn có chắc chắn muốn xóa thể loại "' + categoryName + '"?';

                        if (confirm(confirmMessage)) {
                            const formData = new FormData();
                            formData.append('action', 'deleteCategory');
                            formData.append('id', categoryId);

                            fetch('<%=request.getContextPath()%>/categories', {
                                method: 'POST',
                                body: formData
                            })
                            .then(async response => {
                            // Đọc dữ liệu dạng text trước để tránh crash nếu Server trả về HTML/Lỗi
                                const textData = await response.text(); 
                                
                                if (!response.ok) {
                                    throw new Error(`Server trả về lỗi HTTP ${response.status}: ${textData}`);
                                }

                                try {
                                    return JSON.parse(textData); // Ép kiểu sang JSON thủ công
                                } catch (e) {
                                    console.error("Dữ liệu Server trả về không phải JSON chuẩn:", textData);
                                    throw new Error("Phản hồi từ Server không đúng định dạng JSON!");
                                }
                            })
                            .then(data => {
                                if (data.success) {
                                    alert(data.message || 'Xóa thể loại thành công!');

                                    // Xóa dòng khỏi bảng
                                    const row = document.querySelector(`#categoryTableBody tr[data-id="${categoryId}"]`);
                                    if (row) {
                                        row.remove();
                                    }

                                    // Xóa nút filter tương ứng
                                    removeCategoryFilter(categoryId);
                                    const currentUrl = new URL(window.location.href);
                                    currentUrl.searchParams.set('openCategoryModal', 'true');
                                    window.location.href = currentUrl.toString();
                                } else {
                                    alert('Lỗi: ' + (data.message || 'Không thể cập nhật'));
                                }
                            })
                            .catch(error => {
                                console.error('Chi tiết lỗi:', error);
                                alert('Có lỗi xảy ra: ' + error.message);
                            });
                        }
                    });
                }

                // Cập nhật dropdown filter thể loại khi thêm mới
                function updateCategoryFilter(category) {
                    const filterBar = document.getElementById('bookFilterBar');
                    if (!filterBar) return;

                    const newBtn = document.createElement('button');
                    newBtn.className = 'filter-btn';
                    newBtn.dataset.cat = category.categoryName;
                    newBtn.textContent = category.categoryName;
                    newBtn.addEventListener('click', function() {
                        document.querySelectorAll('#bookFilterBar .filter-btn').forEach(b => b.classList.remove('active'));
                        newBtn.classList.add('active');
                        applyBookFilter();
                    });
                    filterBar.appendChild(newBtn);
                }

                // Xóa nút filter khi xóa thể loại
                function removeCategoryFilter(categoryId) {
                    const filterBar = document.getElementById('bookFilterBar');
                    if (!filterBar) return;

                    const btns = filterBar.querySelectorAll('.filter-btn');
                    btns.forEach(btn => {
                        // Tìm body row với data-id tương ứng để lấy tên
                        const row = document.querySelector(`#categoryTableBody tr[data-id="${categoryId}"]`);
                        if (row && btn.dataset.cat === row.dataset.name) {
                            btn.remove();
                        }
                    });
                }

                // Xử lý khi đóng modal category - reload để cập nhật dropdown category trong form sách
                if (categoryModal) {
                    categoryModal.addEventListener('hidden.bs.modal', function() {
                        window.location.reload();
                    });
                }
            });


            let editCategoryModalInstance = null;

            document.addEventListener('DOMContentLoaded', function() {
                const urlParams = new URLSearchParams(window.location.search);
                if (urlParams.get('openCategoryModal') === 'true') {
        
                // Mở Modal Quản lý thể loại
                    const categoryModalEl = document.getElementById('categoryModal');
                    if (categoryModalEl) {
                        // Sử dụng setTimeout nhẹ để đảm bảo Bootstrap đã load xong DOM hoàn toàn
                        setTimeout(() => {
                            const categoryModal = new bootstrap.Modal(categoryModalEl);
                            categoryModal.show();
                        }, 100);
                    }

                    // 2. Xóa riêng tham số 'openCategoryModal' khỏi URL nhưng GIỮ LẠI các tham số khác (như table=books)
                    urlParams.delete('openCategoryModal');
                    
                    // Tạo lại URL mới gọn sạch không có openCategoryModal
                    const newSearch = urlParams.toString() ? '?' + urlParams.toString() : '';
                    const newUrl = window.location.pathname + newSearch + window.location.hash;
                    
                    // Cập nhật lại thanh địa chỉ trình duyệt mà không làm reload
                    window.history.replaceState({}, document.title, newUrl);
                }


                const editCategoryModalEl = document.getElementById('editCategoryModal');
                if (editCategoryModalEl) {
                    editCategoryModalInstance = new bootstrap.Modal(editCategoryModalEl, {
                        backdrop: false // Tắt tạo backdrop riêng để tránh làm tối đen toàn bộ màn hình
                    });
                }

                const btnSaveCategoryEdit = document.getElementById('btnSaveCategoryEdit');

                // Xử lý Lưu thay đổi thể loại
                if (btnSaveCategoryEdit) {
                    btnSaveCategoryEdit.addEventListener('click', function(e) {
                        e.preventDefault();
                        
                        const id = document.getElementById('editCategoryId').value;
                        const newName = document.getElementById('editCategoryNameInput').value.trim();

                        if (!newName) {
                            alert('Tên thể loại không được để trống!');
                            return;
                        }

                        const formData = new FormData();
                        formData.append('action', 'editCategory');
                        formData.append('id', id);
                        formData.append('categoryName', newName);

                        fetch('<%=request.getContextPath()%>/categories', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.text()) // Đọc dữ liệu dạng chữ trước
                        .then(text => {
                            let data;
                            try {
                                data = JSON.parse(text); // Ép kiểu sang JSON
                            } catch (err) {
                                console.error("Dữ liệu nhận được từ Server không chuẩn JSON:", text);
                                // Nếu DB đã update thành công nhưng JSON bị lỗi cú pháp, vẫn coi như thành công trên UI
                                data = { success: true, message: 'Đã cập nhật thể loại!' };
                            }

                            if (data.success) {
                                alert(data.message || 'Cập nhật thể loại thành công!');

                                // 1. Cập nhật tên thể loại mới lên giao diện (Table)
                                const row = document.querySelector(`#categoryTableBody tr[data-id="${id}"]`);
                                if (row) {
                                    row.dataset.name = newName;
                                    row.querySelector('td:first-child').textContent = newName;

                                    // Cập nhật lại thuộc tính của nút sửa
                                    const btnEdit = row.querySelector('.btn-edit-category');
                                    if (btnEdit) {
                                        btnEdit.setAttribute('onclick', `openEditCategoryModal(event, '${id}', '${newName}')`);
                                    }
                                }

                                // 2. ẨN TỰ ĐỘNG MODAL SỬA
                                closeEditCategoryModal();
                                reloadAndOpenCategoryModal();
                            } else {
                                alert('Thất bại: ' + (data.message || 'Không thể cập nhật thể loại!'));
                            }
                        })
                        .catch(error => {
                            console.error('Lỗi Fetch:', error);
                            alert('Có lỗi xảy ra khi kết nối tới máy chủ!');
                        });
                    });
                }
            });

            // Hàm mở Modal Sửa (Hiển thị đè lên Modal Quản lý)
            function openEditCategoryModal(event, id, currentName) {
                if (event) {
                    event.stopPropagation(); // Chống lan truyền sự kiện làm đóng modal cha
                    event.preventDefault();
                }

                document.getElementById('editCategoryId').value = id;
                document.getElementById('editCategoryNameInput').value = currentName;

                if (!editCategoryModalInstance) {
                    const editCategoryModalEl = document.getElementById('editCategoryModal');
                    editCategoryModalInstance = new bootstrap.Modal(editCategoryModalEl, { backdrop: false });
                }
                
                // Mở modal sửa lên trên
                editCategoryModalInstance.show();
            }
            
            function reloadAndOpenCategoryModal() {
                const currentUrl = new URL(window.location.href);
                console.log(currentUrl);
                currentUrl.searchParams.set('openCategoryModal', 'true');
                window.location.href = currentUrl.toString();
            }

            // Hàm đóng Modal Sửa / Hủy -> Tải lại trang và giữ nguyên Modal Quản lý thể loại
            function closeEditCategoryModal() {
                reloadAndOpenCategoryModal();
            }
            
            function viewPdfModal(pdfUrl) {
                // 1. Gán URL của PDF vào iframe
                const pdfFrame = document.getElementById('pdfFrame');
                if (pdfFrame) {
                    pdfFrame.src = pdfUrl;
                }

                // 2. Hiển thị Bootstrap Modal
                const pdfModalEl = document.getElementById('pdfViewerModal');
                if (pdfModalEl) {
                    const pdfModal = new bootstrap.Modal(pdfModalEl);
                    pdfModal.show();
                }
            }

            // Xóa src của iframe khi đóng Modal để tiết kiệm bộ nhớ & tránh lưu lại file cũ
            document.getElementById('pdfViewerModal')?.addEventListener('hidden.bs.modal', function () {
                document.getElementById('pdfFrame').src = '';
            });
        </script>

    </body>
</html>
