<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ page import="java.util.List" %>
<%@ page import="structure.books" %>
<%@ page import="structure.login" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tạo hóa đơn bán hàng - POS</title>
    <link rel="icon" href="<%=request.getContextPath()%>/favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<%=request.getContextPath()%>/css/employee.css">

    <style>
        :root {
            /* Unified brand palette */
            --primary-color: #f5f1e7;        /* page background */
            --secondary-color: #2b1c15;      /* sidebar */
            --third-color: #dcb37b;          /* gold accent */
            --bg-main: #f4efe4;
            --bg-sidebar: #2b1c15;
            --bg-sidebar-hover: #3d2a1f;
            --text-light: #fff;
            --text-dark: #2e2820;
            --text-main: #4a4136;
            --text-muted: #8c8375;
            --border-color: #e9e0d0;
            --border-soft: #f0e8da;
            --card-bg: #fffdf9;
            --accent-gold: #dcb37b;
            --accent-gold-dark: #c79a5e;
            --accent-brown: #7a5c43;
            --accent-brown-dark: #5d4431;
            --btn-green: #7a5c43;
            --danger: #d9534f;

            /* Gradients */
            --grad-gold: linear-gradient(135deg, #e7c692 0%, #dcb37b 45%, #c79a5e 100%);
            --grad-brown: linear-gradient(135deg, #8a6a4d 0%, #6b4f3a 100%);
            --grad-sidebar: linear-gradient(185deg, #38251b 0%, #2b1c15 55%, #201009 100%);
            --grad-surface: linear-gradient(180deg, #fffefb 0%, #fdf9f1 100%);

            --font-sans: 'Be Vietnam Pro', 'Segoe UI', Tahoma, sans-serif;
            --font-num: 'Inter', 'Be Vietnam Pro', sans-serif;
            --radius: 12px;
            --shadow-sm: 0 2px 6px rgba(43,28,21,0.06);
            --shadow-md: 0 8px 22px rgba(43,28,21,0.10);
            --shadow-gold: 0 6px 18px rgba(220,179,123,0.4);
            --ring-gold: 0 0 0 3px rgba(220,179,123,0.28);
            --transition: 0.25s cubic-bezier(0.4,0,0.2,1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: var(--font-sans);
        }

        /* Numbers → Inter */
        .product-price, .total-price, .qty-input, .stock,
        .cart-item-info p, .cart-input {
            font-family: var(--font-num);
            font-variant-numeric: tabular-nums;
        }

        body {
            background-color: var(--bg-main);
            background-image:
                radial-gradient(900px 480px at 100% -8%, rgba(220,179,123,0.14), transparent 60%),
                radial-gradient(760px 420px at -6% 108%, rgba(122,92,67,0.09), transparent 55%);
            background-attachment: fixed;
            display: flex;
            height: 100vh;
            overflow: hidden;
            color: var(--text-dark);
            -webkit-font-smoothing: antialiased;
        }

        /* --- MAIN CONTENT --- */
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .top-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 24px;
            background-color: var(--bg-main);
            border-bottom: 1px solid var(--border-color);
        }

        .top-header h2 {
            font-size: 19px;
            font-weight: 800;
            letter-spacing: -0.015em;
            position: relative;
            padding-left: 13px;
        }

        .top-header h2::before {
            content: "";
            position: absolute;
            left: 0; top: 2px; bottom: 2px;
            width: 5px;
            border-radius: 4px;
            background: var(--grad-gold);
        }

        .header-user {
            display: flex;
            align-items: center;
            gap: 10px;
            background: linear-gradient(135deg, #efe6d5, #e7dcc7);
            padding: 5px 16px 5px 5px;
            border-radius: 26px;
            font-size: 13px;
            color: var(--text-main);
            border: 1px solid var(--border-color);
            box-shadow: var(--shadow-sm);
        }

        .search-filter-section {
            padding: 16px 24px 0;
        }

        .search-bar {
            width: 100%;
            padding: 11px 15px 11px 42px;
            border: 1px solid var(--border-color);
            border-radius: var(--radius);
            background: #fff url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="16" height="16" fill="%23a99f8d"><path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"/></svg>') no-repeat 15px center;
            outline: none;
            font-size: 14px;
            transition: border-color var(--transition), box-shadow var(--transition);
        }

        .search-bar:focus {
            border-color: var(--accent-gold);
            box-shadow: 0 0 0 3px rgba(220,179,123,0.22);
        }

        .filters {
            display: flex;
            gap: 8px;
            margin-top: 14px;
            overflow-x: auto;
            padding-bottom: 4px;
        }

        .filter-btn {
            padding: 7px 16px;
            border: 1px solid var(--border-color);
            background: #fff;
            color: var(--text-main);
            border-radius: 20px;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            white-space: nowrap;
            transition: all var(--transition);
        }

        .filter-btn:hover {
            border-color: var(--accent-gold);
            color: var(--accent-brown-dark);
        }

        .filter-btn.active {
            background-color: var(--accent-brown);
            color: #fff;
            border-color: var(--accent-brown);
            box-shadow: 0 2px 8px rgba(122,92,67,0.28);
        }

        /* --- PRODUCT GRID --- */
        .product-grid {
            padding: 20px 24px;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 18px;
            overflow-y: auto;
            height: calc(100vh - 150px);
            align-content: start;
        }

        .product-card {
            background: var(--grad-surface);
            border: 1px solid var(--border-color);
            border-radius: 14px;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            display: flex;
            flex-direction: column;
            min-height: 320px;
            transition: box-shadow var(--transition), transform var(--transition), border-color var(--transition);
        }

        .product-card:hover {
            box-shadow: var(--shadow-md);
            transform: translateY(-4px);
            border-color: var(--accent-gold);
        }

        .product-img-wrapper {
            position: relative;
            height: 150px;
            background: #ece4d5;
        }

        .product-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .category-tag {
            position: absolute;
            top: 10px;
            left: 10px;
            background: rgba(43,28,21,0.72);
            color: #fff;
            font-size: 10px;
            padding: 3px 9px;
            border-radius: 20px;
            text-transform: uppercase;
            letter-spacing: 0.03em;
            backdrop-filter: blur(2px);
        }

        .product-info {
            padding: 12px;
            display: flex;
            flex-direction: column;
            flex: 1;
        }

        .product-title {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 4px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            color: var(--text-dark);
        }

        .product-author {
            font-size: 11px;
            color: var(--text-muted);
            margin-bottom: 8px;
        }

        .product-price {
            font-size: 15px;
            font-weight: 700;
            color: var(--accent-brown);
            margin-bottom: auto;
        }

        .product-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 10px;
            border-top: 1px solid #f0e8da;
            padding-top: 10px;
        }

        .stock {
            font-size: 11px;
            color: var(--text-muted);
        }

        .stock.out {
            color: var(--danger);
            font-weight: 600;
        }

        .qty-controls {
            display: flex;
            align-items: center;
            border: 1px solid #e0d9cc;
            border-radius: 6px;
            overflow: hidden;
        }

        .qty-btn {
            background: #f9f6f0;
            border: none;
            width: 26px;
            height: 26px;
            cursor: pointer;
            font-size: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-main);
            transition: background var(--transition);
        }

        .qty-btn:hover { background: #efe8db; }

        .qty-input {
            width: 32px;
            height: 26px;
            border: none;
            border-left: 1px solid #e0d9cc;
            border-right: 1px solid #e0d9cc;
            text-align: center;
            font-size: 13px;
            outline: none;
        }

        .qty-input::-webkit-outer-spin-button,
        .qty-input::-webkit-inner-spin-button {
            -webkit-appearance: none; margin: 0;
        }

        /* --- CART SECTION RIGHT --- */
        .cart-section {
            width: 340px;
            background: var(--bg-main);
            border-left: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
        }

        .cart-header {
            padding: 17px 20px;
            font-size: 16px;
            font-weight: 800;
            letter-spacing: -0.01em;
            border-bottom: 1px solid var(--border-color);
            background: var(--grad-surface);
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--text-dark);
        }

        .cart-header i {
            color: #3a2a17;
            background: var(--grad-gold);
            width: 30px; height: 30px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 9px;
            font-size: 14px;
            box-shadow: 0 4px 12px rgba(220,179,123,0.35);
        }

        .cart-body {
            flex: 1;
            background: #fff;
            overflow-y: auto;
            padding: 18px;
        }

        .empty-cart {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: #b3a994;
            text-align: center;
            font-size: 14px;
        }

        .empty-cart i {
            font-size: 40px;
            margin-bottom: 10px;
            color: #ddd3c0;
        }

        .cart-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 14px;
            padding-bottom: 14px;
            border-bottom: 1px dashed #ece4d5;
        }

        .cart-item-info h4 { font-size: 13px; margin-bottom: 4px; color: var(--text-dark); }
        .cart-item-info p { font-size: 13px; color: var(--accent-brown); font-weight: 600; }

        .cart-footer {
            padding: 18px;
            background: var(--bg-main);
            border-top: 1px solid var(--border-color);
        }

        .customer-fields {
            margin-bottom: 12px;
        }

        .cart-input {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 13px;
            outline: none;
            box-sizing: border-box;
            background: #fff;
        }

        .cart-input:focus {
            border-color: var(--accent-gold);
            box-shadow: 0 0 0 3px rgba(220,179,123,0.22);
        }

        .total-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 14px;
        }

        .total-row span { font-size: 14px; font-weight: 600; color: var(--text-main); }
        .total-price { font-size: 19px !important; font-weight: 700 !important; color: var(--accent-brown); }

        .payment-methods {
            display: flex;
            gap: 10px;
            margin-bottom: 16px;
        }

        .pay-btn {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd4c2;
            background: #fff;
            border-radius: 8px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            color: var(--text-main);
            transition: all var(--transition);
        }

        .pay-btn:hover { border-color: var(--accent-gold); }

        .pay-btn.active.cash {
            background: var(--btn-green);
            color: #fff;
            border-color: var(--btn-green);
        }

        .checkout-btn {
            width: 100%;
            padding: 15px;
            background: #e0d9cc; /* Disabled state */
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: not-allowed;
            transition: var(--transition);
            font-family: var(--font-sans);
        }

        .checkout-btn.active {
            background: linear-gradient(135deg, var(--accent-gold), var(--accent-gold-dark));
            cursor: pointer;
            color: #3a2a17;
            box-shadow: 0 4px 14px rgba(220,179,123,0.4);
        }

        .checkout-btn.active:hover {
            background: linear-gradient(135deg, var(--accent-gold-dark), #b98a4e);
            transform: translateY(-1px);
        }

        /* Scrollbar styling */
        ::-webkit-scrollbar { width: 7px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #cfc4b2; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--accent-brown); }

        /* --- INVOICE MODAL --- */
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(43,28,21,0.55);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 2000;
            backdrop-filter: blur(2px);
        }

        .modal-box {
            background: #fff;
            border-radius: 14px;
            width: 90%;
            max-width: 820px;
            max-height: 92vh;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            box-shadow: 0 24px 70px rgba(0,0,0,0.35);
        }

        .modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 22px;
            border-bottom: 1px solid var(--border-color);
        }

        .modal-header h3 {
            font-size: 16px;
            font-weight: 700;
            margin: 0;
            color: var(--text-dark);
        }

        .modal-close {
            background: transparent;
            border: none;
            font-size: 24px;
            line-height: 1;
            cursor: pointer;
            color: #9a8f7e;
            transition: color var(--transition);
        }

        .modal-close:hover { color: var(--text-dark); }

        .modal-body {
            flex: 1;
            overflow: hidden;
            background: #525659;
            padding: 10px;
        }

        .modal-body iframe {
            width: 100%;
            height: 70vh;
            border: none;
            background: #fff;
        }

        .modal-footer {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            padding: 16px 22px;
            border-top: 1px solid var(--border-color);
        }

        .btn-print {
            background: var(--btn-green);
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 10px 18px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: background var(--transition);
        }

        .btn-print:hover { background: var(--accent-brown-dark); }

        .btn-close-modal {
            background: #efe8db;
            color: var(--text-main);
            border: none;
            border-radius: 8px;
            padding: 10px 18px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: background var(--transition);
        }

        .btn-close-modal:hover { background: #e3d9c7; }
    </style>
</head>
<body>
    <%  
        structure.login user = (structure.login) session.getAttribute("user");
        if (user == null) {
            session.setAttribute("error", "Vui lòng đăng nhập");
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }
    %>
        <!--Kiểm tra đăng nhập -->
    <%
        String displayName = (user.getUsername() != null && user.getUsername() != null && !user.getUsername().isBlank())
                ? user.getUsername() : "Nhân viên";
    %>

    <%
        String success = (String) session.getAttribute("success");
        String error = (String) session.getAttribute("error");
        if (success != null) {
    %>
        <script>
            alert("<%= success %>");
        </script>
    <%
            session.removeAttribute("success");
        }
        if (error != null) {
    %>
        <script>
            alert("<%= error %>");
        </script>
    <%
            session.removeAttribute("error");
        }
    %>

    <aside class="sidebar">
        <div>
            <div class="brand">
                <div class="brand-icon"><i class="fa-solid fa-book-open"></i></div>
                <div class="brand-text">
                    <h1>Nhà Sách Minh Châu</h1>
                    <p>Hệ thống quản lý</p>
                </div>
            </div>
            <ul class="nav-menu">
                <li><a class="nav-item active" href="<%=request.getContextPath()%>/createCart"><i class="fa-solid fa-file-invoice"></i> Tạo hóa đơn</a></li>
                <li><a class="nav-item" href="<%=request.getContextPath()%>/history"><i class="fa-solid fa-clock-rotate-left"></i> Lịch sử bán hàng</a></li>
                <li><a class="nav-item" href="<%=request.getContextPath()%>/viewSchedule"><i class="fa-solid fa-calendar-days"></i> Xem Lịch Làm Việc</a></li>
            </ul>
        </div>

        <div class="user-info-bottom">
            <div class="header-user">
                <div class="avatar" style="width: 24px; height: 24px; font-size: 12px;"><%= displayName.substring(0, 1).toUpperCase() %></div>
                <span><%= displayName %> <br><small style="color:#777; font-size: 10px;">Ca làm việc: <%= request.getAttribute("shiftLabel") != null ? request.getAttribute("shiftLabel") : "" %></small></span>
            </div>
            <button class="logout-btn" onclick="window.location.href='<%=request.getContextPath()%>/index.jsp'">
                <i class="fa-solid fa-right-from-bracket"></i> Đăng xuất
            </button>
        </div>
    </aside>

    <main class="main-content">
        <header class="top-header">
            <h2>Tạo hóa đơn bán hàng</h2>
        </header>

        <div class="search-filter-section">
            <input type="text" class="search-bar" id="searchInput" placeholder="Tìm kiếm sách, tác giả...">
            <div class="filters" id="filterBar">
                <button class="filter-btn active" data-cat="Tất cả">Tất cả</button>

                <c:forEach var="c" items="${categoryList}">
                    <button class="filter-btn" data-cat="${c.categoryName}">
                        ${c.categoryName}
                    </button>
                </c:forEach>
            </div>
        </div>

        <div class="product-grid" id="productGrid">
            <%
                List<books> bookList = (List<books>) request.getAttribute("books");
                if (bookList != null && !bookList.isEmpty()) {
                    for (books b : bookList) {
                        String img = b.getImageUrl() != null ? b.getImageUrl() : "";
                        String name = b.getBookName() != null ? b.getBookName() : "";
                        String author = b.getAuthor() != null ? b.getAuthor() : "";
                        String cat = b.getCategory() != null ? b.getCategory() : "";
                        double price = b.getSellingPrice();
                        int stock = b.getQuantity();
                        int bid = b.getBook_id();
                        boolean outOfStock = stock <= 0;
            %>
            <div class="product-card" data-id="<%=bid%>" data-name="<%=name%>" data-author="<%=author%>" data-category="<%=cat%>" data-price="<%=String.format("%.0f", price)%>" data-stock="<%=stock%>">
                <div class="product-img-wrapper">
                    <span class="category-tag"><%=cat%></span>
                    <img src="<%=request.getContextPath()%>/image?name=<%=img%>" alt="<%=name%>" class="product-img" onerror="this.src='https://via.placeholder.com/200x140'">
                </div>
                <div class="product-info">
                    <div class="product-title" title="<%=name%>"><%=name%></div>
                    <div class="product-author"><%=author%></div>
                    <div class="product-price"><%=String.format("%,.0f", price)%> đ</div>
                    <div class="product-footer">
                        <span class="stock <%= outOfStock ? "out" : "" %>"><%= outOfStock ? "Hết hàng" : "Kho: " + stock %></span>
                        <div class="qty-controls">
                            <button type="button" class="qty-btn" onclick="updateQty(<%=bid%>, -1)" <%= outOfStock ? "disabled" : "" %>>-</button>
                            <input type="number" class="qty-input" id="qty-input-<%=bid%>" value="0" readonly>
                            <button type="button" class="qty-btn" onclick="updateQty(<%=bid%>, 1)" <%= outOfStock ? "disabled" : "" %>>+</button>
                        </div>
                    </div>
                </div>
            </div>
            <%
                    }
                } else {
            %>
            <div class="text-muted" style="grid-column: 1 / -1; color: #999;">Không có sách nào trong kho.</div>
            <%
                }
            %>
        </div>
    </main>

    <aside class="cart-section">
        <div class="cart-header">
            <i class="fa-solid fa-cart-shopping"></i> Giỏ hàng
        </div>

        <div class="cart-body" id="cartBody">
            <div class="empty-cart">
                <i class="fa-solid fa-cart-plus"></i>
                <p>Chưa có sách nào trong giỏ</p>
            </div>
        </div>

        <div class="cart-footer">
            <div class="customer-fields">
                <input type="text" id="customerName" class="cart-input" placeholder="Tên khách hàng">
                <input type="text" id="customerPhone" class="cart-input" placeholder="Số điện thoại" style="margin-top: 8px;">
            </div>
            <div class="total-row">
                <span>Tổng cộng</span>
                <span class="total-price" id="totalPrice">0đ</span>
            </div>
            <div style="font-size: 11px; color: #777; margin-bottom: 5px; text-transform: uppercase;">Phương thức thanh toán</div>
            <div class="payment-methods">
                <button type="button" class="pay-btn active cash" data-method="cash"><i class="fa-solid fa-money-bill"></i> Tiền mặt</button>
                <button type="button" class="pay-btn" data-method="transfer"><i class="fa-solid fa-building-columns"></i> Chuyển khoản</button>
            </div>
            <button type="button" class="checkout-btn" id="checkoutBtn"><i class="fa-solid fa-file-invoice-dollar"></i> Thanh toán</button>
        </div>
    </aside>

    <!-- Modal xem trước hóa đơn -->
    <div class="modal-overlay" id="invoiceModal">
        <div class="modal-box">
            <div class="modal-header">
                <h3><i class="fa-solid fa-file-invoice"></i> Hóa đơn bán hàng</h3>
                <button type="button" class="modal-close" id="modalClose">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            <div class="modal-body">
                <iframe id="pdfFrame" src="" title="Hóa đơn PDF"></iframe>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-print" id="printInvoiceBtn"><i class="fa-solid fa-print"></i> In hóa đơn</button>
                <button type="button" class="btn-close-modal" id="closeModalBtn">Đóng</button>
            </div>
        </div>
    </div>

    <script>
        const ctx = '<%=request.getContextPath()%>';
        const cart = {}; // bookId -> quantity
        let selectedPayment = 'Tiền mặt';

        const formatMoney = (amount) => {
            return Math.round(amount).toLocaleString('vi-VN') + 'đ';
        };

        const getProductCard = (id) => document.querySelector('.product-card[data-id="' + id + '"]');

        function updateQty(id, change) {
            const card = getProductCard(id);
            if (!card) return;
            const stock = parseInt(card.dataset.stock, 10);
            let qty = cart[id] || 0;
            qty += change;
            if (qty < 0) qty = 0;
            if (qty > stock) {
                alert('Vượt quá số lượng tồn kho (' + stock + ')!');
                return;
            }
            if (qty === 0) delete cart[id];
            else cart[id] = qty;

            const input = document.getElementById('qty-input-' + id);
            if (input) input.value = qty;
            renderCart();
        }

        function renderCart() {
            const cartBody = document.getElementById('cartBody');
            const totalPriceEl = document.getElementById('totalPrice');
            const checkoutBtn = document.getElementById('checkoutBtn');
            const keys = Object.keys(cart);

            if (keys.length === 0) {
                cartBody.innerHTML = `
                    <div class="empty-cart">
                        <i class="fa-solid fa-cart-plus"></i>
                        <p>Chưa có sách nào trong giỏ</p>
                    </div>`;
                checkoutBtn.classList.remove('active');
                totalPriceEl.textContent = '0đ';
                return;
            }

            cartBody.innerHTML = '';
            let total = 0;

            keys.forEach(id => {
                const card = getProductCard(id);
                const name = card.dataset.name;
                const price = parseFloat(card.dataset.price);
                const qty = cart[id];
                const lineTotal = price * qty;
                total += lineTotal;

                const item = document.createElement('div');
                item.className = 'cart-item';
                item.innerHTML = 
                '<div class="cart-item-info">' +
                    '<h4>' + name + '</h4>' +
                    '<div style="display:flex; align-items:center; gap:10px; margin-top:5px;">' +
                        '<div class="qty-controls" style="transform: scale(0.8); transform-origin: left;">' +
                            '<button type="button" class="qty-btn" onclick="updateQty(' + id + ', -1)">-</button>' +
                            '<input type="number" class="qty-input" value="' + qty + '" readonly>' +
                            '<button type="button" class="qty-btn" onclick="updateQty(' + id + ', 1)">+</button>' +
                        '</div>' +
                        '<span style="font-size:12px; color:#777;">x ' + formatMoney(price) + '</span>' +
                    '</div>' +
                '</div>' +
                '<div class="cart-item-info" style="text-align: right;">' +
                    '<p>' + formatMoney(lineTotal) + '</p>' +
                '</div>';
                cartBody.appendChild(item);
            });

            checkoutBtn.classList.add('active');
            totalPriceEl.textContent = formatMoney(total);
        }

        // Phương thức thanh toán
        const payBtns = document.querySelectorAll('.pay-btn');
        payBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                payBtns.forEach(b => {
                    b.classList.remove('active', 'cash');
                    b.style.borderColor = '';
                    b.style.color = '';
                });
                btn.classList.add('active');
                if (btn.dataset.method === 'cash') {
                    btn.classList.add('cash');
                } else {
                    btn.style.borderColor = '#dcb37b';
                    btn.style.color = '#dcb37b';
                }
                selectedPayment = btn.dataset.method === 'cash' ? 'Tiền mặt' : 'Chuyển khoản';
            });
        });

        // Tìm kiếm & lọc
        const searchInput = document.getElementById('searchInput');
        const filterBtns = document.querySelectorAll('.filter-btn');

        function applyFilter() {
            const term = searchInput.value.trim().toLowerCase();
            const activeBtn = document.querySelector('.filter-btn.active');
            const activeCat = activeBtn ? activeBtn.dataset.cat : 'Tất cả';
            document.querySelectorAll('.product-card').forEach(card => {
                const name = (card.dataset.name || '').toLowerCase();
                const author = (card.dataset.author || '').toLowerCase();
                const cat = card.dataset.category || '';
                const matchTerm = name.includes(term) || author.includes(term);
                const matchCat = activeCat === 'Tất cả' || cat === activeCat;
                card.style.display = (matchTerm && matchCat) ? '' : 'none';
            });
        }

        searchInput.addEventListener('input', applyFilter);
        filterBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                filterBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                applyFilter();
            });
        });

        // Thanh toán
        document.getElementById('checkoutBtn').addEventListener('click', () => {
            const keys = Object.keys(cart);
            if (keys.length === 0) {
                alert('Giỏ hàng đang trống.');
                return;
            }
            const bookIds = keys.join(',');
            const quantities = keys.map(k => cart[k]).join(',');
            const customerName = document.getElementById('customerName').value.trim();
            const customerPhone = document.getElementById('customerPhone').value.trim();

            if (customerPhone !== "" && !/^\d{10}$/.test(customerPhone)) {
                alert("Số điện thoại khách hàng phải đúng 10 chữ số.");
                return;
            }
            
            const params = new URLSearchParams();
            params.append('paymentMethod', selectedPayment);
            params.append('bookIds', bookIds);
            params.append('quantities', quantities);
            params.append('customerName', customerName);
            params.append('customerPhone', customerPhone);

            const btn = document.getElementById('checkoutBtn');
            btn.disabled = true;
            btn.textContent = 'Đang xử lý...';
            

            fetch(ctx + '/checkout', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: params.toString()
            })
            .then(r => r.json().then(data => ({ status: r.status, data })))
            .then(({ status, data }) => {
                if (status === 200 && data.invoiceId) {
                    // Xóa giỏ hàng và reset số lượng trên từng thẻ sản phẩm
                    for (const k of Object.keys(cart)) {
                        delete cart[k];
                        const input = document.getElementById('qty-input-' + k);
                        if (input) input.value = 0;
                    }
                    document.getElementById('customerName').value = '';
                    document.getElementById('customerPhone').value = '';
                    renderCart();
                    openInvoiceModal(data.invoiceId);
                } else {
                    alert(data.error || 'Thanh toán thất bại.');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fa-solid fa-file-invoice-dollar"></i> Thanh toán';
                }
            })
            .catch(err => {
                alert('Lỗi kết nối: ' + err);
                btn.disabled = false;
                btn.innerHTML = '<i class="fa-solid fa-file-invoice-dollar"></i> Thanh toán';
            });
        });

        // --- Modal hóa đơn ---
        function openInvoiceModal(invoiceId) {
            const frame = document.getElementById('pdfFrame');
            frame.src = ctx + '/invoice/pdf?invoiceId=' + invoiceId;
            document.getElementById('invoiceModal').style.display = 'flex';
        }

        function closeInvoiceModal() {
            document.getElementById('invoiceModal').style.display = 'none';
            document.getElementById('pdfFrame').src = '';
            // Tải lại trang để cập nhật tồn kho sau khi bán
            window.location.reload();
        }

        document.getElementById('modalClose').addEventListener('click', closeInvoiceModal);
        document.getElementById('closeModalBtn').addEventListener('click', closeInvoiceModal);

        document.getElementById('printInvoiceBtn').addEventListener('click', () => {
            const frame = document.getElementById('pdfFrame');
            if (frame.contentWindow) {
                frame.contentWindow.focus();
                frame.contentWindow.print();
            }
        });

        // Đóng modal khi bấm ra ngoài vùng nội dung
        document.getElementById('invoiceModal').addEventListener('click', (e) => {
            if (e.target === document.getElementById('invoiceModal')) {
                closeInvoiceModal();
            }
        });
    </script>
</body>
</html>
