<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="true"%>
<%@ page import="java.util.List" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="structure.Invoice" %>
<%@ page import="structure.login" %>
<!DOCTYPE html>
<html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Lịch sử bán hàng - POS</title>
        <link rel="icon" href="<%=request.getContextPath()%>/favicon.svg" type="image/svg+xml">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="<%=request.getContextPath()%>/css/employee.css">

        <style>
            :root {
                /* Unified brand palette */
                --primary-color: #f5f1e7;
                --secondary-color: #2b1c15;
                --third-color: #dcb37b;
                --bg-main: #f4efe4;
                --bg-sidebar: #2b1c15;
                --bg-sidebar-hover: #3d2a1f;
                --text-light: #fff;
                --text-dark: #2e2820;
                --text-main: #4a4136;
                --text-muted: #8c8375;
                --border-color: #e9e0d0;
                --border-soft: #f0e8da;
                --card-bg: #fffdf9;
                --accent-gold: #dcb37b;
                --accent-gold-dark: #c79a5e;
                --accent-brown: #7a5c43;
                --accent-brown-dark: #5d4431;
                --danger: #d9534f;

                /* Gradients */
                --grad-gold: linear-gradient(135deg, #e7c692 0%, #dcb37b 45%, #c79a5e 100%);
                --grad-brown: linear-gradient(135deg, #8a6a4d 0%, #6b4f3a 100%);
                --grad-sidebar: linear-gradient(185deg, #38251b 0%, #2b1c15 55%, #201009 100%);
                --grad-surface: linear-gradient(180deg, #fffefb 0%, #fdf9f1 100%);

                --font-sans: 'Be Vietnam Pro', 'Segoe UI', Tahoma, sans-serif;
                --font-num: 'Inter', 'Be Vietnam Pro', sans-serif;
                --radius: 12px;
                --shadow-sm: 0 2px 6px rgba(43,28,21,0.06);
                --shadow-md: 0 8px 22px rgba(43,28,21,0.10);
                --transition: 0.25s cubic-bezier(0.4,0,0.2,1);
            }

            * { margin: 0; padding: 0; box-sizing: border-box; font-family: var(--font-sans); }

            /* Numbers → Inter */
            .money, .history-table td:nth-child(1), .history-table td:nth-child(3) {
                font-family: var(--font-num);
                font-variant-numeric: tabular-nums;
            }

            body {
                background-color: var(--bg-main);
                background-image:
                    radial-gradient(900px 480px at 100% -8%, rgba(220,179,123,0.14), transparent 60%),
                    radial-gradient(760px 420px at -6% 108%, rgba(122,92,67,0.09), transparent 55%);
                background-attachment: fixed;
                display: flex;
                height: 100vh;
                overflow: hidden;
                color: var(--text-dark);
                -webkit-font-smoothing: antialiased;
            }

            /* --- MAIN --- */
            .main-content {
                flex: 1;
                display: flex;
                flex-direction: column;
                overflow: hidden;
            }

            .top-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 16px 24px;
                background-color: var(--bg-main);
                border-bottom: 1px solid var(--border-color);
            }

            .top-header h2 {
                font-size: 19px;
                font-weight: 800;
                letter-spacing: -0.015em;
                position: relative;
                padding-left: 13px;
            }
            .top-header h2::before {
                content: "";
                position: absolute;
                left: 0; top: 2px; bottom: 2px;
                width: 5px;
                border-radius: 4px;
                background: var(--grad-gold);
            }

            .header-user {
                display: flex;
                align-items: center;
                gap: 10px;
                background: linear-gradient(135deg, #efe6d5, #e7dcc7);
                padding: 5px 16px 5px 5px;
                border-radius: 26px;
                font-size: 13px;
                color: var(--text-main);
                border: 1px solid var(--border-color);
                box-shadow: var(--shadow-sm);
            }

            .content-body {
                flex: 1;
                overflow-y: auto;
                padding: 22px 24px;
            }

            .error-message {
                color: var(--danger);
                background-color: #fdecea;
                border: 1px solid #f5c6c2;
                padding: 13px 15px;
                border-radius: var(--radius);
                margin-bottom: 16px;
            }

            .history-table {
                width: 100%;
                border-collapse: collapse;
                background: var(--card-bg);
                border: 1px solid var(--border-color);
                border-radius: 14px;
                overflow: hidden;
                box-shadow: var(--shadow-sm);
            }

            .history-table th, .history-table td {
                border-bottom: 1px solid var(--border-soft);
                padding: 13px 15px;
                text-align: left;
                font-size: 14px;
            }

            .history-table th {
                background-color: #f9f4ea;
                font-weight: 700;
                font-size: 0.72rem;
                text-transform: uppercase;
                letter-spacing: 0.06em;
                color: var(--text-muted);
                white-space: nowrap;
                border-bottom: 1px solid var(--border-color);
            }

            .history-table tr:last-child td { border-bottom: none; }
            .history-table tbody tr { transition: background-color var(--transition); }
            .history-table tr:hover { background-color: #f6efe2; }

            .money { font-weight: 600; color: var(--accent-brown); }

            /* Dòng tiêu đề nhóm theo ngày (giống mục Quản lý hóa đơn admin.jsp) */
            .history-table .day-header-row td {
                background-color: #efe6d6;
                color: var(--text-dark);
                font-weight: 600;
            }
            .history-table tr.day-header-row:hover td { background-color: #efe6d6; }

            .btn-view {
                background: var(--grad-brown);
                color: #fff;
                padding: 7px 15px;
                border-radius: 8px;
                text-decoration: none;
                font-size: 13px;
                font-weight: 600;
                display: inline-flex;
                align-items: center;
                gap: 6px;
                box-shadow: 0 3px 10px rgba(122,92,67,0.24);
                transition: background var(--transition), transform var(--transition), box-shadow var(--transition);
            }
            .btn-view:hover { background: var(--accent-brown-dark); transform: translateY(-2px); box-shadow: 0 6px 16px rgba(122,92,67,0.3); }

            .empty-state {
                text-align: center;
                padding: 60px 20px;
                color: #b3a994;
            }
            .empty-state i { font-size: 48px; margin-bottom: 12px; color: #ddd3c0; }

            ::-webkit-scrollbar { width: 7px; }
            ::-webkit-scrollbar-track { background: transparent; }
            ::-webkit-scrollbar-thumb { background: #cfc4b2; border-radius: 10px; }
            ::-webkit-scrollbar-thumb:hover { background: var(--accent-brown); }

            /* Tuỳ chỉnh Giao diện Modal PDF */
            .pdf-modal-content {
                border-radius: 12px;
                overflow: hidden;
                box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
            }

            .pdf-modal-header {
                background-color: #f8f9fa;
                border-bottom: 1px solid #e9ecef;
                padding: 1rem 1.5rem;
            }

            .pdf-iframe-container {
                position: relative;
                height: 100%;
                width: 100%;
                background-color: #f1f3f5; /* Màu nền lúc đang chờ tải */
            }

            /* Căn giữa hiệu ứng loading */
            .pdf-loader {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                z-index: 1;
            }

            /* Ẩn iframe lúc đầu để làm hiệu ứng fade-in */
            #pdfFrame {
                position: relative;
                z-index: 2;
                width: 100%;
                height: 100%;
                border: none;
                opacity: 0;
                transition: opacity 0.4s ease-in-out;
            }
        </style>
    </head>
    <body>
        <%
            // Kiểm tra đăng nhập
            structure.login user = (structure.login) session.getAttribute("user");
            if (user == null) {
                session.setAttribute("error", "Vui lòng đăng nhập");
                response.sendRedirect(request.getContextPath() + "/index.jsp");
                return;
            }
        %>

        <%
            login currentUser = (login) session.getAttribute("user");
            String displayName = (currentUser != null && currentUser.getUsername() != null && !currentUser.getUsername().isBlank())
                    ? currentUser.getUsername() : "Nhân viên";
        %>

        <%
            String success = (String) session.getAttribute("success");
            String error = (String) session.getAttribute("error");
            if (success != null) {
        %>
            <script>
                alert("<%= success %>");
            </script>
        <%
                session.removeAttribute("success");
            }
            if (error != null) {
        %>
            <script>
                alert("<%= error %>");
            </script>
        <%
                session.removeAttribute("error");
            }
        %>
        
        <%
            String headerName = displayName;
            String headerRole = (currentUser != null && currentUser.getRole() != null) ? currentUser.getRole() : "";
            String headerInitial = headerName.substring(0, 1).toUpperCase();
        %>
    
        <%
            String ctx = request.getContextPath();

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            SimpleDateFormat dayFmt = new SimpleDateFormat("dd/MM/yyyy");
            List<Invoice> invoices = (List<Invoice>) request.getAttribute("invoices");
            String errorMsg = (String) request.getAttribute("error");
        %>

        <aside class="sidebar">
            <div>
                <div class="brand">
                    <div class="brand-icon"><i class="fa-solid fa-book-open"></i></div>
                    <div class="brand-text">
                        <h1>Nhà Sách Minh Châu</h1>
                        <p>Hệ thống quản lý</p>
                    </div>
                </div>
                <ul class="nav-menu">
                    <li><a class="nav-item" href="<%=ctx%>/createCart"><i class="fa-solid fa-file-invoice"></i> Tạo hóa đơn</a></li>
                    <li><a class="nav-item active" href="<%=ctx%>/history"><i class="fa-solid fa-clock-rotate-left"></i> Lịch sử bán hàng</a></li>
                    <li><a class="nav-item" href="<%=ctx%>/viewSchedule"><i class="fa-solid fa-calendar-days"></i> Xem Lịch Làm Việc</a></li>
                </ul>
            </div>

            <div class="user-info-bottom">
                <div class="header-user">
                    <div class="avatar" style="width: 24px; height: 24px; font-size: 12px;"><%= displayName.substring(0, 1).toUpperCase() %></div>
                    <span><%= displayName %> <br><small style="color:#777; font-size: 10px;">Ca làm việc: <%= request.getAttribute("shiftLabel") != null ? request.getAttribute("shiftLabel") : "" %></small></span>
                </div>
                <button class="logout-btn" onclick="window.location.href='<%=ctx%>/index.jsp'">
                    <i class="fa-solid fa-right-from-bracket"></i> Đăng xuất
                </button>
            </div>
        </aside>

        <main class="main-content">
            <header class="top-header">
                <h2>Lịch sử bán hàng</h2>
            </header>

            <div class="content-body">
                <% if (errorMsg != null) { %>
                <div class="error-message"><%= errorMsg %></div>
                <% } %>

                <% if (invoices != null && !invoices.isEmpty()) { %>
                <table class="history-table">
                    <thead>
                        <tr>
                            <th>Ngày lập</th>
                            <th>Khách hàng</th>
                            <th>Tổng tiền</th>
                            <th>Phương thức</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <%
                            String currentDate = "";
                            for (Invoice inv : invoices) {
                                String custName = inv.getCustomerName() != null ? inv.getCustomerName() : "-";
                                String status = inv.getStatus() != null ? inv.getStatus() : "-";
                                String invoiceDay = dayFmt.format(inv.getInvoiceDate());

                                if (!invoiceDay.equals(currentDate)) {
                                    currentDate = invoiceDay;
                        %>
                        <tr class="day-header-row">
                            <td colspan="5"><strong>📅 Ngày <%= currentDate %></strong></td>
                        </tr>
                        <%
                                }
                        %>
                        <tr>
                            <td><%= sdf.format(inv.getInvoiceDate()) %></td>
                            <td><%= custName %></td>
                            <td class="money"><%= String.format("%,.0f", inv.getTotalAmount()) %> đ</td>
                            <td><%= inv.getPaymentMethod() != null ? inv.getPaymentMethod() : "-" %></td>
                            <td>
                                <button type="button" 
                                                class="btn btn-view btn-sm" 
                                                onclick="viewPdfModal('<%=request.getContextPath()%>/invoice/pdf?invoiceId=<%= inv.getId() %>')">
                                            <i class="fa-solid fa-eye me-1"></i>
                                        </button>
                            </td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>

                <%
                    Integer currentPage = (Integer) request.getAttribute("currentPage");
                    Integer totalPages = (Integer) request.getAttribute("totalPages");
                    if (currentPage == null) currentPage = 1;
                    if (totalPages == null) totalPages = 1;
                %>

                <% if (totalPages > 1) { %>
                <nav aria-label="Phân trang lịch sử bán hàng" class="mt-4">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <%= currentPage <= 1 ? "disabled" : "" %>">
                            <a class="page-link" href="?page=<%= currentPage - 1 %>">Trước</a>
                        </li>
                        <%
                            int startPage = Math.max(1, currentPage - 2);
                            int endPage = Math.min(totalPages, currentPage + 2);
                            for (int i = startPage; i <= endPage; i++) {
                        %>
                        <li class="page-item <%= i == currentPage ? "active" : "" %>">
                            <a class="page-link" href="?page=<%= i %>"><%= i %></a>
                        </li>
                        <% } %>
                        <li class="page-item <%= currentPage >= totalPages ? "disabled" : "" %>">
                            <a class="page-link" href="?page=<%= currentPage + 1 %>">Sau</a>
                        </li>
                    </ul>
                </nav>
                <% } %>

                <% } else if (errorMsg == null) { %>
                <div class="empty-state">
                    <i class="fa-solid fa-clock-rotate-left"></i>
                    <p>Chưa có lịch sử bán hàng nào.</p>
                </div>
                <% } %>
            </div>
        </main>
        <div class="modal fade" id="pdfViewerModal" tabindex="-1" aria-labelledby="pdfViewerModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-centered" style="height: 90vh;">
                <div class="modal-content h-100">
                    <div class="modal-header">
                        <h5 class="modal-title" id="pdfViewerModalLabel">
                            <i class="fa-solid fa-file-pdf text-danger me-2"></i>Chi tiết hóa đơn
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body p-0" style = "height:95vh; max-height:100vh; overflow-y:hidden; border-radius:8px">
                        <!-- Thẻ iframe để nhúng PDF -->
                        <iframe id="pdfFrame" src="" style="width: 100%; height: 100%; border: none;"></iframe>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            function viewPdfModal(pdfUrl) {
                    // 1. Gán URL của PDF vào iframe
                    const pdfFrame = document.getElementById('pdfFrame');
                    if (pdfFrame) {
                        pdfFrame.src = pdfUrl;
                        pdfFrame.style.opacity = '1';
                    }

                    // 2. Hiển thị Bootstrap Modal
                    const pdfModalEl = document.getElementById('pdfViewerModal');
                    if (pdfModalEl) {
                        const pdfModal = new bootstrap.Modal(pdfModalEl);
                        pdfModal.show();
                    }
                }

                // Xóa src của iframe khi đóng Modal để tiết kiệm bộ nhớ & tránh lưu lại file cũ
                document.getElementById('pdfViewerModal')?.addEventListener('hidden.bs.modal', function () {
                    document.getElementById('pdfFrame').src = '';
                });
        </script>
    </body>
</html>
