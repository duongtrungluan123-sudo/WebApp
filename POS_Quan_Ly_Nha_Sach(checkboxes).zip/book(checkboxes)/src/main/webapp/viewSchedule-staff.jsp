<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%@ page import="java.util.LinkedHashMap" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.util.Calendar" %>
<%@ page import="java.time.LocalDate" %>
<%@ page import="java.time.YearMonth" %>
<%@ page import="java.time.DayOfWeek" %>
<%@ page import="java.time.format.DateTimeFormatter" %>
<%@ page import="structure.login" %>
<%@ page import="structure.schedule" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Lịch làm việc cá nhân - Nhà Sách Minh Châu</title>
    <link rel="icon" href="<%=request.getContextPath()%>/favicon.svg" type="image/svg+xml">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<%=request.getContextPath()%>/css/admin.css">
    <link rel="stylesheet" href="<%=request.getContextPath()%>/css/employee.css">
    <style>
        :root {
            /* Unified brand palette */
            --primary-color: #f5f1e7;        
            --secondary-color: #2b1c15;      
            --third-color: #dcb37b;          
            --bg-main: #f4efe4;
            --bg-sidebar: #2b1c15;
            --bg-sidebar-hover: #3d2a1f;
            --text-light: #fff;
            --text-dark: #2e2820;
            --text-main: #4a4136;
            --text-muted: #8c8375;
            --border-color: #e9e0d0;
            --border-soft: #f0e8da;
            --card-bg: #fffdf9;
            --accent-gold: #dcb37b;
            --accent-gold-dark: #c79a5e;
            --accent-brown: #7a5c43;
            --accent-brown-dark: #5d4431;
            --btn-green: #7a5c43;
            --danger: #d9534f;

            /* Gradients */
            --grad-gold: linear-gradient(135deg, #e7c692 0%, #dcb37b 45%, #c79a5e 100%);
            --grad-brown: linear-gradient(135deg, #8a6a4d 0%, #6b4f3a 100%);
            --grad-sidebar: linear-gradient(185deg, #38251b 0%, #2b1c15 55%, #201009 100%);
            --grad-surface: linear-gradient(180deg, #fffefb 0%, #fdf9f1 100%);

            --font-sans: 'Be Vietnam Pro', 'Segoe UI', Tahoma, sans-serif;
            --font-num: 'Inter', 'Be Vietnam Pro', sans-serif;
            --radius: 12px;
            --shadow-sm: 0 2px 6px rgba(43,28,21,0.06);
            --shadow-md: 0 8px 22px rgba(43,28,21,0.10);
            --transition: 0.25s cubic-bezier(0.4,0,0.2,1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: var(--font-sans);
        }

        body {
            background-color: var(--bg-main);
            background-image:
                radial-gradient(900px 480px at 100% -8%, rgba(220,179,123,0.14), transparent 60%),
                radial-gradient(760px 420px at -6% 108%, rgba(122,92,67,0.09), transparent 55%);
            background-attachment: fixed;
            display: flex;
            height: 100vh;
            overflow: hidden;
            color: var(--text-dark);
            -webkit-font-smoothing: antialiased;
        }

        /* --- MAIN CONTENT --- */
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            background-color: transparent;
            padding:0px;
        }

        .top-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 24px;
            background-color: var(--bg-main);
            border-bottom: 1px solid var(--border-color);
        }

        .top-header h2 {
            font-size: 19px;
            font-weight: 800;
            letter-spacing: -0.015em;
            position: relative;
            padding-left: 13px;
            margin: 0;
            color: var(--text-dark);
        }

        .top-header h2::before {
            content: "";
            position: absolute;
            left: 0; top: 2px; bottom: 2px;
            width: 5px;
            border-radius: 4px;
            background: var(--grad-gold);
        }

        .btn-back {
            background: #fff;
            border: 1px solid var(--border-color);
            color: var(--text-main);
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 500;
            transition: all var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }

        .btn-back:hover {
            border-color: var(--accent-gold);
            color: var(--accent-brown-dark);
            background: var(--grad-surface);
        }

        .logout-btn span {
            position: relative;
            top: 1px;
        }
        /* --- CALENDAR SECTION --- */
        .calendar-container {
            padding: 24px;
            overflow-y: hidden;
            flex: 1;
        }

        .calendar-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .month-selector select {
            padding: 8px 14px;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            background: #fff;
            font-family: var(--font-num);
            font-weight: 500;
            color: var(--text-main);
            outline: none;
            transition: var(--transition);
            box-shadow: var(--shadow-sm);
        }

        .month-selector select:focus {
            border-color: var(--accent-gold);
            box-shadow: 0 0 0 3px rgba(220,179,123,0.22);
        }

        .calendar-grid {
            display: grid;
            height: 85%;
            grid-template-columns: repeat(7, 1fr);
            gap: 1px;
            background-color: var(--border-color); /* Acts as border */
            border: 1px solid var(--border-color);
            border-radius: 12px;
            box-shadow: var(--shadow-sm);
        }

        .calendar-day-header {
            background: var(--grad-surface);
            padding: 12px;
            text-align: center;
            font-weight: 700;
            color: var(--accent-brown-dark);
            font-size: 0.875rem;
        }

        .calendar-day {
            background-color: #fff;
            padding: 10px;
            position: relative;
            transition: background var(--transition);
        }
        
        .calendar-day:hover {
            background-color: #faf7f2;
        }

        .calendar-day.other-month {
            background-color: #fcfbfa;
            color: #cfc4b2;
        }

        .calendar-day.today {
            background-color: #fffdf9;
            box-shadow: inset 0 0 0 2px var(--accent-gold);
        }

        .day-number {
            font-family: var(--font-num);
            font-weight: 600;
            font-size: 0.95rem;
            margin-bottom: 8px;
            color: var(--text-dark);
        }
        
        .calendar-day.other-month .day-number {
            color: #cfc4b2;
        }

        .shift-item {
            padding: 6px 10px;
            margin-bottom: 5px;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 500;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            border-left: 3px solid transparent;
            box-shadow: 0 1px 3px rgba(0,0,0,0.04);
        }

        /* Theming the shifts to match the POS warm vibe while keeping distinction */
        .shift-item.morning {
            background-color: #f0f7ff;
            border-left-color: #4a90e2;
            color: #2c5282;
        }
        .shift-item.afternoon {
            background-color: #fff8f0;
            border-left-color: #f6ad55;
            color: #9c4221;
        }
        .shift-item.fullday {
            background-color: #fff1f2;
            border-left-color: #f43f5e;
            color: #9f1239;
        }

        .no-shifts {
            color: var(--text-muted);
            font-size: 0.75rem;
            font-style: italic;
            text-align: center;
            padding-top: 15px;
        }

        .legend {
            display: flex;
            gap: 20px;
            margin-top: 24px;
            flex-wrap: wrap;
            background: #fff;
            padding: 16px 24px;
            border-radius: 12px;
            border: 1px solid var(--border-color);
            box-shadow: var(--shadow-sm);
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.875rem;
            font-weight: 500;
            color: var(--text-main);
        }

        .legend-color {
            width: 20px;
            height: 20px;
            border-radius: 4px;
            border-left: 3px solid;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        /* Scrollbar styling */
        ::-webkit-scrollbar { width: 7px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #cfc4b2; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--accent-brown); }
    </style>
</head>
<body>
    <%
        // Kiểm tra đăng nhập
        structure.login user = (structure.login) session.getAttribute("user");
        if (user == null) {
            session.setAttribute("error", "Vui lòng đăng nhập");
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }
    %>

    <%
        login currentUser = (login) session.getAttribute("user");
        String displayName = (currentUser != null && currentUser.getUsername() != null && !currentUser.getUsername().isBlank())
                ? currentUser.getUsername() : "Nhân viên";
    %>

    <%
        String success = (String) session.getAttribute("success");
        String error = (String) session.getAttribute("error");
        if (success != null) {
    %>
        <script>
            alert("<%= success %>");
        </script>
    <%
            session.removeAttribute("success");
        }
        if (error != null) {
    %>
        <script>
            alert("<%= error %>");
        </script>
    <%
            session.removeAttribute("error");
        }
    %>
    
    <%
        String headerName = displayName;
        String headerRole = (currentUser != null && currentUser.getRole() != null) ? currentUser.getRole() : "";
        String headerInitial = headerName.substring(0, 1).toUpperCase();
    %>
    
    <!-- Sidebar -->
    <aside class="sidebar">
        <div>
            <div class="brand">
                <div class="brand-icon"><i class="fa-solid fa-book-open"></i></div>
                <div class="brand-text">
                    <h1>Nhà Sách Minh Châu</h1>
                    <p>Hệ thống quản lý</p>
                </div>
            </div>
            <ul class="nav-menu">
                <li><a class="nav-item" href="<%=request.getContextPath()%>/createCart"><i class="fa-solid fa-file-invoice"></i> Tạo hóa đơn</a></li>
                <li><a class="nav-item" href="<%=request.getContextPath()%>/history"><i class="fa-solid fa-clock-rotate-left"></i> Lịch sử bán hàng</a></li>
                <li><a class="nav-item active" href="<%=request.getContextPath()%>/viewSchedule"><i class="fa-solid fa-calendar-days"></i> Xem Lịch Làm Việc</a></li>
            </ul>
        </div>

        <div class="user-info-bottom">
            <div class="header-user">
                <div class="avatar" style="width: 24px; height: 24px; font-size: 12px;"><%= displayName.substring(0, 1).toUpperCase() %></div>
                <span><%= displayName %> <br><small style="color:#777; font-size: 10px;">Ca làm việc: <%= request.getAttribute("shiftLabel") != null ? request.getAttribute("shiftLabel") : "" %></small></span>
            </div>
            <button class="logout-btn" style = "height:38px" onclick="window.location.href='<%=request.getContextPath()%>/index.jsp'">
                <i class="fa-solid fa-right-from-bracket"></i> 
                <span>Đăng xuất<span>
            </button>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <header class="top-header">
            <h2>Lịch làm việc cá nhân</h2>
        </header>

        <div class="calendar-container">
            <div class="calendar-header">
                <div class="month-selector">
                    <form id="monthForm" method="GET" action="<%=request.getContextPath()%>/viewSchedule" class="d-flex align-items-center gap-2">
                        <input type="hidden" name="employeeId" value="${param.employeeId}">
                        <label for="monthSelect" class="form-label mb-0 fw-semibold" style="color: var(--text-main);">Tháng:</label>
                        <select id="monthSelect" name="month" class="form-select form-select-sm" style="width: auto;" onchange="this.form.submit()">
                            <%
                                int currentYear = java.time.LocalDate.now().getYear();
                                int currentMonth = java.time.LocalDate.now().getMonthValue();
                                String paramMonth = request.getParameter("month");

                                // Lặp qua năm hiện tại và năm tiếp theo (y = currentYear đến currentYear + 1)
                                for (int m = 1; m <= 12; m++) {
                                    String valueStr = currentYear + "-" + String.format("%02d", m);
                                    String selected = "";

                                    if (paramMonth != null && paramMonth.equals(valueStr)) {
                                        selected = "selected";
                                    } else if (paramMonth == null && m == currentMonth) {
                                        // Mặc định chọn đúng tháng hiện tại
                                        selected = "selected";
                                    }

                                    String monthName = java.time.Month.of(m).getDisplayName(java.time.format.TextStyle.FULL, new java.util.Locale("vi", "VN"));
                                    String capitalizedMonth = monthName.substring(0, 1).toUpperCase() + monthName.substring(1);
                            %>
                            <option value="<%=valueStr%>" <%=selected%>><%=capitalizedMonth%> <%=currentYear%></option>
                            <%
                                }
                            %>
                        </select>
                    </form>
                </div>
                <div class="legend">
                <div class="legend-item">
                    <div class="legend-color" style="background-color: #f0f7ff; border-left-color: #4a90e2;"></div>
                    <span>Ca Sáng</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background-color: #fff8f0; border-left-color: #f6ad55;"></div>
                    <span>Ca Chiều</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background-color: #fff1f2; border-left-color: #f43f5e;"></div>
                    <span>Cả ngày</span>
                </div>
            </div>
            </div>

            <%
                String monthParam = request.getParameter("month");
                YearMonth yearMonth;
                if (monthParam != null && !monthParam.isEmpty()) {
                    String[] parts = monthParam.split("-");
                    yearMonth = YearMonth.of(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]));
                } else {
                    yearMonth = YearMonth.now();
                }

                int year = yearMonth.getYear();
                int month = yearMonth.getMonthValue();

                LocalDate firstDayOfMonth = yearMonth.atDay(1);
                int daysInMonth = yearMonth.lengthOfMonth();
                int firstDayOfWeek = firstDayOfMonth.getDayOfWeek().getValue() % 7;

                Map<String, List<schedule>> scheduleMap = (Map<String, List<schedule>>) request.getAttribute("scheduleMap");
                if (scheduleMap == null) {
                    scheduleMap = new LinkedHashMap<>();
                }
            %>

            <!-- Calendar Grid -->
            <div class="calendar-grid" id="calendarGrid">
                <div class="calendar-day-header">CN</div>
                <div class="calendar-day-header">T2</div>
                <div class="calendar-day-header">T3</div>
                <div class="calendar-day-header">T4</div>
                <div class="calendar-day-header">T5</div>
                <div class="calendar-day-header">T6</div>
                <div class="calendar-day-header">T7</div>

                <%
                    for (int i = 0; i < firstDayOfWeek; i++) {
                %>
                <div class="calendar-day other-month"></div>
                <%
                    }

                    LocalDate today = LocalDate.now();
                    for (int day = 1; day <= daysInMonth; day++) {
                        LocalDate currentDate = LocalDate.of(year, month, day);
                        String dateKey = currentDate.toString();
                        boolean isToday = currentDate.equals(today);

                        List<schedule> daySchedules = scheduleMap.get(dateKey);
                %>
                <div class="calendar-day <%= isToday ? "today" : "" %>" data-date="<%= dateKey %>">
                    <div class="day-number"><%= day %></div>
                    <%
                        if (daySchedules != null && !daySchedules.isEmpty()) {
                            // Group shifts by employee to detect "Cả ngày" (both Sáng and Chiều for same employee on same day)
                            Map<String, List<String>> employeeShifts = new LinkedHashMap<>();
                            for (schedule s : daySchedules) {
                                String empName = s.getEmployeeName();
                                String shift = s.getShift();
                                employeeShifts.computeIfAbsent(empName, k -> new ArrayList<>()).add(shift);
                            }

                            for (Map.Entry<String, List<String>> entry : employeeShifts.entrySet()) {
                                String empName = entry.getKey();
                                List<String> shifts = entry.getValue();
                                String shiftClass = "";
                                String displayShift = "";

                                boolean hasMorning = shifts.contains("Sáng");
                                boolean hasAfternoon = shifts.contains("Chiều");
                                boolean hasFullDay = shifts.contains("Cả ngày");

                                if (hasFullDay || (hasMorning && hasAfternoon)) {
                                    shiftClass = "fullday";
                                    displayShift = "Cả ngày";
                                } else if (hasMorning) {
                                    shiftClass = "morning";
                                    displayShift = "Ca Sáng";
                                } else if (hasAfternoon) {
                                    shiftClass = "afternoon";
                                    displayShift = "Ca Chiều";
                                } else {
                                    shiftClass = "fullday";
                                    displayShift = shifts.get(0);
                                }
                    %>
                    <div class="shift-item <%= shiftClass %>">
                        <span><%= displayShift %></span>
                    </div>
                    <%
                            }
                        } else {
                    %>
                    <div class="no-shifts">Không có ca</div>
                    <%
                        }
                    %>
                </div>
                <%
                    }
                %>
            </div>

            
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>