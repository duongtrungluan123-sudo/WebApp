<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="structure.login" %>
<%@ page import="structure.Invoice" %>
<%@ page import="structure.books" %>
<%@ page import="database.InvoiceDAO" %>
<%@ page import="java.sql.SQLException" %>

<!DOCTYPE html>
<html>
    <head>
        <title>Doanh Thu - Nhà Sách Minh Châu</title>
        <link rel="icon" href="<%=request.getContextPath()%>/favicon.svg" type="image/svg+xml">
        <!-- Chart.js & Font Awesome -->
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<%=request.getContextPath()%>/css/admin.css">
    </head>
    <body>
        <%
            // Kiểm tra đăng nhập và role ADMIN
            structure.login user = (structure.login) session.getAttribute("user");
            if (user == null || !"Quản Lý".equals(user.getRole())) {
                session.setAttribute("error", "Vui lòng đăng nhập với tài khoản admin");
                response.sendRedirect(request.getContextPath() + "/index.jsp");
                return;
            }
        %>
        <%
            String success = (String) session.getAttribute("success");
            String error = (String) session.getAttribute("error");
            if (success != null) {
        %>
            <script>
                alert("<%= success %>");
            </script>

        <%
                session.removeAttribute("success");
            }
            if (error != null) {
        %>

            <script>
                alert("<%= error %>");
            </script>

        <%
                session.removeAttribute("error");
            }
        %>

        <%
            List<Invoice> revenue7Days = (List<Invoice>)request.getAttribute("revenue7Days");
            List<Invoice> revenueMonth = (List<Invoice>)request.getAttribute("revenueMonth");
        %>

        <div class="layout">
            <!-- Sidebar với thanh chọn -->
            <nav class="sidebar">
                <div class="sidebar-brand">
                    <i class="fa-solid fa-book-open"></i>
                    <div class="brand-text">
                        <span class="brand-name">Nhà Sách Minh Châu</span>
                        <span class="brand-sub">Hệ thống quản lý</span>
                    </div>
                </div>
                <ul class="sidebar-menu">
                    <li class="<%= "dashboard".equals(request.getParameter("page")) ? "active" : "active" %>">
                        <a href="<%=request.getContextPath()%>/dashboard"><i class="fa-solid fa-chart-column"></i> Báo Cáo Doanh Thu</a>
                    </li>
                    <li class="<%= "books".equals(request.getAttribute("tableName")) ? "active" : "" %>">
                        <a href="<%=request.getContextPath()%>/data?table=books"><i class="fa-solid fa-book"></i> Quản Lý Sách</a>
                    </li>
                    <li class="<%= "employees".equals(request.getAttribute("tableName")) ? "active" : "" %>">
                        <a href="<%=request.getContextPath()%>/data?table=employees"><i class="fa-solid fa-users"></i> Quản Lý Nhân Viên</a>
                    </li>
                    <li class="<%= "book-efficiency".equals(request.getParameter("page")) ? "active" : "" %>">
                        <a href="<%=request.getContextPath()%>/book-efficiency"><i class="fa-solid fa-arrow-trend-up"></i> Hiệu Suất Bán Hàng</a>
                    </li>
                    <li class="<%= "invoices".equals(request.getAttribute("tableName")) ? "active" : "" %>">
                        <a href="<%=request.getContextPath()%>/data?table=invoices"><i class="fa-regular fa-clock"></i> Quản Lý Hóa Đơn</a>
                    </li>
                    <li class="<%= "viewSchedule".equals(request.getParameter("page")) ? "active" : "" %>">
                        <a href="<%=request.getContextPath()%>/viewSchedule"><i class="fa-solid fa-calendar-days"></i> Lịch làm việc</a>
                    </li>
                </ul>

                <div class="sidebar-footer">
                    <%
                        structure.login dashUser = (structure.login) session.getAttribute("user");
                        String dashName = (dashUser != null && dashUser.getUsername() != null && !dashUser.getUsername().isBlank())
                                ? dashUser.getUsername() : "Quản Lý";
                        String dashRole = (dashUser != null && dashUser.getRole() != null) ? dashUser.getRole() : "";
                        String dashInitial = dashName.substring(0, 1).toUpperCase();
                    %>
                    <div class="header-user">
                        <div class="avatar"><%= dashInitial %></div>
                        <span><%= dashName %><br><small><%= dashRole %></small></span>
                    </div>
                    <button class="logout-btn" onclick="window.location.href='<%=request.getContextPath()%>/index.jsp'" style = "height:43.5px">
                        <i class="fa-solid fa-right-from-bracket"></i> Đăng xuất
                    </button>
                </div>
            </nav>

            <!-- Nội dung chính -->
            <div class="main-content-dashboard">
                <div class="header-top">
                    <h4 class = "mb-0">Báo Cáo Doanh Thu</h4>
                </div>

                <% String errorMsg = (String) request.getAttribute("error"); %>
                <% if (errorMsg != null) { %>
                <div class="error-message"><%= errorMsg %></div>
                <% } %>

                <%
                    Double todayRevenue = (Double) request.getAttribute("todayRevenue");
                    Double morningShiftRevenue = (Double) request.getAttribute("todayShiftMorning");
                    Double afternoonShiftRevenue = (Double) request.getAttribute("todayShiftAfternoon");
                    Double monthlyRevenue = (Double) request.getAttribute("monthlyRevenue");

                    // Tổng doanh thu các biểu đồ
                    double total7Days = 0.0;
                    if (revenue7Days != null) {
                        for (Invoice inv : revenue7Days) {
                            total7Days += inv.getTotalAmount();
                        }
                    }

                    double totalMonth = 0.0;
                    if (revenueMonth != null) {
                        for (Invoice inv : revenueMonth) {
                            totalMonth += inv.getTotalAmount();
                        }
                    }
                %>


                <!-- Row 1: Today's Revenue Stats (3 cards) -->
                <div class="dashboard-row">
                    <div class="stat-card">
                        <h3>Doanh Thu Hôm Nay</h3>
                            <div class="value">
                                <%= String.format("%,.0f", todayRevenue != null ? todayRevenue : 0) %><span style="font-size: 50px;">đ</span>
                            </div>
                            <div class="today-date"><%= String.format("%02d/%02d/%d", java.time.LocalDate.now().getDayOfMonth(), java.time.LocalDate.now().getMonthValue(), java.time.LocalDate.now().getYear())%>
                            </div>
                    </div>

                    <%
                        Integer orderMorning = (Integer) request.getAttribute("todayOrderMorning");
                        Integer orderAfternoon = (Integer) request.getAttribute("todayOrderAfternoon");
                    %>
                    <div class="stat-card success">
                        <h3>Ca Sáng (08:00 - 14:00)</h3>
                        <div class="value"><%= String.format("%,.0f", morningShiftRevenue != null ? morningShiftRevenue : 0) %><span style="font-size: 50px;">đ</span></div>
                        <div class="today-date">Số đơn: <%= orderMorning != null ? orderMorning : 0 %></div>
                    </div>


                    <div class="stat-card info">
                        <h3>Ca Chiều (14:00 - 20:00)</h3>
                        <div class="value"><%= String.format("%,.0f", afternoonShiftRevenue != null ? afternoonShiftRevenue : 0) %><span style="font-size: 50px;">đ</span></div>
                        <div class="today-date">Số đơn: <%= orderAfternoon != null ? orderAfternoon : 0 %></div>
                    </div>
                </div>

                <!-- Row 2: 7-Day Revenue Chart & Book Efficiency-->
                <div class="dashboard-row row-rev">
                    <div class="chart-section split-left">
                        <div class="chart-title chart-title--revenue">
                            <span class="chart-title-label">
                                <i class="fa-solid fa-chart-column"></i>
                                Doanh Thu Theo Tuần
                            </span>
                            <span class="chart-title-total" style="font-size: 20px;">Tổng: <%= String.format("%,.0f", total7Days) %>đ</span>
                        </div>
                        <div class="chart-container">
                            <canvas id="chart7days"></canvas>
                        </div>
                    </div>
                    <div class="chart-section split-right">
                        <div class="chart-title">
                            <i class="fa-solid fa-star"></i>
                            Top 5 Sách Bán Chạy Nhất
                        </div>
                        <div class="top-books-list">
                            <%
                                List<books> topSellers =
                                        (List<books>) request.getAttribute("topSellers");
                                // Tìm số lượng bán cao nhất để tính tỉ lệ thanh progress bar.
                                int maxSold = 0;
                                if (topSellers != null) {
                                    for (books b : topSellers) {
                                        if (b.getSold() > maxSold) maxSold = b.getSold();
                                    }
                                }
                                if (topSellers != null && !topSellers.isEmpty()) {
                                    int rank = 1;
                                    for (books b : topSellers) {
                                        String img = b.getImageUrl() != null ? b.getImageUrl() : "";
                                        String title = b.getBookName() != null ? b.getBookName() : "";
                                        String author = b.getAuthor() != null ? b.getAuthor() : "";
                                        int sold = b.getSold();
                                        int pct = (maxSold > 0) ? (sold * 100 / maxSold) : 0;
                                        String bg = img.isEmpty() ? ""
                                                : "background-image:url('"
                                                + request.getContextPath()
                                                + "/image?name=" + img
                                                + "');background-size:cover;";
                            %>
                            <div class="top-book-item">
                                <div class="top-book-rank">#<%= rank %></div>
                                <div class="top-book-img" style="<%= bg %>"></div>
                                <div class="top-book-info">
                                    <div class="top-book-title"><%= title %></div>
                                    <div class="top-book-author"><%= author %></div>
                                    <div class="progress-bar-custom"><div class="progress-fill" style="width: <%= pct %>%;"></div></div>
                                </div>
                                <div class="top-book-sold"><%= sold %><br><small>đã bán</small></div>
                            </div>
                            <%
                                        rank++;
                                    }
                                } else {
                            %>
                            <div class="loading">Chưa có dữ liệu bán hàng.</div>
                            <%
                                }
                            %>
                        </div>
                    </div>
                </div>

                <!-- Row 3: Monthly Revenue Chart-->
                <div class="chart-section full-width">
                    <div class="chart-title chart-title--revenue">
                        <span class="chart-title-label">
                            <i class="fa-solid fa-chart-column"></i>
                            Doanh Thu Theo Tháng
                        </span>
                        <span class="chart-title-total" style="font-size: 20px;">Tổng: <%= String.format("%,.0f", totalMonth) %>đ</span>
                    </div>
                    <div class="chart-container">
                        <canvas id="monthlyChart"></canvas>
                    </div>
                </div>

                

            </div>
        </div>

        <script>
            // Dữ liệu mẫu cho các biểu đồ
            const revenue7Days = [

                <%
                if(revenue7Days != null){
                    for(int i=0;i<revenue7Days.size();i++){

                        out.print(revenue7Days.get(i).getTotalAmount());

                        if(i < revenue7Days.size()-1){
                            out.print(",");
                        }
                    }
                }
                %>

            ];

            // Trục y động: lấy doanh thu lớn nhất, chia thành 5 mốc
            function niceCeil(v) {
                if (!v || v <= 0) return 1000000;
                var exp = Math.floor(Math.log10(v));
                var base = Math.pow(10, exp);
                var n = v / base;
                var nf = n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10;
                return nf * base;
            }
            

            function makeYScale(data) {
                var max = 0;
                for (var i = 0; i < data.length; i++) {
                    if (data[i] > max) max = data[i];
                }
                var top = niceCeil(max);
                return {
                    beginAtZero: true,
                    max: top,
                    ticks: {
                        stepSize: top / 5,
                        // Sử dụng toLocaleString để tạo dấu phân cách hàng nghìn (VD: 1.200.000)
                        callback: function (value) { return value.toLocaleString('vi-VN'); }
                    }
                };
            }

            const monthlyData = [
                <%
                    if(revenueMonth != null){
                        for(int i = 0; i < revenueMonth.size(); i++){
                            out.print(revenueMonth.get(i).getTotalAmount());
                            if(i < revenueMonth.size()-1){
                                out.print(",");
                            }
                        }
                    }
                %>
            ];


            document.addEventListener('DOMContentLoaded', function() {
                // Dùng font Inter cho toàn bộ số liệu trên biểu đồ
                if (window.Chart) {
                    Chart.defaults.font.family = 'Inter';
                    Chart.defaults.color = '#8c8375';
                }
                // Row 2: Biểu đồ doanh thu 7 ngày
                const chart7days = document.getElementById('chart7days');
                if (chart7days) {
                    new Chart(chart7days, {
                        type: 'bar',
                        data: {
                            labels: [
                            <%
                                String[] thu = {"CN","T2","T3","T4","T5","T6","T7"};

                                if(revenue7Days != null){

                                    for(int i=0;i<revenue7Days.size();i++){

                                        java.sql.Timestamp date = revenue7Days.get(i).getInvoiceDate();

                                        java.time.LocalDate localDate = date.toLocalDateTime().toLocalDate();

                                        String dayName = thu[localDate.getDayOfWeek().getValue()%7];
                                        String label = dayName + " " + String.format("%02d/%02d",localDate.getDayOfMonth(), localDate.getMonthValue());

                                        out.print("'" + label + "'");

                                        if(i < revenue7Days.size()-1)
                                            out.print(",");
                                    }
                                }
                            %>],
                            datasets: [{
                                label: 'Doanh thu (VNĐ)',
                                data: revenue7Days,
                                backgroundColor: '#7a5c43',
                                borderRadius: 5,
                                maxBarThickness: 35
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            font: {
                                family: 'Inter'
                            },
                            scales: {
                                y: makeYScale(revenue7Days)
                            }
                        }
                    });
                }

                // Row 3: Biểu đồ doanh thu theo tháng
                const monthlyChart = document.getElementById('monthlyChart');
                if (monthlyChart) {
                    new Chart(monthlyChart, {
                        type: 'bar',
                        data: {
                            labels: [
                            <%
                            if(revenueMonth!=null){
                                for(int i=0;i<revenueMonth.size();i++){

                                    java.sql.Timestamp date = revenueMonth.get(i).getInvoiceDate();
                                    java.time.LocalDate ld = date.toLocalDateTime().toLocalDate();

                                    out.print("'" + ld.getDayOfMonth() + "'");

                                    if(i<revenueMonth.size()-1)
                                        out.print(",");
                                }
                            }
                            %>
                            ],
                            datasets: [{
                                label: 'Doanh thu (VNĐ)',
                                data: monthlyData,
                                backgroundColor: '#7a5c43',
                                borderRadius: 5
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            font: {
                                family: 'Inter'
                            },
                            scales: {
                                y: makeYScale(monthlyData)
                            }
                        }
                    });
                }
            });
        </script>
    </body>
</html>
